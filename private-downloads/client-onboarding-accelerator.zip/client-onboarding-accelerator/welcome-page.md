# Welcome to [YOUR STUDIO NAME] — Let's Get Started 🚀

**Prepared for:** [CLIENT NAME], [CLIENT COMPANY]
**Project:** [PROJECT NAME]
**Your point of contact:** [YOUR NAME], [YOUR TITLE]
**Date:** [DATE]

---

## Welcome aboard, [CLIENT FIRST NAME] 👋

Thank you for trusting us with [PROJECT NAME]. We're genuinely excited to work with you — and we don't take the trust lightly.

This page is your **single source of truth** for what happens next. Read it once (it takes 3 minutes), then complete the two quick steps at the bottom. That's it — we'll handle the rest.

> **TL;DR:** Complete the intake questionnaire and book your kickoff call. Links are at the bottom of this page.

---

## What you can expect from us

| Commitment | What it means in practice |
|------------|---------------------------|
| **A clear plan** | You'll receive a written scope and timeline before any work begins. |
| **Proactive updates** | A short progress update every [FREQUENCY, e.g. Friday], even if the news is "on track." |
| **Fast, honest replies** | We reply to emails within [X business hours]. If something is at risk, you'll hear it from us first. |
| **No surprises** | Any change in scope, cost, or timeline is agreed with you *in writing* before it happens. |
| **Your work, protected** | All files, passwords, and access are handled confidentially and returned or destroyed on request. |

---

## What we need from you

To hit the ground running, we need three things. Most clients complete this in under 20 minutes.

1. **Complete the intake questionnaire** — [LINK TO INTAKE QUESTIONNAIRE]
   *Why it matters: it tells us your goals, your audience, and where your assets live so we don't waste the first week asking questions.*

2. **Book your kickoff call** — [BOOKING LINK, e.g. Calendly]
   *A 30–45 minute call to align on goals, scope, and timeline. Pick any slot that works for you.*

3. **Grant access** — [LIST TOOLS, e.g. Google Drive folder, website CMS, ad accounts]
   *We'll send secure, individual access requests — never share passwords over email.*

---

## Your onboarding timeline

| Step | What happens | Who | When |
|------|--------------|-----|------|
| 1 | You complete the intake questionnaire | You | Within 2 days of signing |
| 2 | We review & flag anything missing | Us | Within 1 business day |
| 3 | Kickoff call | Both | Within 3–5 days |
| 4 | You approve the written scope & timeline | You | Within 1 day of kickoff |
| 5 | Work begins 🎉 | Us | Immediately after approval |

---

## How we'll communicate

We keep things simple and predictable:

- **Email** — for anything official, decisions, and approvals.
- **[PROJECT TOOL, e.g. Slack / Notion / ClickUp]** — for day-to-day updates and quick questions.
- **Calls** — [CADENCE, e.g. a 20-minute check-in every Tuesday].

Full details, including response times and how to reach us in an emergency, are in our **[Communication Guidelines](communication-guidelines.md)**. We'll walk through them at kickoff.

---

## Meet your team

| Name | Role | Best for | Contact |
|------|------|----------|---------|
| [YOUR NAME] | [TITLE / Lead] | Strategy, decisions, escalations | [EMAIL] |
| [TEAM MEMBER] | [ROLE] | [e.g. Day-to-day delivery] | [EMAIL] |
| [TEAM MEMBER] | [ROLE] | [e.g. Design & assets] | [EMAIL] |

---

## Frequently asked questions

**How soon can we start?**
Work begins as soon as the questionnaire is returned and the scope is approved — typically within [X] business days of signing.

**What if I don't have all my content ready?**
No problem. Tell us in the questionnaire and we'll build a content-collection step into the plan. We can also start with what you have.

**Who owns the work when it's done?**
You do — full ownership transfers on final payment, as set out in our agreement.

**What if I need changes after we start?**
Small tweaks within scope are handled through our [Revision Request Form](revision-request-form.md). Anything beyond the agreed scope is quoted as a change order before we proceed.

**What if I need to pause the project?**
Just tell us. We'll agree a restart date and adjust the timeline. See our [Communication Guidelines](communication-guidelines.md) for the pause policy.

---

## Your next two steps ✅

1. 👉 **Complete the intake questionnaire:** [LINK]
2. 👉 **Book your kickoff call:** [LINK]

Once those are done, you'll receive your written scope and timeline within one business day. Then we build.

---

*Questions before then? Just reply to this email or reach me directly at [EMAIL] / [PHONE]. I'm looking forward to it.*

**— [YOUR NAME]**
[YOUR TITLE], [YOUR STUDIO NAME]
[WEBSITE] · [SOCIAL LINKS]
