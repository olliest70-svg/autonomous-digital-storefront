# Project Scope & Deliverables Tracker

**Project:** [PROJECT NAME]
**Client:** [CLIENT COMPANY]
**Prepared by:** [YOUR NAME]
**Version:** 1.0 · **Last updated:** [DATE]
**Status:** 🟡 Awaiting client sign-off

> **How to use this:** This is the single source of truth for what's included, what it costs, and when it's delivered. Update it weekly. Any change to scope, cost, or timeline is recorded here as a **Change Order** *before* work begins. Sign-off below makes it contractually binding.

---

## 1. Project summary

| Field | Detail |
|-------|--------|
| Objective | [One-line goal from the intake questionnaire] |
| Start date | [DATE] |
| Target completion | [DATE] |
| Total investment | [CURRENCY AMOUNT] |
| Payment terms | [e.g. 50% deposit, 50% on delivery] |
| Included revision rounds | [e.g. 2] |
| Out-of-scope rate | [e.g. $XXX/hour or per-item quote] |

---

## 2. Deliverables tracker

| # | Deliverable | Description | Owner | Due date | Status | Approved |
|---|-------------|-------------|-------|----------|--------|----------|
| 1 | [e.g. Brand strategy doc] | [Short description] | [Us/You] | [DATE] | ⬜ Not started | ☐ |
| 2 | [e.g. Homepage design] | [Short description] | [Us] | [DATE] | 🟡 In progress | ☐ |
| 3 | [e.g. Copywriting] | [Short description] | [Us] | [DATE] | ⬜ Not started | ☐ |
| 4 | [e.g. Development build] | [Short description] | [Us] | [DATE] | ⬜ Not started | ☐ |
| 5 | [e.g. QA & launch] | [Short description] | [Both] | [DATE] | ⬜ Not started | ☐ |

**Status key:** ⬜ Not started · 🟡 In progress · 🔵 In review · 🟢 Complete · 🔴 Blocked

---

## 3. Milestones & timeline

| Milestone | Description | Date | Depends on |
|-----------|-------------|------|------------|
| M1 — Kickoff | Scope signed off, access granted | [DATE] | Questionnaire returned |
| M2 — Concept | First concepts presented | [DATE] | M1 |
| M3 — Review | Client feedback round 1 | [DATE] | M2 |
| M4 — Build | Final assets produced | [DATE] | M3 |
| M5 — Launch | Delivered & handed over | [DATE] | M4 |

---

## 4. What's included vs. not included

### ✅ Included in this scope

- [Deliverable / activity 1]
- [Deliverable / activity 2]
- [Deliverable / activity 3]
- [e.g. 2 rounds of revisions per deliverable]
- [e.g. 1 kickoff call + 1 handover session]

### ❌ Not included (available as a change order)

- [e.g. Additional pages beyond the agreed 5]
- [e.g. Ongoing maintenance after launch]
- [e.g. Third-party licence or stock costs]
- [e.g. Copywriting for new sections]
- [e.g. Revisions beyond round 2]

---

## 5. Client responsibilities

To keep the project on schedule, the client agrees to:

- [ ] Return the intake questionnaire by [DATE]
- [ ] Provide all required assets by [DATE]
- [ ] Grant tool access by [DATE]
- [ ] Provide consolidated feedback within [X] business days of each review
- [ ] Nominate a single point of contact with sign-off authority

> **Delay clause:** Timelines assume the above are met. Delays in client inputs may shift delivery dates by an equivalent period.

---

## 6. Change order log

Any request that falls outside Section 4 ("Included") is logged here and quoted before work begins.

| CO # | Date | Requested by | Description | Impact on cost | Impact on timeline | Approved |
|------|------|--------------|-------------|----------------|--------------------|----------|
| CO-001 | [DATE] | [Name] | [e.g. Add 3 extra pages] | +[AMOUNT] | +[X] days | ☐ |
| CO-002 | | | | | | ☐ |

**Change order process:**

1. Client submits the request (via the [Revision Request Form](revision-request-form.md) or email).
2. We assess scope, cost, and timeline impact within [2] business days.
3. We issue a written quote (this table row).
4. Client approves in writing. **Work begins only after approval.**
5. Tracker and timeline are updated.

---

## 7. Risk & assumptions log

| Risk / assumption | Likelihood | Impact | Mitigation |
|-------------------|-----------|--------|------------|
| [e.g. Brand assets delayed] | Medium | High | [Start with placeholder, swap later] |
| [e.g. Stakeholder availability] | Low | Medium | [Weekly async updates] |

---

## 8. Sign-off

By signing below, both parties confirm this scope, timeline, and cost are agreed and form part of the project agreement.

| | Name | Signature | Date |
|---|------|-----------|------|
| **Client** | | | |
| **Provider** | | | |

---

*This tracker is a living document. The latest version always supersedes prior versions.*
