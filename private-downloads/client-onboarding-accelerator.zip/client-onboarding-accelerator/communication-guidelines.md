# Communication Guidelines

**Between:** [YOUR STUDIO NAME] ("we") and [CLIENT COMPANY] ("you")
**Project:** [PROJECT NAME]
**Effective from:** [DATE]

> **Why this document exists:** Clear communication is the single biggest predictor of a smooth project. These guidelines set expectations for both sides so nothing gets lost, nobody feels ignored, and everyone's time is respected. We'll review them together at kickoff.

---

## 1. Channels — what to use for what

| Channel | Use it for | Response time |
|---------|-----------|---------------|
| **Email** ([ADDRESS]) | Decisions, approvals, official requests, anything that needs a record | Within [1] business day |
| **[PROJECT TOOL, e.g. Slack]** | Day-to-day questions, quick updates, file sharing | Within [4] business hours |
| **Scheduled calls** | Strategy, reviews, brainstorming | Per cadence below |
| **Phone / SMS** ([NUMBER]) | Genuine emergencies only | As soon as possible |

**Please avoid:** sending the same request across multiple channels, or giving feedback by voice note (it's hard to track). Use the [Revision Request Form](revision-request-form.md) for feedback.

---

## 2. Response-time commitments (SLAs)

| Situation | Our commitment |
|-----------|----------------|
| Standard email | Reply within [1] business day |
| Project tool message | Reply within [4] business hours |
| Urgent (project-blocking) | Reply within [2] hours during business hours |
| Out of hours | Next business morning |

**Our working hours:** [e.g. Mon–Fri, 9:00–17:00 [TIMEZONE]]. We do not monitor messages outside these hours except for pre-agreed emergencies.

**What we ask of you:**

- A single point of contact for consolidated feedback.
- Responses to our questions within [2] business days so we can keep momentum.
- Approvals within [2] business days of a review request.

---

## 3. Meeting cadence

| Meeting | Frequency | Duration | Purpose |
|---------|-----------|----------|---------|
| Kickoff | Once | 30–45 min | Align on goals, scope, timeline |
| Progress check-in | [Weekly, e.g. Tue 10:00] | 20 min | Status, blockers, next steps |
| Review session | Per milestone | 30 min | Walk through deliverables |
| Handover | Once | 45 min | Final delivery & training |

**Meeting etiquette:**

- Agendas shared at least [24] hours in advance.
- Notes and action items sent within [1] business day.
- If a meeting is no longer needed, cancel at least [4] hours ahead.

---

## 4. Status reporting

Every [Friday], you'll receive a short written update covering:

- ✅ **Done this week**
- 🔵 **In progress**
- 🔴 **Blocked / needs your input**
- 📅 **Next week's focus**

This is backed by the live [Project Scope Tracker](project-scope-tracker.md), which you can view at any time.

---

## 5. Escalation path

If something isn't working, here's how to raise it:

| Step | Who | When |
|------|-----|------|
| 1 | Raise it with your day-to-day contact | Immediately |
| 2 | If unresolved in [2] business days, escalate to [SENIOR NAME / EMAIL] | Within 2 days |
| 3 | Formal review call | Within [5] business days |

We'd rather hear a concern early than discover it late. No issue is too small.

---

## 6. Pauses, changes & delays

- **Pausing the project:** Notify us in writing. We'll agree a restart date; the timeline shifts by the pause duration.
- **Changes to scope:** Handled via change orders in the [Project Scope Tracker](project-scope-tracker.md).
- **Delays on your side:** If inputs are late, we'll flag the impact on delivery dates and adjust the plan together.
- **Delays on our side:** You'll hear it from us first, with a revised plan — never silence.

---

## 7. Confidentiality & data

- All shared information is treated as confidential.
- Access is granted via secure, individual invitations — never share passwords over email.
- On project completion, we return or delete your credentials and data on request.

---

## 8. Agreement

By continuing with the project, both parties agree to follow these communication guidelines.

| | Name | Signature | Date |
|---|------|-----------|------|
| **Client** | | | |
| **Provider** | | | |

---

*Questions about any of this? Ask at kickoff — we'd rather over-explain than under-communicate.*
