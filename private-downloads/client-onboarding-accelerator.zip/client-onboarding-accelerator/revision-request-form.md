# Handle Revisions Without the Drama — One Form, No Confusion

**Project:** [PROJECT NAME]
**Client:** [CLIENT COMPANY]
**Round:** [e.g. 1 of 2]
**Submitted by:** [NAME]
**Date submitted:** [DATE]

> **How to use this:** Use this form for **every** round of feedback. Consolidate all comments from all stakeholders into one submission. Feedback sent by email, text, or voice note may not be actioned. This keeps revisions fast, trackable, and within scope.

---

## 1. What are you reviewing?

| Field | Detail |
|-------|--------|
| Deliverable | [e.g. Homepage design v2] |
| Version / link | [LINK] |
| Review deadline | [DATE] |
| Round | [1] of [2] included |

---

## 2. Overall verdict

- [ ] ✅ **Approved** — proceed as-is
- [ ] 🟡 **Approved with minor changes** — see below
- [ ] 🔴 **Needs revision** — see below

---

## 3. Revision requests

List each change as a separate row. Be specific: *what* to change, *where*, and *why*.

| # | Location / element | Current state | Requested change | Priority | In scope? |
|---|--------------------|---------------|------------------|----------|-----------|
| 1 | [e.g. Hero headline] | ["Grow faster"] | [Change to "Grow 2x faster"] | High | ✅ |
| 2 | [e.g. Colour of CTA] | [Blue] | [Match brand green #1FA37A] | Medium | ✅ |
| 3 | [e.g. Add testimonial section] | [Not present] | [Add 3-quote carousel] | Low | ⚠️ New scope |
| 4 | | | | | |

**Priority key:** High = blocks approval · Medium = important · Low = nice-to-have

---

## 4. Out-of-scope flag

If any item above is marked **⚠️ New scope**, it will be handled as a change order (see the [Project Scope Tracker](project-scope-tracker.md)) and quoted separately before work begins.

| Item # | Description | Estimated impact | Approved as change order? |
|--------|-------------|------------------|---------------------------|
| | | [Cost / time] | ☐ |

---

## 5. Consolidation check

Before submitting, confirm:

- [ ] All stakeholders have reviewed and their comments are merged here.
- [ ] No duplicate requests.
- [ ] Each request is specific and actionable.
- [ ] Priorities are agreed (not everything can be High).
- [ ] This is one consolidated round — not a running list.

---

## 6. Revision policy (summary)

| Item | Policy |
|------|--------|
| Included rounds | [2] per deliverable |
| Turnaround per round | [X] business days after receipt |
| Extra rounds | Billed at [RATE] per round |
| Scope changes | Quoted as change orders before work begins |
| Feedback channel | This form only |

---

## 7. Provider response

*For internal use — completed by [YOUR STUDIO NAME].*

| Field | Detail |
|-------|--------|
| Received | [DATE] |
| Items accepted | [#] |
| Items flagged out-of-scope | [#] |
| Estimated completion | [DATE] |
| Notes | |

---

*Submitting this form confirms the feedback is final for this round and consolidated from all stakeholders.*
