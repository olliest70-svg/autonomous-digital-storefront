# Impress Every Client From Day One — The Agency Onboarding Kit

**The complete, plug-and-play onboarding system for freelancers, agencies, consultants, and studios.**

Stop losing your first two weeks (and your margin) to scattered emails, "quick questions," and scope surprises. The Client Onboarding Accelerator gives you six polished, contract-ready documents that take a new client from *"Nice to meet you"* to *"Kickoff is booked, everything's signed, and I know exactly what I'm delivering"* — in under 48 hours.

---

## What's inside

| # | File | What it does | Who it's for |
|---|------|--------------|--------------|
| 1 | `welcome-page.md` | A warm, branded first-touch page that sets expectations, links every next step, and makes you look like a 20-person firm. | Send within 1 hour of signing. |
| 2 | `intake-questionnaire.md` | A structured discovery questionnaire that extracts everything you need to start — goals, assets, access, stakeholders, and constraints. | Send with the welcome page. |
| 3 | `project-scope-tracker.md` | A living scope + deliverables tracker with a change-order mechanism so "one small tweak" never becomes free work. | Set up at kickoff; update weekly. |
| 4 | `revision-request-form.md` | A single, repeatable form clients use for every round of feedback — with a built-in revision counter and out-of-scope flag. | Share at kickoff; require for every round. |
| 5 | `communication-guidelines.md` | Your response-time SLAs, channel rules, meeting cadence, and escalation path — the document that protects your calendar. | Attach to every proposal & contract. |
| 6 | `README.md` | This file — how to deploy the system, in what order, and how to customize it. | You. |

---

## The problem this solves

Most client relationships don't fail because of bad work. They fail because of **unclear expectations**. The Accelerator closes the five gaps that quietly destroy projects and margins:

1. **The Silence Gap** — clients don't hear from you for days and start to worry.
2. **The Discovery Gap** — you start before you have the assets, access, and answers you need.
3. **The Scope Gap** — "while you're in there, could you also…"
4. **The Feedback Gap** — vague revisions arrive by email, text, and voice note with no structure.
5. **The Boundary Gap** — clients expect instant replies at 11pm because nobody told them otherwise.

Each document in this kit maps directly to one of those gaps.

---

## How to deploy it (the 48-hour onboarding flow)

```
DAY 0  ── Proposal accepted / contract signed
         │
         ├─► Send welcome-page.md + intake-questionnaire.md  (within 1 hour)
         │
DAY 1  ── Client returns questionnaire
         │
         ├─► Review answers, flag missing assets
         ├─► Set up project-scope-tracker.md from their answers
         │
DAY 2  ── Kickoff call (30–45 min)
         │
         ├─► Walk through communication-guidelines.md
         ├─► Agree the scope tracker together (get sign-off)
         ├─► Demo revision-request-form.md
         │
DAY 3+ ── Project runs. Weekly tracker update. Every revision via the form.
```

**Golden rule:** nothing starts until the questionnaire is returned and the scope tracker is signed off. This single rule prevents 80% of onboarding chaos.

---

## Quick-start checklist

- [ ] Replace all `[BRACKETED]` placeholders with your details (search for `[` to find them all).
- [ ] Add your logo, brand colors, and booking link to `welcome-page.md`.
- [ ] Set your real response-time SLAs in `communication-guidelines.md`.
- [ ] Decide your included revision count (most studios use 2) and set it in `revision-request-form.md`.
- [ ] Add your hourly rate for out-of-scope work in `project-scope-tracker.md`.
- [ ] Save all six files as templates in your project management tool (Notion, ClickUp, Google Docs, etc.).
- [ ] Create a reusable email snippet that links to the welcome page + questionnaire.

---

## Customization guide

| If you are a… | Change this |
|---------------|-------------|
| **Freelancer / solo** | Keep it lean. You can merge the welcome page and questionnaire into one email. |
| **Small agency (2–10)** | Add a named project manager and account contact to the welcome page. |
| **Consultant** | Emphasize the intake questionnaire and communication guidelines; scope tracker can be lighter. |
| **Studio / creative** | Lean on the revision-request form and scope tracker — these protect your creative time. |
| **Retainer client** | Duplicate the scope tracker per month/quarter and track hours against a retainer cap. |

---

## Legal & usage notes

- These documents are **templates**, not legal advice. Have your contract reviewed by a qualified professional in your jurisdiction.
- The scope tracker and revision form are designed to be **referenced by your master services agreement (MSA)**. Add a line to your contract such as: *"Revisions are governed by the Revision Request Form; out-of-scope work is governed by the Change Order process in the Project Scope Tracker."*
- You may use these templates for unlimited client projects. Reselling or redistributing the templates themselves is not permitted.

---

## Suggested companion line

> *"Before we dive in, I'll send over a short welcome pack and a quick questionnaire. It takes about 15 minutes and it means we start the project with total clarity — no back-and-forth later."*

Say this in your sales call. It primes the client to complete onboarding fast.

---

*Client Onboarding Accelerator · v1.0 · Built for people who'd rather do great work than chase paperwork.*
