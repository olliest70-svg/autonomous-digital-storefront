# 35 Questions That Eliminate Scope Creep Before the Project Starts

**Project:** [PROJECT NAME]
**Client:** [CLIENT NAME]
**Completed by:** [NAME / ROLE]
**Date:** [DATE]

> **How to use this:** Send this link with your welcome page. It takes clients 15–20 minutes. Every answer feeds directly into your scope tracker and kickoff agenda. Anything left blank becomes an explicit "open item" — not an assumption.

---

## Section 1 — The Basics

| Question | Answer |
|----------|--------|
| Legal / trading name | |
| Website | |
| Primary contact (name, role, email, phone) | |
| Billing contact (if different) | |
| Preferred timezone & working hours | |
| How did you hear about us? | |

---

## Section 2 — Goals & Success

**2.1 In one or two sentences, what does success look like for this project?**

> *Example: "A new website that generates 20 qualified demo requests per month and finally looks like the category leader we are."*

```
[Client answer]
```

**2.2 What are the top 3 measurable outcomes you want?**

| # | Outcome | How we'll measure it | Target |
|---|---------|----------------------|--------|
| 1 | | | |
| 2 | | | |
| 3 | | | |

**2.3 What does "done" look like — and by when?**

```
[Client answer]
```

**2.4 What would make this project a failure in your eyes?**

```
[Client answer]
```

---

## Section 3 — Audience & Brand

**3.1 Who is your ideal customer?** (demographics, role, pain points)

```
[Client answer]
```

**3.2 Who are your top 3 competitors, and what do they do well?**

| Competitor | Website | What they do well | How we'll differ |
|------------|---------|-------------------|------------------|
| | | | |
| | | | |
| | | | |

**3.3 Do you have brand guidelines?** (logo files, fonts, colors, tone of voice)

- [ ] Yes — link: [LINK]
- [ ] Partially — see notes below
- [ ] No — we need help creating them

**3.4 Three words you'd use to describe your brand:**

```
[Client answer]
```

---

## Section 4 — Scope & Requirements

**4.1 Describe the project in your own words.**

```
[Client answer]
```

**4.2 What is explicitly IN scope?**

- [ ] [Deliverable 1]
- [ ] [Deliverable 2]
- [ ] [Deliverable 3]

**4.3 What is explicitly OUT of scope?** (things you do *not* want us to touch)

```
[Client answer]
```

**4.4 Are there any hard deadlines or fixed dates?** (launches, events, campaigns)

| Date | What happens | Non-negotiable? |
|------|--------------|-----------------|
| | | |

**4.5 Any technical, legal, or compliance constraints?** (accessibility, GDPR, brand approvals, etc.)

```
[Client answer]
```

---

## Section 5 — Assets & Access

**5.1 What assets already exist?**

| Asset type | Available? | Location / link |
|------------|-----------|-----------------|
| Logo & brand files | Yes / No | |
| Copy / content | Yes / No | |
| Photography / video | Yes / No | |
| Product / service data | Yes / No | |
| Existing website / CMS access | Yes / No | |
| Analytics / ad accounts | Yes / No | |

**5.2 Who will provide missing assets, and by when?**

```
[Client answer]
```

> ⚠️ **Note:** We never accept passwords over email. We'll send secure, individual access requests for every tool.

---

## Section 6 — Stakeholders & Decisions

**6.1 Who is involved in this project?**

| Name | Role | Involvement | Decision-maker? |
|------|------|-------------|-----------------|
| | | | Yes / No |
| | | | Yes / No |

**6.2 Who has final sign-off authority?**

```
[Client answer]
```

**6.3 How many rounds of feedback do you expect to need?**

- [ ] 1 round
- [ ] 2 rounds (recommended)
- [ ] 3+ rounds — *note: extra rounds are billed per our agreement*

---

## Section 7 — Budget & Logistics

**7.1 Is the project budget confirmed?**

- [ ] Yes — amount: [AMOUNT]
- [ ] Pending approval — expected by: [DATE]

**7.2 Preferred payment method & billing cycle:**

```
[Client answer]
```

**7.3 Anything else we should know before we start?**

```
[Client answer]
```

---

## For internal use only

| Field | Value |
|-------|-------|
| Questionnaire received | [DATE] |
| Missing items flagged | [LIST] |
| Scope tracker created | [DATE] |
| Kickoff booked | [DATE] |
| Risk notes | [NOTES] |
