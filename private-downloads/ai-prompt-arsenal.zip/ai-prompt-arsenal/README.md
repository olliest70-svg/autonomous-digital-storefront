# 500+ Prompts That Make ChatGPT & Claude Work Like a Pro Team

**The complete prompt library for creators, marketers, freelancers, and developers.**

Stop staring at a blank chat box. AI Prompt Arsenal is a battle-tested collection of **380+ production-ready prompts** organized into five focused playbooks. Every prompt includes clear variables, realistic examples, and — where it matters most — before/after demonstrations that show you exactly how to turn a weak request into a high-quality output.

---

## 📦 What's Inside

| File | Prompts | Best For |
|------|:-------:|----------|
| [`content-creation-prompts.md`](content-creation-prompts.md) | **80+** | Blog posts, newsletters, scripts, courses, books, repurposing |
| [`client-email-prompts.md`](client-email-prompts.md) | **60+** | Sales, onboarding, updates, difficult conversations, follow-ups |
| [`seo-copy-prompts.md`](seo-copy-prompts.md) | **60+** | Keyword clusters, meta tags, landing pages, product copy, audits |
| [`social-hook-prompts.md`](social-hook-prompts.md) | **60+** | Hooks, carousels, threads, video scripts, repurposing |
| [`coding-prompts.md`](coding-prompts.md) | **60+** | Code review, debugging, refactoring, tests, docs, architecture |
| **Total** | **320+** | Everything above |

> **Bonus:** Every file ends with a "Prompt Engineering Cheatsheet" section so you can adapt any prompt to your own voice, niche, and workflow.

---

## 🚀 How to Use This Arsenal

### 1. The 4-Step Prompt Formula
Every prompt in this library follows a repeatable structure. Learn it once, use it forever:

```
[ROLE]      → Who the AI should act as
[CONTEXT]   → The situation, audience, and constraints
[TASK]      → The specific deliverable you want
[FORMAT]    → How the output should be structured
```

### 2. Fill the Variables
Variables are written in `{{double_curly_braces}}`. Replace them with your specifics before sending.

**Example:**
```
You are a {{role}}. Write a {{content_type}} about {{topic}} for {{audience}}.
Tone: {{tone}}. Length: {{word_count}}. Include: {{must_include}}.
```

### 3. Iterate, Don't Restart
When output is close but not perfect, use the **refinement prompts** included in each section (e.g., "Make it 30% shorter without losing the core argument" or "Rewrite the opening with a contrarian angle").

---

## 🧠 The Golden Rules of Prompting

1. **Be specific about the audience.** "Small business owners" beats "people."
2. **Give a role.** "You are a senior copywriter who has written for SaaS" produces better copy than "write me copy."
3. **Show, don't just tell.** Paste an example of the style you want.
4. **Constrain the format.** Tables, bullets, word counts, and JSON all reduce cleanup.
5. **Ask for the reasoning first** on complex tasks, then the deliverable.
6. **Never accept v1.** Always run at least one refinement pass.

---

## 🛠️ Compatibility

These prompts work with any modern large language model, including:

- **ChatGPT** (GPT-4o, GPT-5 class)
- **Claude** (Sonnet, Opus)
- **Gemini** (Pro, Ultra)
- **Copilot, Perplexity, Llama, Mistral, and open-source models**

Prompts are model-agnostic. Where a prompt benefits from a specific capability (long context, code execution, web access), it's noted inline.

---

## 📁 Folder Structure

```
ai-prompt-arsenal/
├── README.md                     ← You are here
├── content-creation-prompts.md   ← 80+ writing & content prompts
├── client-email-prompts.md       ← 60+ client & sales email prompts
├── seo-copy-prompts.md           ← 60+ SEO & conversion copy prompts
├── social-hook-prompts.md        ← 60+ social media & hook prompts
└── coding-prompts.md             ← 60+ developer & engineering prompts
```

---

## ⚖️ License & Usage

- ✅ Use these prompts in your own work and client projects.
- ✅ Adapt, remix, and combine them freely.
- ✅ Teach them to your team.
- ❌ Do not resell or redistribute this library as-is.

---

## 💬 A Note on Quality

AI output is a **first draft, not a final draft**. These prompts are engineered to get you to 80% faster — you bring the last 20% that makes it yours. Always review for accuracy, brand voice, and factual claims before publishing.

**Now go build something great.** 🏗️
