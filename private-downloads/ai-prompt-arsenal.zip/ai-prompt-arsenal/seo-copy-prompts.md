# 60 Prompts That Rank on Google & Convert Readers Into Buyers

> **Part of the AI Prompt Arsenal.** Keyword research, on-page SEO, landing pages, product copy, ads, and audits — prompts that rank *and* convert.

**How to read this file:** Each prompt shows the **Role**, the **Prompt** (with `{{variables}}`), and where useful a **Before / After** or **Example Output**.

---

## Table of Contents

1. [Keyword Research & Strategy (1–12)](#1-keyword-research--strategy)
2. [On-Page SEO (13–24)](#2-on-page-seo)
3. [Meta Tags & Snippets (25–32)](#3-meta-tags--snippets)
4. [Landing Page Copy (33–42)](#4-landing-page-copy)
5. [Product & E-commerce Copy (43–50)](#5-product--e-commerce-copy)
6. [Ads & PPC Copy (51–56)](#6-ads--ppc-copy)
7. [SEO Audits & Technical (57–62)](#7-seo-audits--technical)
8. [Prompt Engineering Cheatsheet](#-prompt-engineering-cheatsheet)

---

## 1. Keyword Research & Strategy

### 1. Keyword Cluster Builder
**Role:** SEO strategist
```
You are an SEO strategist. Build a keyword cluster around the seed keyword "{{seed_keyword}}".
Output a table with columns: Keyword | Intent (informational/commercial/transactional/navigational) | Est. Difficulty (low/med/high) | Priority.
Group into 3–5 topic clusters. For each cluster, suggest a pillar page and 3–5 supporting articles.
```

### 2. Search Intent Analysis
```
Analyze the search intent for the keyword "{{keyword}}".
Tell me: the dominant intent, what searchers actually want, the content format that ranks (listicle, guide, product page, etc.), and 5 related questions.
Then recommend the best page type and angle to target it.
```

### 3. Long-Tail Keyword Generator
```
Generate 30 long-tail keyword variations for "{{topic}}" that a {{audience}} would search.
Include question keywords (how, what, why, best, vs), and mark the 10 with the best low-competition opportunity.
Output as a table with intent and suggested page title.
```

### 4. Competitor Keyword Gap
```
Here are my competitor's top pages: {{competitor_urls_or_topics}}.
Here are mine: {{my_topics}}.
Identify keyword/topic gaps I should target, ranked by likely ROI. Output a table: Gap Topic | Why It Matters | Suggested Content | Priority.
```

### 5. Topic Cluster Map
```
Create a topic cluster map for the pillar topic "{{pillar_topic}}".
List the pillar page, 8–12 cluster articles, and the internal linking structure (which cluster links to which).
Output as a table: Cluster Article | Target Keyword | Links To | CTA.
```

### 6. Keyword Prioritization Matrix
```
Score these keywords on a 1–5 scale for Volume, Intent Value, and Difficulty: {{keywords}}.
Calculate a priority score (Volume + Intent − Difficulty). Output a ranked table with a recommended action for each.
```

### 7. Featured Snippet Targets
```
For the keyword "{{keyword}}", identify the featured snippet format currently ranking (paragraph, list, table).
Then write a snippet-optimized answer: a 40–55 word paragraph, or a 5–8 item list, or a 3-column table — whichever matches.
```

### 8. People Also Ask Miner
```
Generate 15 "People Also Ask" style questions for "{{topic}}".
Group them by theme. For each, note whether it's a good blog post, FAQ entry, or video opportunity.
```

### 9. Seasonal / Trend Keyword Plan
```
Identify seasonal keyword opportunities for "{{niche}}" across the next 12 months.
Output a table: Month | Keyword | Why It Peaks | Content Deadline (publish 6–8 weeks early).
```

### 10. Local SEO Keyword Set
```
Generate local SEO keywords for a {{business_type}} in {{city}}.
Include: "near me" terms, neighborhood variations, service + location combos, and question keywords.
Output as a table with suggested page and priority.
```

### 11. Content Calendar From Keywords
```
Turn this keyword list into a 12-week content calendar: {{keywords}}.
Assign one piece per week, mixing pillar and cluster content. Output a table: Week | Title | Target Keyword | Format | CTA.
```

### 12. Keyword Cannibalization Check
```
I have these pages targeting overlapping keywords: {{pages_and_keywords}}.
Identify cannibalization risks, recommend which page should "own" each keyword, and suggest consolidation or differentiation.
```

---

## 2. On-Page SEO

### 13. On-Page Optimization
```
Optimize this page for the keyword "{{keyword}}".
Page content: {{paste_content}}.
Recommend: title tag, meta description, H1, H2 structure, keyword placement, internal links, and image alt text.
Report keyword density before and after. Do not keyword-stuff.
```

### 14. Title Tag Generator
```
Generate 10 SEO title tags for a page about "{{topic}}" targeting "{{keyword}}".
Keep each under 60 characters, front-load the keyword, and include a benefit or hook.
Mark the 3 best and explain why.
```

### 15. Heading Structure Audit
```
Review this page's heading structure for SEO and readability: {{paste_headings}}.
Flag: missing H1, skipped levels, keyword gaps, and vague headings.
Output a corrected H1–H3 hierarchy.
```

### 16. Internal Linking Plan
```
For a new article about "{{topic}}", suggest 8 internal links from my existing content.
Existing content: {{list_of_pages}}.
For each: the source page, anchor text, and where in the article to place it. Output as a table.
```

### 17. Image Alt Text Generator
```
Write SEO-friendly alt text for these images on a page about "{{topic}}": {{image_descriptions}}.
Keep each under 125 characters, descriptive, and natural. Include the keyword only where it genuinely fits.
```

### 18. Content Refresh for Rankings
```
This page is losing rankings for "{{keyword}}": {{paste_content}}.
Analyze why (thin content, outdated info, intent mismatch, weak structure) and produce a refresh plan: what to add, cut, update, and restructure.
```

### 19. FAQ Schema Content
```
Write 8 FAQ questions and answers for a page about "{{topic}}" suitable for FAQ schema markup.
Each answer: 40–60 words, direct, snippet-friendly. Output as a Q&A list.
```

### 20. Blog Post SEO Checklist
```
Create a 15-point on-page SEO checklist for publishing a blog post targeting "{{keyword}}".
Include checks for title, meta, headings, keyword usage, internal/external links, images, schema, and readability.
Format as a checkbox list.
```

### 21. Content Brief (SEO)
```
Write an SEO content brief for "{{keyword}}".
Include: search intent, target word count, H2/H3 outline, entities to mention, questions to answer, internal links, meta title, and meta description.
Make it executable by a freelance writer with no follow-up questions.
```

### 22. Keyword Mapping to Pages
```
Map these keywords to the most appropriate page on my site: {{keywords}} and {{pages}}.
Output a table: Keyword | Target Page | Intent | Current Status (optimized/needs work/missing).
Flag any keyword with no suitable page.
```

### 23. E-E-A-T Enhancement
```
Review this content for E-E-A-T signals (Experience, Expertise, Authoritativeness, Trust): {{paste_content}}.
Suggest specific additions: author bio, credentials, sources, first-hand experience, and trust elements.
Output a prioritized list of improvements.
```

### 24. On-Page SEO — Before/After
**Before (weak title + intro):**
> **Title:** Our Services
> **Intro:** We are a company that provides many services to clients. We have been in business for many years and offer quality work.

**After (optimized):**
> **Title:** Web Design Services for SaaS Startups | Acme Studio
> **Intro:** Need a website that converts trial users into paying customers? We design and build high-converting sites for SaaS startups — average lift of 22% in signup rate across 40+ projects.

**Prompt:**
```
Rewrite this page's title and intro to be SEO-optimized for "{{keyword}}" and conversion-focused. Keep it honest and specific.
Content: {{paste_content}}
```

---

## 3. Meta Tags & Snippets

### 25. Meta Description Generator
```
Write 5 meta descriptions for a page about "{{topic}}" targeting "{{keyword}}".
Each: 150–160 characters, includes the keyword, has a benefit and a soft CTA.
Mark the best one.
```

### 26. SERP Snippet Preview
```
Write a title tag (≤60 chars) and meta description (≤160 chars) for "{{page_topic}}" targeting "{{keyword}}".
Then show how the SERP snippet would look, and note the character counts.
```

### 27. OG / Social Meta Tags
```
Write Open Graph and Twitter Card meta tags for a page about "{{topic}}".
Include: og:title, og:description, og:image (describe the ideal image), twitter:card, twitter:title, twitter:description.
Optimize for click-through on social.
```

### 28. Breadcrumb & URL Slug
```
Suggest an SEO-friendly URL slug and breadcrumb structure for a page about "{{topic}}" under the section "{{section}}".
Give 3 slug options, explain the tradeoffs, and recommend one.
```

### 29. Snippet Bait Paragraph
```
Write a 45-word paragraph optimized to win the featured snippet for "{{question_keyword}}".
Answer directly in the first sentence, then add one supporting detail. No fluff.
```

### 30. Meta Description — Before/After
**Before:**
> Learn about our project management software. Click here to read more.

**After:**
> Project management software for freelancers — plan projects, track time, and invoice clients in one place. Start free, no card required.

**Prompt:**
```
Rewrite this meta description to be compelling and keyword-rich in under 160 characters. Add a benefit and a CTA.
Meta: {{paste_meta}}
```

### 31. Multi-Page Meta Pack
```
Write title tags and meta descriptions for these {{n}} pages: {{page_list}}.
Keep titles ≤60 chars and descriptions ≤160 chars. Ensure each targets a distinct keyword and avoids duplication.
Output as a table.
```

### 32. CTR Optimization
```
This page ranks on page 1 but has a low CTR for "{{keyword}}": current title "{{title}}", description "{{description}}".
Suggest 5 title/description combos designed to increase clicks. Explain the psychological trigger in each.
```

---

## 4. Landing Page Copy

### 33. Landing Page Full Copy
**Role:** Direct-response copywriter
```
You are a direct-response copywriter. Write full landing page copy for {{offer}} targeting {{audience}}.
Sections: hero (headline + subhead + CTA), problem, solution, benefits (3–5), how it works (3 steps), social proof, objections/FAQ, final CTA.
Tone: {{tone}}. Emphasize outcomes over features. Include 3 headline options.
```

### 34. Hero Section Copy
```
Write 5 hero section variations for {{offer}}.
Each: headline (≤10 words), subheadline (≤20 words), and CTA button text.
Vary the angle: outcome, pain, speed, social proof, and curiosity.
```

### 35. Value Proposition
```
Write a clear value proposition for {{offer}} targeting {{audience}}.
Format: "We help [audience] [achieve outcome] without [pain]."
Give 5 versions and mark the clearest.
```

### 36. Benefits vs Features
```
Turn these features into customer benefits: {{features}}.
For each: the feature, the benefit ("so you can…"), and a proof point or example.
Output as a table.
```

### 37. Objection-Crushing Section
```
List the top 7 objections a {{audience}} would have about buying {{offer}}.
For each: the objection, a reframe, and a proof element (testimonial, guarantee, data).
Output as a table.
```

### 38. Social Proof Section
```
Write 5 testimonial-style social proof blurbs for {{offer}}.
Each should follow: specific result → before state → after state → one-line endorsement.
Keep each under 40 words. Add a "results may vary" note.
```

### 39. CTA Copy Bank
```
Generate 15 CTA button texts for {{offer}}.
Mix: action-led, benefit-led, low-commitment, and urgency styles.
Keep each under 5 words. Mark the 3 strongest for a cold audience.
```

### 40. Pricing Page Copy
```
Write pricing page copy for {{product}} with tiers {{tiers}}.
Include: a headline, a "which plan is right for you" guide, feature comparison table, FAQ, and guarantee.
Reduce decision friction and anchor the recommended plan.
```

### 41. Landing Page — Before/After
**Before (weak hero):**
> **Headline:** Welcome to Our Platform
> **Subhead:** We offer a great solution for your business needs.

**After (strong):**
> **Headline:** Turn Trial Users Into Paying Customers
> **Subhead:** The onboarding platform SaaS teams use to lift activation by 30% in 60 days — without hiring more engineers.
> **CTA:** Start Free Trial

**Prompt:**
```
Rewrite this hero section to be specific, outcome-driven, and audience-aware. Give 3 versions.
Hero: {{paste_hero}}
```

### 42. Above-the-Fold Audit
```
Review this landing page's above-the-fold content: {{paste_content}}.
Assess: clarity of value prop, audience match, CTA visibility, and load-time concerns.
Give 5 prioritized fixes.
```

---

## 5. Product & E-commerce Copy

### 43. Product Description
```
Write a product description for {{product}}.
Include: a benefit-led headline, a 2-sentence overview, 5 bullet-point benefits, specs, and a "who it's for" line.
Tone: {{tone}}. Avoid generic adjectives. Make it scannable.
```

### 44. Amazon / Marketplace Listing
```
Write an Amazon-style listing for {{product}}.
Include: title (≤200 chars, keyword-rich), 5 bullet points (benefit + feature), a product description (A+ style), and backend keywords.
Optimize for both search and conversion.
```

### 45. Product Title Optimizer
```
Rewrite this product title to be keyword-rich and click-worthy: "{{current_title}}".
Give 5 options under 200 characters, front-loading the primary keyword. Mark the best for SEO and the best for CTR.
```

### 46. Product Bullet Points
```
Write 6 benefit-driven bullet points for {{product}}.
Each: a bolded benefit lead-in, then a supporting feature/spec. Keep each under 25 words.
Order by importance to {{audience}}.
```

### 47. Collection / Category Page Copy
```
Write category page copy for a {{category}} collection at {{store}}.
Include: an SEO intro (80–120 words), buying guidance, and 3 filter/sort suggestions.
Tone: {{tone}}. Help shoppers decide.
```

### 48. Product FAQ
```
Write 8 product FAQs for {{product}} covering: sizing/specs, usage, care, shipping, returns, and compatibility.
Each answer: 30–50 words, direct, reassuring. Output as a Q&A list.
```

### 49. Upsell / Bundle Copy
```
Write copy for an upsell offering {{bundle}} alongside {{main_product}}.
Explain the added value, the savings, and why buying together makes sense.
Include a headline, 3 bullets, and CTA. Under 100 words.
```

### 50. Product Description — Before/After
**Before:**
> This is a high-quality water bottle made of stainless steel. It is durable and keeps drinks cold. Great for everyone.

**After:**
> **Ice-cold water, 24 hours a day.**
> The 32oz Glacier bottle keeps drinks cold for 24 hours (or hot for 12) thanks to double-wall vacuum insulation. Fits standard cup holders, survives drops, and never sweats on your desk.
> - **24-hour cold / 12-hour hot** — double-wall vacuum insulation
> - **Fits your life** — standard cup-holder base, leak-proof lid
> - **Built to last** — 18/8 stainless steel, BPA-free
> *Perfect for commuters, gym-goers, and anyone tired of lukewarm water.*

**Prompt:**
```
Rewrite this product description to be benefit-led, specific, and scannable. Add a headline, bullets, and a "who it's for" line.
Description: {{paste_description}}
```

---

## 6. Ads & PPC Copy

### 51. Google Search Ads
```
Write 3 Google Responsive Search Ad variations for "{{keyword}}" promoting {{offer}}.
For each: 5 headlines (≤30 chars) and 3 descriptions (≤90 chars).
Include the keyword in at least 2 headlines. Add a clear CTA and a benefit.
```

### 52. Facebook / Meta Ad Copy
```
Write 3 Facebook ad variations for {{offer}} targeting {{audience}}.
Each: primary text (under 125 words), headline (≤40 chars), and description (≤30 chars).
Use different angles: pain, social proof, and curiosity. Include a hook in the first line.
```

### 53. Ad Angle Brainstorm
```
Generate 10 ad angles for {{offer}} targeting {{audience}}.
For each: the angle, the hook, and the emotional driver (fear, desire, status, convenience, etc.).
Mark the 3 most likely to work for a cold audience.
```

### 54. LinkedIn Ad Copy
```
Write a LinkedIn ad for {{offer}} targeting {{job_title}} at {{company_type}}.
Include: intro text (under 150 words), headline, and CTA. Lead with a business outcome, not a feature.
```

### 55. Ad Copy — Before/After
**Before:**
> Buy our software today! It's the best tool for your business. Click now for a special offer!

**After:**
> **Still tracking projects in a spreadsheet?**
> Freelancers using Acme cut admin time by 6 hours a week — invoicing, time tracking, and client updates in one place.
> Start free. No card required.

**Prompt:**
```
Rewrite this ad copy to lead with a specific pain or outcome, add proof, and end with a low-friction CTA. Give 3 versions.
Ad: {{paste_ad}}
```

### 56. Ad A/B Test Plan
```
Create an A/B test plan for these ad variations: {{variations}}.
Define: the hypothesis, the variable to test, the primary metric, sample size guidance, and how to interpret results.
Output as a table.
```

---

## 7. SEO Audits & Technical

### 57. Content Audit
```
Audit this content inventory: {{list_of_pages_with_metrics}}.
Categorize each page as: keep, update, consolidate, or delete. Justify each.
Output a table: Page | Traffic | Action | Reason | Priority.
```

### 58. Technical SEO Checklist
```
Create a technical SEO audit checklist for a {{site_type}} website.
Cover: crawlability, indexation, site speed, mobile, structured data, canonical tags, redirects, and sitemaps.
Format as a prioritized checklist with a "how to check" note for each.
```

### 59. Schema Markup Generator
```
Generate JSON-LD schema markup for a {{page_type}} page about "{{topic}}".
Include all relevant properties (e.g. Article, Product, FAQPage, LocalBusiness). Output valid JSON-LD in a code block.
```

### 60. Redirect Plan
```
I'm restructuring my site. Here's the old → new URL mapping: {{url_mapping}}.
Identify any missing redirects, potential chains, and pages that should 410 instead of redirect.
Output a clean redirect table.
```

### 61. Site Speed Recommendations
```
Review these page performance notes: {{performance_notes}}.
Recommend prioritised fixes for Core Web Vitals (LCP, INP, CLS), images, scripts, and caching.
Output as a table: Issue | Impact | Fix | Effort.
```

### 62. SEO Report Summary
```
Turn these raw SEO metrics into an executive summary for a client: {{metrics}}.
Include: wins, concerns, key opportunities, and next month's priorities.
Write it in plain English for a non-technical stakeholder. Under 300 words.
```

---

## 🧰 Prompt Engineering Cheatsheet

### The SEO Copy C.O.R.E. Framework
| Letter | Meaning | Example |
|--------|---------|---------|
| **C** | Customer | "Written for a busy marketing manager." |
| **O** | Objective | "Rank for 'email automation' and drive demo signups." |
| **R** | Restriction | "≤60 char title, no keyword stuffing." |
| **E** | Evidence | "Include a stat or proof point per section." |

### Power Phrases for SEO Prompts
- **To avoid stuffing:** "Use the keyword naturally; report density before and after."
- **To match intent:** "First state the search intent, then write to it."
- **To get options:** "Give 5 options ranked by likely CTR."
- **To stay honest:** "Do not invent statistics. Flag anything unverified."
- **To convert:** "Every section must answer 'so what?' for the reader."

### SEO Copy Rules of Thumb
1. **Intent first.** Match the format that already ranks.
2. **One keyword per page.** Avoid cannibalization.
3. **Front-load.** Put the keyword early in titles and first sentences.
4. **Write for humans, optimize for bots.** Never the reverse.
5. **Snippet-friendly.** Answer directly in the first sentence.

### Conversion Copy Rules of Thumb
1. **Lead with the outcome,** not the feature.
2. **Specificity sells.** "Cut admin time by 6 hours" beats "save time."
3. **One page, one action.** Remove competing CTAs.
4. **Handle objections on the page.** Don't make them email you.
5. **Proof everywhere.** Numbers, names, and results.

---

*End of SEO & Conversion Copy Prompts — 62 prompts. Part of the AI Prompt Arsenal.*
