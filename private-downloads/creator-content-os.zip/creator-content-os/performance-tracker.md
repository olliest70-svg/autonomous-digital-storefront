# Performance Tracker

**The feedback loop of Creator Content OS.** Log a small, fixed set of metrics weekly. Review monthly. Turn findings into explicit "make more of X" decisions. No more guessing.

---

## Table of Contents
1. [The Tracking Philosophy](#1-the-tracking-philosophy)
2. [North-Star Metrics](#2-north-star-metrics)
3. [The Weekly Log Template](#3-the-weekly-log-template)
4. [The Monthly Dashboard](#4-the-monthly-dashboard)
5. [The Review Rituals](#5-the-review-rituals)
6. [Decision Rules](#6-decision-rules)
7. [Content Scorecard](#7-content-scorecard)
8. [Benchmarks & Diagnostics](#8-benchmarks--diagnostics)

---

## 1. The Tracking Philosophy

> **Log before you judge. Decide from data, not vibes.**

Three rules:
1. **Track few metrics, consistently.** 5–8 numbers, every week, beats 30 numbers sporadically.
2. **Separate vanity from value.** Likes are vanity; saves, subscribers, and replies are value.
3. **Every metric must drive a decision.** If a number never changes what you do, stop tracking it.

### What to Track vs. Ignore

| Track ✅ | Ignore ❌ |
|---|---|
| Saves / bookmarks | Raw impressions alone |
| Subscriber/follower growth | Follower count in isolation |
| Email open & click rate | "Going viral" as a goal |
| Watch time / retention | Likes |
| Replies & DMs | Shares without context |
| Conversion (clicks, downloads) | Aesthetic metrics |

---

## 2. North-Star Metrics

Pick **three** north-star metrics — one per stage of your funnel. Everything else is supporting.

### The Funnel Framework

```
   REACH  ──────►  RESONANCE  ──────►  RELATIONSHIP
 (do they see it?) (does it land?)   (do they come back?)
```

| Stage | North-star metric | Why it matters |
|---|---|---|
| **Reach** | Views / impressions (by format) | Are you being seen? |
| **Resonance** | Saves + retention % | Does the content land? |
| **Relationship** | Subscribers / email list | Are they coming back? |

### Choosing Your Three (Worked Example)

| Creator type | Reach | Resonance | Relationship |
|---|---|---|---|
| YouTuber | Views | Avg. view duration | Subscribers |
| Newsletter writer | Open rate | Click rate | List growth |
| LinkedIn creator | Impressions | Saves + comments | Profile follows |
| Short-form creator | Views | Watch-through % | Follows |

> **Rule:** Only ONE of your three can be a vanity metric, and even then, only as a leading indicator.

---

## 3. The Weekly Log Template

Fill this every **Friday (10 min)**. Keep it in a spreadsheet or Notion database.

### Weekly Metrics Log

| Week | Platform | Asset | Format | Views | Saves | Comments | New Subs | Clicks | Notes |
|---|---|---|---|---|---|---|---|---|---|
| W41 | YouTube | 4-loop engine | Long | 4,210 | — | 87 | 214 | 340 | Best hook so far |
| W41 | LinkedIn | Pillar map | Carousel | 12,400 | 410 | 63 | 38 | 90 | Saves spiked |
| W41 | TikTok | Stop starting from zero | Short | 28,900 | 1,120 | 140 | 96 | 40 | Trend audio helped |
| W41 | Newsletter | The Capture Problem | Essay | 3,100 | — | 22 | 51 | 180 | Open 48% |

### Weekly Summary Row

| Metric | This week | Last week | Δ | Target |
|---|---|---|---|---|
| Total views | 48,610 | 41,200 | +18% | 45,000 |
| Total saves | 1,530 | 1,100 | +39% | 1,200 |
| New subscribers | 399 | 310 | +29% | 350 |
| Newsletter opens | 48% | 46% | +2pt | 45% |

### Logging Rules
- **Log within 72 hours of publishing.** Data stabilizes; memory doesn't.
- **One row per asset.** Never aggregate before logging.
- **Always add a "Notes" column.** Context explains anomalies.
- **Log the flagship AND its derivatives.** This is how you compare formats.

---

## 4. The Monthly Dashboard

Roll up four weeks into a single view. This is your decision-making surface.

### Monthly Dashboard Template — October 2026

| Metric | Oct total | Sep total | Δ | Goal | Status |
|---|---|---|---|---|---|
| **Reach** | | | | | |
| Total views | 182,400 | 151,000 | +21% | 160,000 | ✅ |
| Avg. views/asset | 6,514 | 5,393 | +21% | 5,500 | ✅ |
| **Resonance** | | | | | |
| Total saves | 6,120 | 4,400 | +39% | 5,000 | ✅ |
| Avg. retention | 52% | 47% | +5pt | 50% | ✅ |
| **Relationship** | | | | | |
| New subscribers | 1,540 | 1,210 | +27% | 1,300 | ✅ |
| Email list size | 8,940 | 7,400 | +21% | 8,500 | ✅ |
| **Conversion** | | | | | |
| Product clicks | 1,320 | 980 | +35% | 1,000 | ✅ |
| Conversion rate | 2.4% | 2.1% | +0.3pt | 2.5% | 🟡 |

### By-Format Breakdown

| Format | Assets | Total views | Avg. saves | Avg. retention | Verdict |
|---|---|---|---|---|---|
| Long-form | 4 | 16,840 | 210 | 52% | Keep — authority driver |
| Carousel | 4 | 49,600 | 410 | — | Double down — highest saves |
| Short | 12 | 96,000 | 340 | 61% | Scale — best reach |
| Essay | 4 | 12,400 | — | 48% open | Keep — relationship driver |
| Thread | 4 | 7,560 | 120 | — | Test more |

### By-Pillar Breakdown

| Pillar | Assets | Avg. views | Avg. saves | Verdict |
|---|---|---|---|---|
| P1 Systems | 14 | 8,200 | 380 | Core — keep 50% mix |
| P2 Tools | 6 | 5,100 | 290 | Solid — keep 25% |
| P3 Mindset | 5 | 6,900 | 410 | Underused — increase |
| P4 BTS | 3 | 3,200 | 90 | Low reach, high trust — keep |

---

## 5. The Review Rituals

### Weekly Review (Friday, 10 min)
1. Log the week's metrics.
2. Note the single best-performing asset and *why*.
3. Note the single worst and *why*.
4. Flag one thing to test next week.

### Monthly Review (Last Friday, 60 min)
1. **Pull the dashboard** (10 min).
2. **Identify top 3 and bottom 3 assets** (10 min).
3. **Diagnose patterns** — format, pillar, hook, topic (20 min).
4. **Make 3 decisions** using the rules in Section 6 (15 min).
5. **Update next month's calendar** to reflect decisions (5 min).

### Quarterly Review (Half day)
1. Reassess pillars against performance.
2. Kill the lowest-performing pillar or format.
3. Set next quarter's goal and theme.
4. Refresh the brand voice if it's drifted.

### Review Output Template

```markdown
## Monthly Review — October 2026

**Top 3 assets:**
1. TikTok "Stop starting from zero" — 28.9k views, 1.1k saves
2. LinkedIn "Pillar map" carousel — 12.4k views, 410 saves
3. YT "4-loop engine" — 4.2k views, 214 subs

**Bottom 3 assets:**
1. Thread "Tool stack" — 1.2k views
2. Blog "Note app review" — 400 views
3. Reel "Desk tour" — 2.1k views

**Patterns:**
- Carousels over-index on saves (2x average)
- Threads underperform — low effort, low return
- Mindset pillar has highest saves per view

**3 decisions for November:**
1. Increase carousels from 4 → 6/month
2. Pause threads; reallocate time to carousels
3. Test 2 more mindset-pillar pieces
```

---

## 6. Decision Rules

Pre-commit to these rules so you don't rationalize. When a pattern appears, act.

| If... | Then... |
|---|---|
| A format beats average by **>30%** on your north-star | Increase its share next month |
| A format underperforms by **>30%** for 2 months | Pause or kill it |
| A pillar drives **>40%** of saves | Increase its mix |
| A pillar drives **<10%** of saves for a quarter | Retire it |
| A hook style wins repeatedly | Add it to your swipe file |
| An asset gets **0 saves** and low retention | Stop making that type |
| Email list grows **<5%/month** for 2 months | Add a lead magnet or CTA |
| Conversion drops 2 months running | Audit the offer, not the content |

### The "Two-Month Rule"
Never change strategy based on one week. A pattern must repeat for **two consecutive months** before you make a structural change. Exception: obvious wins (a format that 3x's your average) — scale those immediately.

---

## 7. Content Scorecard

Score each published asset 0–100 to rank quality independent of reach (reach can be luck; quality compounds).

| Criterion | Weight | Score (0–10) | Weighted |
|---|---|---|---|
| Hook strength | 20% | 9 | 18 |
| Value density | 20% | 8 | 16 |
| Voice match | 15% | 9 | 13.5 |
| Native fit | 15% | 8 | 12 |
| CTA clarity | 10% | 7 | 7 |
| Repurposing potential | 10% | 9 | 9 |
| Production quality | 10% | 8 | 8 |
| **Total** | **100%** | | **83.5** |

### Scorecard Bands

| Score | Grade | Action |
|---|---|---|
| 90–100 | A | Template it; make more like this |
| 80–89 | B | Strong; minor tweaks |
| 70–79 | C | Review hook and value density |
| <70 | D | Diagnose before repeating |

> **Use it this way:** Score *before* you see the numbers. Then compare score vs. reach. High score + low reach = distribution problem. Low score + high reach = lucky hook; fix the substance.

---

## 8. Benchmarks & Diagnostics

### Rough Benchmarks (directional, not gospel)

| Metric | Weak | Average | Strong |
|---|---|---|---|
| Short-form watch-through | <40% | 50–60% | >70% |
| Long-form retention | <35% | 45–55% | >60% |
| Newsletter open rate | <30% | 35–45% | >50% |
| Newsletter click rate | <2% | 3–5% | >7% |
| Carousel save rate | <1% | 2–4% | >5% |
| Follower→email conversion | <1% | 2–4% | >5% |

### Diagnostic Table

| Symptom | Likely cause | Fix |
|---|---|---|
| High views, low saves | Entertaining but not useful | Add a takeaway/framework |
| Low views, high saves | Great content, weak hook | Rewrite the hook |
| High opens, low clicks | Weak CTA or offer | Clarify the CTA |
| High reach, no growth | No reason to follow | Add a follow prompt + series |
| Good retention, low subs | No end-screen CTA | Add subscribe moment |
| Saves high, shares low | Not opinionated enough | Add a point of view |

### The One-Number Health Check
If you only track one thing, track **saves + subscribers per asset**. It combines resonance and relationship — the two things that actually compound.

---

## The Tracker Loop

```
   PUBLISH ──► LOG (weekly) ──► ROLL UP (monthly)
      ▲                              │
      │                              ▼
      │                       DIAGNOSE PATTERNS
      │                              │
      │                              ▼
      │                       APPLY DECISION RULES
      │                              │
      └──────── UPDATE CALENDAR ◄────┘
```

**Next file:** `brand-voice-swipe-file.md` — the tone layer that keeps every asset recognizably *you*.
