# Idea Pipeline

**The intake system of Creator Content OS.** Every idea enters through one door, gets scored, and earns its way to a production slot. No more "I have 200 notes and nothing to post."

---

## Table of Contents
1. [The Pipeline Stages](#1-the-pipeline-stages)
2. [Capture: The Inbox](#2-capture-the-inbox)
3. [The Idea Scoring Rubric](#3-the-idea-scoring-rubric)
4. [The Idea Card Template](#4-the-idea-card-template)
5. [Triage: The Weekly Sort](#5-triage-the-weekly-sort)
6. [The Backlog Board](#6-the-backlog-board)
7. [Idea Generation Engines](#7-idea-generation-engines)
8. [Pipeline Health Metrics](#8-pipeline-health-metrics)

---

## 1. The Pipeline Stages

Ideas move left to right. An idea only advances when it earns it.

```
┌─────────┐   ┌────────┐   ┌──────────┐   ┌───────────┐   ┌──────────┐   ┌────────┐
│ CAPTURE │ → │ SCORE  │ → │ SCHEDULE │ → │  PRODUCE  │ → │ PUBLISH  │ → │ REVIEW │
│  inbox  │   │ rubric │   │ calendar │   │  create   │   │  ship    │   │ learn  │
└─────────┘   └────────┘   └──────────┘   └───────────┘   └──────────┘   └────────┘
   daily        weekly        weekly         daily          weekly        monthly
```

| Stage | Where it lives | Who moves it | Trigger |
|---|---|---|---|
| **Capture** | Inbox file | You (instantly) | Any spark |
| **Score** | Inbox → scored | You (Monday) | Weekly triage |
| **Schedule** | Calendar | You (Monday) | Slot opens |
| **Produce** | Pillars folder | You / VA | Slot date nears |
| **Publish** | Published folder | You / VA | Scheduled day |
| **Review** | Tracker | You (monthly) | Month end |

---

## 2. Capture: The Inbox

**Rule: capture is frictionless. Judging comes later.**

One inbox. One place. No sorting at capture time.

### Inbox Options
- A single note: `01-ideas/2026-10-inbox.md`
- A voice-memo folder + weekly transcription
- A "quick capture" shortcut on your phone

### Capture Prompts (When You Have Nothing)
- What question did someone ask me this week?
- What did I learn the hard way?
- What do I believe that most people in my niche don't?
- What mistake do I see beginners make constantly?
- What did I change my mind about recently?

### The 30-Second Capture Format
Don't write essays. Capture the seed:

```
[ ] Idea: <one line>
    Why now: <one line>
    Source: <where it came from>
```

**Example:**
```
[ ] Idea: "Most creators don't have an idea problem, they have a filtering problem"
    Why now: Comment on yesterday's post said exactly this
    Source: YouTube comment, Oct 12
```

---

## 3. The Idea Scoring Rubric

Score every idea on **5 dimensions, 1–4 points each** (max 20). This replaces gut-feel with a repeatable decision.

| Dimension | Question | 1 (weak) | 4 (strong) |
|---|---|---|---|
| **Audience Fit** | Does my audience care? | Tangential | Core problem |
| **Uniqueness** | Can only *I* say this? | Everyone says it | Unique angle/proof |
| **Effort vs. Value** | Is the ROI worth it? | High effort, low payoff | High payoff, low effort |
| **Timeliness** | Is now the right time? | Evergreen, no urgency | Timely hook |
| **Repurposing Potential** | Can it become 5+ assets? | One-off | Deep, derivable |

### Score Bands

| Total | Band | Action |
|---|---|---|
| **17–20** | 🔥 Flagship | Schedule as a pillar piece immediately |
| **13–16** | ✅ Strong | Schedule as a derivative or secondary |
| **9–12** | 🟡 Maybe | Park in backlog; revisit in 30 days |
| **5–8** | 🔴 Weak | Kill it (or merge into a stronger idea) |

### Worked Scoring Example

| Idea | Fit | Unique | Effort/Value | Timely | Repurpose | **Total** | Band |
|---|---|---|---|---|---|---|---|
| "The 4-loop content engine" | 4 | 4 | 4 | 3 | 4 | **19** | 🔥 Flagship |
| "My favorite note-taking app" | 3 | 1 | 4 | 2 | 2 | **12** | 🟡 Maybe |
| "Why I quit daily posting" | 4 | 3 | 3 | 4 | 3 | **17** | 🔥 Flagship |
| "5 productivity hacks" | 2 | 1 | 3 | 1 | 2 | **9** | 🟡 Maybe |

> **Insight from the example:** The generic listicle scores low on uniqueness and fit even though it's easy. The scoring system protects you from publishing filler.

### Scoring Shortcut (When in a Hurry)
Score only **Fit + Uniqueness + Repurposing**. If the sum is under 8/12, park it. If 10+, schedule it.

---

## 4. The Idea Card Template

Promote a scored idea into a full card before it hits the calendar.

```markdown
### Idea #042 — The 4-Loop Content Engine

- **Pillar:** Systems & Workflows (P1)
- **Score:** 19/20 🔥 Flagship
- **Core promise:** "You don't need more ideas, you need a system that filters them."
- **Hook options:**
  1. "Most creators quit because they run four disconnected workflows."
  2. "I almost quit content. Then I built one engine with four loops."
- **Key points:**
  - Loop 1: Idea pipeline
  - Loop 2: Editorial calendar
  - Loop 3: Repurposing workflow
  - Loop 4: Performance tracker
- **Proof / story:** My own 6-month data — posts went from 2/week to 9/week
- **CTA:** Download the Content OS
- **Repurposing tree:** YT → newsletter, carousel, 3 shorts, thread
- **Assets needed:** Whiteboard diagram, screen recording, B-roll
- **Target slot:** Week of Oct 13, Tuesday flagship
```

### Card Quality Checklist
- [ ] One clear promise (not three).
- [ ] At least two hook options.
- [ ] A proof element (data, story, or example).
- [ ] A defined CTA.
- [ ] A repurposing tree sketched.

---

## 5. Triage: The Weekly Sort

Run this every **Monday (10 min)**. It's the single highest-leverage habit in the system.

### The Triage Flow

```
For each new idea in the inbox:
  1. Score it (30 seconds)
  2. Route it:
       🔥 Flagship → assign to next open flagship slot
       ✅ Strong   → add to backlog as a derivative
       🟡 Maybe    → park with a revisit date
       🔴 Weak     → delete (yes, really)
```

### Triage Rules
- **Cap the backlog at 50 ideas.** If it's full, you must kill one to add one.
- **No idea older than 90 days survives without a revisit.** Stale ideas decay.
- **Promote a maximum of 3 ideas per week.** More than that and you're over-committing.
- **Merge duplicates.** Two half-ideas often make one great one.

### Triage Log (keep a running record)

| Date | Idea | Score | Routed to | Notes |
|---|---|---|---|---|
| Oct 13 | 4-loop engine | 19 | Flagship Wk 2 | Strong, lead the month with it |
| Oct 13 | Note app review | 12 | Backlog | Revisit after tool roundup |
| Oct 13 | Quit daily posting | 17 | Flagship Wk 3 | Pair with burnout angle |

---

## 6. The Backlog Board

The backlog is a **ranked queue**, not a graveyard. Sort by score, then by timeliness.

| Rank | Idea | Score | Pillar | Format | Revisit by | Status |
|---|---|---|---|---|---|---|
| 1 | Why I quit daily posting | 17 | P3 | Essay | Oct 20 | Scheduled |
| 2 | Content OS walkthrough | 16 | P1 | YT | Oct 27 | Backlog |
| 3 | Tool stack 2026 | 15 | P2 | Carousel | Nov 3 | Backlog |
| 4 | Note app review | 12 | P2 | Short | Nov 10 | Parked |
| 5 | Productivity hacks | 9 | P3 | Short | Nov 17 | Parked |

### Backlog Hygiene
- **Review monthly.** Anything parked twice gets killed.
- **Re-score on revisit.** Timeliness changes; a 12 can become a 16.
- **Keep it visible.** A backlog you don't look at is just clutter.

---

## 7. Idea Generation Engines

When the pipeline runs dry, run one of these engines. Each reliably produces 5–10 scored ideas.

| Engine | How it works | Output |
|---|---|---|
| **The Question Miner** | Collect every question from comments/DMs/emails for a week | 1 idea per recurring question |
| **The Repurpose Engine** | Take a top performer, extract 5 sub-angles | 5 derivative ideas |
| **The Belief Flip** | List what your niche believes; argue the opposite | 3–5 contrarian ideas |
| **The Mistake List** | List 10 mistakes beginners make | 10 teaching ideas |
| **The Story Bank** | List 10 turning points in your journey | 10 narrative ideas |
| **The Format Swap** | Take 5 old ideas, change the format | 5 fresh ideas |
| **The Trend Scan** | Scan your niche weekly for news | 2–3 timely ideas |

### The Question Miner (Worked Example)

| Question heard | Turned into | Score |
|---|---|---|
| "How do you decide what to post?" | "The 5-minute idea scoring ritual" | 18 |
| "How often should I post?" | "The cadence math that stopped my burnout" | 17 |
| "Do I need to be on every platform?" | "Pick 3 slots, ignore the rest" | 16 |

---

## 8. Pipeline Health Metrics

Track these monthly to know if your pipeline is healthy.

| Metric | Healthy range | What it tells you |
|---|---|---|
| **Inbox inflow** | 10–20 ideas/week | You're capturing enough |
| **Scoring rate** | 100% of inbox | Nothing is rotting unscored |
| **Promotion rate** | 20–30% | You're filtering, not hoarding |
| **Backlog size** | 20–50 | Healthy buffer, not a graveyard |
| **Idea → publish time** | 7–21 days | Pipeline isn't stalled |
| **Kill rate** | 30–50% | You're being ruthless enough |

### Warning Signs

| Symptom | Diagnosis | Fix |
|---|---|---|
| Inbox empty | Not capturing | Use capture prompts daily |
| Inbox huge, backlog huge | Not scoring | Force a triage session |
| Backlog full of 9s | Scoring too leniently | Raise the kill threshold |
| Same ideas repeating | Not enough input | Run a generation engine |

---

## The Pipeline in One Diagram

```
DAILY                    WEEKLY (Mon)              MONTHLY
─────                    ───────────               ───────
capture ──► inbox ──► score ──► route ──► backlog ──► review
  (30s)                 (30s)    (auto)    (ranked)   (prune)
                                     │
                                     ▼
                              calendar slot
                                     │
                                     ▼
                                 produce
```

**Next file:** `repurposing-workflow.md` — how one scheduled idea becomes ten assets.
