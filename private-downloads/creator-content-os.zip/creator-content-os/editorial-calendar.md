# The Editorial Calendar That Turns Chaos Into a Posting Machine

**The commitment layer of Creator Content OS.** Pillars give you themes. Themes fill slots. Slots create deadlines. This file turns "I should post more" into a schedule you can actually keep.

---

## Table of Contents
1. [Content Pillars](#1-content-pillars)
2. [The Cadence Math](#2-the-cadence-math)
3. [Quarterly Planning Template](#3-quarterly-planning-template)
4. [Monthly Planning Template](#4-monthly-planning-template)
5. [Weekly Planning Template](#5-weekly-planning-template)
6. [The Content Slot Library](#6-the-content-slot-library)
7. [Seasonal & Campaign Layers](#7-seasonal--campaign-layers)
8. [Calendar Rules](#8-calendar-rules)

---

## 1. Content Pillars

Pillars are the 3–5 recurring themes you're known for. Everything you publish should map to one. If an idea doesn't fit a pillar, either it's wrong for you or you need a new pillar — decide deliberately, not by accident.

### Pillar Definition Template

| Field | Your answer | Example (a productivity creator) |
|---|---|---|
| **Pillar name** | | Systems & Workflows |
| **Audience problem it solves** | | "I'm busy but not productive" |
| **Your unique angle** | | Anti-hustle, ADHD-aware, tool-agnostic |
| **Primary format** | | Long-form YouTube + newsletter |
| **Success metric** | | Email subscribers, saves |
| **Proof you can go deep** | | 3+ years building personal systems |

### Worked Example: A 4-Pillar Set

| # | Pillar | Audience problem | Flagship format | North-star metric |
|---|---|---|---|---|
| 1 | **Systems & Workflows** | "I'm busy but not productive" | YouTube long-form | Newsletter subs |
| 2 | **Tools & Reviews** | "Which app should I use?" | Short-form video | Saves |
| 3 | **Mindset & Habits** | "I start but never finish" | Essay / newsletter | Replies & shares |
| 4 | **Behind the Scenes** | "Is this life even sustainable?" | Vlog / stories | Watch time |

### Pillar Mix Rule
Aim for this rough split of your publishing volume:

- **50%** Pillar 1 (your signature topic)
- **25%** Pillar 2
- **15%** Pillar 3
- **10%** Pillar 4

This keeps you recognizable (not scattered) while leaving room for range.

---

## 2. The Cadence Math

Most creators over-commit. Do the math *before* you promise a schedule.

### The Sustainable Cadence Formula

```
Weekly capacity (hours) = Available creation hours per week
Cost per flagship piece  = Hours to research + draft + edit ONE pillar piece
Derivative cost          = ~20% of flagship cost per derived asset

Max flagships/week = Weekly capacity ÷ Cost per flagship
```

### Worked Example

| Input | Value |
|---|---|
| Available creation hours / week | 10 |
| Hours per YouTube flagship | 6 |
| Hours per derived asset | 1.2 |
| **Max flagships / week** | **1** (with ~4 hours left for 3 derivatives) |

**Conclusion:** This creator should ship **1 flagship + 3 derivatives per week**, not 5 originals. That's a sustainable 4-asset week.

### Cadence by Creator Stage

| Stage | Flagships/week | Derivatives/week | Total assets/week |
|---|---|---|---|
| **Starting (0–1k)** | 1 per 2 weeks | 3 | 3–4 |
| **Growing (1k–10k)** | 1 | 4–5 | 5–6 |
| **Scaling (10k–100k)** | 1–2 | 6–8 | 8–10 |
| **Team (100k+)** | 2–3 | 10–15 | 12–18 |

> **Rule:** Never increase cadence until your current cadence has run for 4 consecutive weeks without a missed slot.

---

## 3. Quarterly Planning Template

Set the big arc once per quarter. This is where you decide *themes*, not individual posts.

### Quarter At A Glance

| Field | Q4 2026 (Oct–Dec) |
|---|---|
| **Quarter theme** | "Build Your Content OS" |
| **Primary goal** | 2,000 newsletter subscribers |
| **Flagship series** | 6-part content systems series |
| **Launch/offer** | Content OS digital product (Dec) |
| **Pillars in focus** | Systems & Workflows, Tools |
| **Pillars on pause** | Mindset (deprioritized) |

### Quarterly Theme Map

| Month | Monthly theme | Ties to quarter goal |
|---|---|---|
| **Month 1 (Oct)** | Foundations: capture & plan | Builds list with "how to start" content |
| **Month 2 (Nov)** | Production & repurposing | Demonstrates the system in action |
| **Month 3 (Dec)** | Measurement & launch | Drives product launch |

### Quarterly Planning Checklist
- [ ] Pick ONE quarter theme (not three).
- [ ] Name the single primary goal and its number.
- [ ] Choose 1–2 pillars to go deep on; explicitly pause the rest.
- [ ] Decide the flagship series (a series beats scattered posts).
- [ ] Note any launch, season, or event you must build toward.
- [ ] Schedule a mid-quarter check-in (week 6) to adjust.

---

## 4. Monthly Planning Template

The monthly plan converts themes into dated slots.

### Month Header

| Field | Value |
|---|---|
| **Month** | October 2026 |
| **Theme** | Foundations: Capture & Plan |
| **Flagship count target** | 4 |
| **Derivative target** | 16 |
| **Key dates** | Oct 1 (Q4 kickoff), Oct 31 (monthly review) |

### Monthly Slot Grid

Fill one row per publishing slot. Use the pillar codes from Section 1.

| Wk | Mon | Tue | Wed | Thu | Fri | Sat | Sun |
|---|---|---|---|---|---|---|---|
| **1** | — | Flagship: YT "Why your content fails" (P1) | Carousel: 5 capture methods (P1) | Short: "Stop starting from zero" (P3) | Newsletter: The Capture Problem (P1) | — | Reel: BTS setup (P4) |
| **2** | — | Flagship: YT "The 4-loop content engine" (P1) | Carousel: Pillar map (P1) | Short: Tool tip (P2) | Newsletter: Pillars 101 (P1) | — | Reel: Desk tour (P4) |
| **3** | — | Flagship: YT "Idea scoring in 5 min" (P1) | Carousel: Scoring rubric (P1) | Short: "Kill your darlings" (P3) | Newsletter: The Idea Pipeline (P1) | — | Reel: Q&A (P4) |
| **4** | — | Flagship: YT "Plan a month in 30 min" (P1) | Carousel: Monthly template (P1) | Short: Template walkthrough (P2) | Newsletter: Monthly review (P1) | — | Reel: Month recap (P4) |

### Monthly Planning Checklist
- [ ] Confirm the month theme against the quarterly map.
- [ ] Block 4 flagship slots (one per week).
- [ ] Pre-assign a pillar code to every slot.
- [ ] Leave 1 "flex slot" per week for reactive/trend content.
- [ ] Note any dates that require a specific angle (holidays, launches).

---

## 5. Weekly Planning Template

The weekly plan is where ideas meet deadlines. Run this during the **Monday Plan (30 min)**.

### Week At A Glance

| Field | Value |
|---|---|
| **Week of** | Oct 13–19, 2026 |
| **Flagship** | YT: "The 4-loop content engine" (P1) |
| **One goal for the week** | Ship flagship + 4 derivatives |
| **Capacity check** | 10 hrs available / 10.8 hrs needed ⚠️ |

### Weekly Slot Board

| Slot | Day | Platform | Format | Pillar | Idea (from pipeline) | Status | Owner |
|---|---|---|---|---|---|---|---|
| 1 | Tue | YouTube | Long-form | P1 | #042 4-loop engine | Drafting | Me |
| 2 | Wed | LinkedIn | Carousel | P1 | #043 Pillar map | Not started | Me |
| 3 | Thu | TikTok/Reels | Short | P3 | #044 "Stop starting from zero" | Not started | VA |
| 4 | Fri | Newsletter | Essay | P1 | #045 The engine explained | Outline | Me |
| 5 | Sun | Instagram | Reel | P4 | #046 BTS setup | Not started | VA |

### Weekly Planning Checklist
- [ ] Pull last week's metrics (5 min).
- [ ] Triage idea inbox; promote top 3 (10 min).
- [ ] Fill every slot from the pipeline, not from thin air (10 min).
- [ ] Name the ONE flagship (5 min).
- [ ] Confirm capacity math — cut a slot if over capacity.

### Capacity Guardrail
If `hours needed > hours available`, **cut the lowest-priority derivative**, never the flagship. The flagship feeds the whole week.

---

## 6. The Content Slot Library

A slot is a *reusable container*: a platform + format + purpose. Pre-defining slots removes daily decisions.

| Slot name | Platform | Format | Length | Purpose | Typical pillar |
|---|---|---|---|---|---|
| **The Flagship** | YouTube / Blog | Long-form | 8–20 min | Teach deeply, build authority | P1 |
| **The Carousel** | LinkedIn / IG | 8–10 slides | — | Distill a framework | P1, P2 |
| **The Short** | TikTok / Reels / Shorts | Vertical video | 30–60 s | Hook + one idea | P3 |
| **The Essay** | Newsletter | Text | 800–1,500 w | Build relationship, depth | P1 |
| **The Thread** | X / Threads | Text thread | 8–12 posts | Micro-teach, shareable | P2 |
| **The BTS** | Stories / Reels | Casual video | 15–45 s | Humanize, build trust | P4 |
| **The Q&A** | Any | Reply format | varies | Community, low effort | P4 |
| **The Flex Slot** | Any | Any | varies | React to trends/news | any |

### Slot Selection Rule
Pick **3–5 slots** as your "always-on" set. Everything else is occasional. Consistency beats variety.

---

## 7. Seasonal & Campaign Layers

Layer these *on top* of your regular cadence — don't replace it.

| Layer | When | Example | How it modifies the calendar |
|---|---|---|---|
| **Seasonal** | Q4, New Year, summer | "New Year reset" content | Swap 1 flagship/month to seasonal angle |
| **Launch** | Product/offer windows | Content OS launch (Dec) | 2–3 weeks of launch-specific slots |
| **Trend-jacking** | Opportunistic | A tool goes viral | Use your flex slots only |
| **Evergreen refresh** | Quarterly | Update a top performer | Re-slot + re-derive an old winner |

### Launch Calendar Template (3 weeks)

| Week | Goal | Slots |
|---|---|---|
| **-2** | Build anticipation | Flagship teaser, 2 shorts, 1 essay |
| **-1** | Educate & warm | Flagship "how it works", carousel, thread |
| **0** | Launch | Flagship demo, daily shorts, email sequence |
| **+1** | Social proof | Testimonials, Q&A, results post |

---

## 8. Calendar Rules

1. **Plan in blocks, publish in slots.** Decide themes monthly, fill slots weekly.
2. **Never schedule more than 80% of capacity.** Leave 20% for life and trends.
3. **The flagship is sacred.** Reschedule derivatives before you reschedule the flagship.
4. **Every slot has a pillar code.** No orphan content.
5. **One flex slot per week.** Reactive content is a feature, not a failure.
6. **Batch by format, not by day.** Write all newsletters together; film all shorts together.
7. **Review the calendar monthly, rebuild it quarterly.** Don't over-tune weekly.
8. **If you miss a slot, don't double up.** Skip it and move on — backlog debt kills momentum.

---

## Quick-Reference: The Planning Stack

```
QUARTER  → theme + goal + series        (decide once)
   ↓
MONTH    → theme + 4 flagship slots     (decide monthly)
   ↓
WEEK     → 5–6 dated slots from pipeline (decide Mondays)
   ↓
DAY      → one task, one slot           (execute)
```

**Next file:** `idea-pipeline.md` — where the ideas that fill these slots come from.
