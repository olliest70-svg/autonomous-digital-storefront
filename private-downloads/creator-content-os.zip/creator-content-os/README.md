# Creator Content OS

**The operating system for creators who publish consistently without burning out.**

Creator Content OS is a complete, plug-and-play system for planning, producing, repurposing, and measuring content across every platform you care about. It replaces the chaos of "what do I post today?" with a repeatable weekly rhythm, a living idea pipeline, a repurposing engine, and a performance dashboard that tells you what to make more of.

> **Who it's for:** solo creators, newsletter writers, YouTubers, podcasters, coaches, consultants, and small content teams who want a durable system — not another one-off content calendar.

---

## What's Inside

| File | What it does | Use it when |
|---|---|---|
| `README.md` | The map. System overview, setup, and weekly rhythm. | First. Read this once, then keep it as your reference. |
| `editorial-calendar.md` | Quarterly + monthly + weekly planning templates, content pillars, cadence math. | At the start of every month and quarter. |
| `idea-pipeline.md` | Capture-to-publish funnel, idea scoring, backlog management. | Daily (capture) and weekly (triage). |
| `repurposing-workflow.md` | The 1 → 10 engine: turn one pillar piece into a week of content. | After every flagship piece ships. |
| `performance-tracker.md` | Metrics dashboard, KPI definitions, review rituals, decision rules. | Weekly (log) and monthly (analyze). |
| `brand-voice-swipe-file.md` | Voice definition, tone dials, swipe lines, do/don't examples. | Once at setup, then whenever you draft or delegate. |

---

## The Core Idea: One Engine, Four Loops

Most creators fail because they run four separate, disconnected workflows. Creator Content OS connects them into a single engine with four loops:

```
        ┌─────────────────────────────────────────────┐
        │                 IDEA PIPELINE                │
        │      (capture → score → schedule → ship)     │
        └───────────────┬─────────────────────────────┘
                        │
        ┌───────────────▼───────────────┐
        │        EDITORIAL CALENDAR      │
        │   (pillars → themes → slots)   │
        └───────────────┬───────────────┘
                        │
        ┌───────────────▼───────────────┐
        │      REPURPOSING WORKFLOW      │
        │     (1 pillar → 10 assets)     │
        └───────────────┬───────────────┘
                        │
        ┌───────────────▼───────────────┐
        │      PERFORMANCE TRACKER       │
        │  (data → insight → next idea)  │
        └───────────────┬───────────────┘
                        │
                        └──────► feeds back into the Idea Pipeline
```

The loop is the point. Performance data doesn't just sit in a dashboard — it generates the next batch of ideas. Repurposed assets don't just fill slots — they get logged and compared so you learn which formats win.

---

## The Four Loops Explained

### Loop 1 — Idea Pipeline
Every idea enters through one door and is scored before it earns a production slot. No more "I have 47 notes and no idea what to make." → `idea-pipeline.md`

### Loop 2 — Editorial Calendar
Pillars give you themes. Themes fill slots. Slots create deadlines. The calendar is the *commitment layer* that turns intentions into a publishable schedule. → `editorial-calendar.md`

### Loop 3 — Repurposing Workflow
One well-made pillar piece becomes 8–12 platform-native assets. This is where leverage lives: you stop creating from zero and start *deriving*. → `repurposing-workflow.md`

### Loop 4 — Performance Tracker
You log a small, fixed set of metrics weekly, review monthly, and turn the findings into explicit "make more of X" decisions. → `performance-tracker.md`

---

## Quick Start (90 minutes)

Do this once. After that, the system runs on ~30 minutes of planning per week.

| Step | Time | Action | File |
|---|---|---|---|
| 1 | 15 min | Define your 3–5 content pillars and your primary platform. | `editorial-calendar.md` |
| 2 | 15 min | Fill in your Voice Profile: audience, promise, tone dials. | `brand-voice-swipe-file.md` |
| 3 | 15 min | Set up your idea capture inbox and scoring rubric. | `idea-pipeline.md` |
| 4 | 20 min | Build your first 4-week calendar from the monthly template. | `editorial-calendar.md` |
| 5 | 15 min | Choose your 1 pillar format and map the repurposing tree. | `repurposing-workflow.md` |
| 6 | 10 min | Create your tracker sheet and set your 3 north-star metrics. | `performance-tracker.md` |

---

## The Weekly Rhythm (The Operating Cadence)

This is the heartbeat of the system. Block these four sessions and protect them.

| Day | Session | Duration | Output |
|---|---|---|---|
| **Monday** | Plan & Triage | 30 min | Week's slots confirmed; ideas scored and slotted |
| **Tuesday–Thursday** | Create | 60–120 min/day | Pillar piece drafted; assets derived |
| **Friday** | Ship & Log | 30 min | Assets scheduled; metrics logged in tracker |
| **Last Friday of month** | Review & Decide | 60 min | Monthly report; next month's themes locked |

### The Monday Plan (30 min agenda)
1. **Review last week's numbers** (5 min) — pull from `performance-tracker.md`.
2. **Triage the idea inbox** (10 min) — score new ideas, promote the top 3.
3. **Confirm the week's slots** (10 min) — match ideas to calendar slots.
4. **Set the one flagship** (5 min) — the single piece that matters most this week.

### The Friday Ship (30 min agenda)
1. **Schedule next week's assets** (15 min).
2. **Log this week's metrics** (10 min).
3. **Capture 3 new ideas** (5 min) — from comments, DMs, and questions you got.

---

## The 3 Rules That Make It Work

1. **One flagship per week.** Everything else is derived. If you try to make five original pieces a week, you'll quit in three weeks.
2. **Log before you judge.** Don't change strategy based on vibes. Log 4 weeks of data first, then decide.
3. **Repurpose on the same day you publish.** If you wait, momentum dies and the pillar piece becomes "too precious" to chop up.

---

## Naming Conventions (Keep Your Files Findable)

Use a consistent naming scheme so assets are traceable back to their source:

```
YYYY-MM-DD_[platform]_[format]_[slug]

Examples:
2026-10-13_youtube_longform_how-to-build-a-content-os
2026-10-14_linkedin_carousel_content-os-5-pillars
2026-10-15_newsletter_essay_the-repurposing-engine
```

The date is the **publish date**, not the creation date. This makes your tracker sortable and your repurposing tree auditable.

---

## Folder Structure (Recommended)

```
creator-content-os/
├── 00-system/            # These six files
├── 01-ideas/             # Raw capture (one inbox file per month)
├── 02-calendar/          # Quarterly, monthly, weekly plans
├── 03-pillars/           # Flagship drafts and finals
├── 04-derivatives/       # Repurposed assets by platform
├── 05-published/         # Archive of everything shipped
└── 06-data/              # Tracker exports and monthly reports
```

---

## Common Failure Modes (and the Fix)

| Failure mode | What it looks like | The fix |
|---|---|---|
| **Idea hoarding** | 200 notes, nothing shipped | Score ruthlessly; kill anything below 12/20 |
| **Calendar drift** | Plan says 5 posts, you shipped 1 | Cut cadence to what you can actually sustain |
| **Repurposing neglect** | Every post is from scratch | Make repurposing a *same-day* ritual, not a someday task |
| **Vanity metrics** | Chasing likes, ignoring saves/subscribes | Track the 3 north-star metrics in `performance-tracker.md` |
| **Voice drift** | Content feels generic | Re-anchor to your Voice Profile monthly |
| **Burnout spiral** | Dreading the Monday plan | Batch-create; never create and publish on the same day |

---

## How to Use This as a Team

If you have a VA, editor, or designer:
- **You** own pillars, voice, and the Monday plan.
- **They** own derivatives, scheduling, and logging.
- Share `brand-voice-swipe-file.md` as the single source of truth for tone.
- Use the naming convention so handoffs are unambiguous.

---

## Maintenance Schedule

| Cadence | Task | File |
|---|---|---|
| Weekly | Plan, ship, log | All |
| Monthly | Review metrics, lock next themes | `performance-tracker.md`, `editorial-calendar.md` |
| Quarterly | Reassess pillars, prune backlog, refresh voice | `editorial-calendar.md`, `brand-voice-swipe-file.md` |
| Annually | Full system audit; kill what doesn't work | `README.md` |

---

## License & Usage

This system is yours to adapt. Rename pillars, change cadences, add platforms. The structure is the value — the specifics should fit your life, not the other way around.

**Version:** 1.0 · **Last updated:** October 2026
