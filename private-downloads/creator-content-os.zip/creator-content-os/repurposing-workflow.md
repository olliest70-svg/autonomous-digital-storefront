# Make One Piece of Content Work Across 5 Platforms

**The leverage engine of Creator Content OS.** One well-made pillar piece becomes 8–12 platform-native assets. Stop creating from zero. Start deriving.

---

## Table of Contents
1. [The Core Principle](#1-the-core-principle)
2. [The 1 → 10 Repurposing Tree](#2-the-1--10-repurposing-tree)
3. [The Five-Step Workflow](#3-the-five-step-workflow)
4. [Format Conversion Cheat Sheet](#4-format-conversion-cheat-sheet)
5. [Platform-Native Adaptation Rules](#5-platform-native-adaptation-rules)
6. [The Repurposing Session (60 min)](#6-the-repurposing-session-60-min)
7. [Worked Example: End to End](#7-worked-example-end-to-end)
8. [Quality Control](#8-quality-control)

---

## 1. The Core Principle

> **Create once at depth. Distribute many times at surface.**

A pillar piece (long-form video, essay, podcast episode) contains **10+ distinct ideas**. Most creators publish it once and move on. The repurposing engine extracts every idea and reshapes it for each platform.

### Why It Works
- **Depth is expensive; surface is cheap.** The hard thinking happens once.
- **Platforms reward native formats.** A clip beats a link every time.
- **Consistency becomes possible.** You're never starting from a blank page.

### The 80/20 of Repurposing
- **20%** of your effort = the flagship.
- **80%** of your *reach* comes from derivatives.
- **100%** of your *authority* comes from the flagship.

You need both. The flagship builds trust; derivatives build reach.

---

## 2. The 1 → 10 Repurposing Tree

Start with one flagship. Branch into formats. Each branch is a native asset.

```
                    ┌──────────────────────┐
                    │   FLAGSHIP PIECE     │
                    │  (YouTube / Essay /  │
                    │   Podcast, 10–20 min)│
                    └──────────┬───────────┘
                               │
        ┌──────────┬───────────┼───────────┬──────────┐
        │          │           │           │          │
   ┌────▼───┐ ┌────▼───┐ ┌─────▼────┐ ┌────▼───┐ ┌────▼───┐
   │Newsletter│ │Carousel│ │ 3 Shorts │ │ Thread │ │  Blog  │
   │  essay  │ │ (10 pg)│ │ (30-60s) │ │ (8-12) │ │  post  │
   └─────────┘ └────────┘ └──────────┘ └────────┘ └────────┘
        │          │           │           │          │
        └──────────┴───────────┼───────────┴──────────┘
                               │
                    ┌──────────▼───────────┐
                    │  AMPLIFIERS          │
                    │  Quote graphic,      │
                    │  audiogram, pin,     │
                    │  community post      │
                    └──────────────────────┘
```

### The Standard 10-Asset Set

| # | Asset | Platform | Derived from | Effort |
|---|---|---|---|---|
| 1 | Newsletter essay | Email | Flagship script | 30 min |
| 2 | Carousel (8–10 slides) | LinkedIn / IG | Flagship key points | 25 min |
| 3 | Short #1 (best hook) | TikTok / Reels | Flagship intro | 15 min |
| 4 | Short #2 (best insight) | YouTube Shorts | Flagship mid-section | 15 min |
| 5 | Short #3 (best story) | Reels | Flagship anecdote | 15 min |
| 6 | Text thread | X / Threads | Flagship outline | 20 min |
| 7 | Blog post | Website / SEO | Flagship transcript | 30 min |
| 8 | Quote graphic | IG / LinkedIn | Best one-liner | 10 min |
| 9 | Audiogram clip | LinkedIn / X | Best 45-sec audio | 10 min |
| 10 | Community post | YouTube / Discord | Question from flagship | 5 min |

**Total extra time: ~3 hours → 10 assets.** Compare to creating 10 originals (~10+ hours).

---

## 3. The Five-Step Workflow

Run this **the same day you publish** the flagship. Momentum is the ingredient.

### Step 1 — Extract (15 min)
Pull the raw material out of the flagship.

- **Transcript:** Auto-generate from video/podcast.
- **Highlight the 10 best lines.** These become hooks and quotes.
- **List the 3–5 main points.** These become carousels and threads.
- **Mark the 1 best story.** This becomes a short.

> **Extraction rule:** If you can't find 10 quotable lines, the flagship isn't deep enough. Add depth before repurposing.

### Step 2 — Map (10 min)
Assign each extracted idea to a format using the tree.

| Extracted element | Best format | Platform |
|---|---|---|
| Strongest hook | Short #1 | TikTok |
| 3–5 main points | Carousel | LinkedIn |
| Best story | Short #3 | Reels |
| Best one-liner | Quote graphic | IG |
| Full argument | Newsletter | Email |

### Step 3 — Adapt (90 min)
Reshape each asset to be **native**, not copy-pasted. (See Section 5.)

### Step 4 — Schedule (15 min)
Load everything into the calendar/scheduler with staggered dates.

| Asset | Publish date | Platform |
|---|---|---|
| Flagship | Day 0 | YouTube |
| Newsletter | Day 0 | Email |
| Short #1 | Day 1 | TikTok |
| Carousel | Day 2 | LinkedIn |
| Thread | Day 3 | X |
| Short #2 | Day 4 | Shorts |
| Blog | Day 5 | Website |
| Short #3 | Day 6 | Reels |
| Quote graphic | Day 6 | IG |
| Community post | Day 7 | YouTube |

### Step 5 — Log (10 min)
Record the flagship and its derivatives in `performance-tracker.md` so you can compare formats later.

---

## 4. Format Conversion Cheat Sheet

How to translate the *same idea* across formats.

| From → To | What changes | What stays |
|---|---|---|
| **Video → Newsletter** | Written voice, no visuals, add links | Core argument, structure |
| **Video → Carousel** | One point per slide, big text | Key points, order |
| **Video → Short** | Cut to 30–60s, new hook, captions | The single best moment |
| **Video → Thread** | Numbered, punchy, one idea per post | The outline |
| **Essay → Video** | Add face, B-roll, spoken cadence | The thesis |
| **Essay → Carousel** | Condense to 8 slides | The framework |
| **Podcast → Audiogram** | 45-sec clip + waveform | The best soundbite |
| **Any → Quote graphic** | One line, big type, your handle | The punchline |

### The Hook Translation Table

The same idea needs a *different hook* per platform.

| Platform | Hook style | Example |
|---|---|---|
| **YouTube** | Curiosity + promise | "Most creators quit for this one reason." |
| **TikTok** | Pattern interrupt | "Stop. You don't have an idea problem." |
| **LinkedIn** | Contrarian + professional | "Posting daily almost killed my channel." |
| **Newsletter** | Personal + direct | "I want to tell you about the week I almost quit." |
| **X** | Blunt + declarative | "You don't need more ideas. You need a filter." |

---

## 5. Platform-Native Adaptation Rules

**Never post the same text on every platform.** Adapt to each platform's native behavior.

| Platform | Native behavior | Do | Don't |
|---|---|---|---|
| **YouTube (long)** | Watch time, search | Deep teaching, chapters, SEO title | Clickbait with no payoff |
| **YouTube Shorts** | Swipe speed | Hook in 1s, captions, loop | Slow intros |
| **TikTok** | Entertainment, trend | Native text, trending audio, casual | Polished corporate feel |
| **Instagram Reels** | Aesthetic, saves | Clean captions, cover frame | Watermarks from other apps |
| **LinkedIn** | Professional insight | Story + lesson, no links in post | Overly salesy, emoji spam |
| **X / Threads** | Brevity, opinion | Punchy, one idea per post | Long paragraphs |
| **Newsletter** | Relationship, depth | Personal, scannable, one CTA | Pure repost of a blog |
| **Blog** | SEO, evergreen | Keywords, headings, internal links | Thin content |

### The "Native Test"
Before posting, ask: *"Would this look like it was made for this platform?"* If it looks imported, adapt it.

---

## 6. The Repurposing Session (60 min)

A focused block that produces the week's derivatives. Batch by *format*, not by piece.

### Agenda

| Time | Task | Output |
|---|---|---|
| 0–10 min | Extract 10 lines + 3 points + 1 story | Raw material list |
| 10–20 min | Map to formats | Asset plan |
| 20–40 min | Write/cut all text assets (thread, carousel, newsletter) | 3 assets |
| 40–55 min | Cut all video assets (3 shorts) | 3 assets |
| 55–60 min | Create graphics + schedule | 4 assets |

### Batching Rules
- **All carousels together.** Same design template, different content.
- **All shorts together.** Same editing preset, different clips.
- **All graphics together.** Same brand kit, different lines.
- **Never context-switch mid-batch.** Finish one format before starting the next.

---

## 7. Worked Example: End to End

**Flagship:** YouTube video — *"The 4-Loop Content Engine"* (14 min)

### Extracted Material
- **10 best lines:** e.g. "You don't have an idea problem, you have a filtering problem."
- **3 main points:** (1) Idea pipeline, (2) Calendar, (3) Repurposing + tracking
- **1 best story:** The week I almost quit after posting daily for 30 days

### The 10 Assets Produced

| # | Asset | Headline / Hook | Platform | Publish |
|---|---|---|---|---|
| 1 | Newsletter | "The system that saved my channel" | Email | Day 0 |
| 2 | Carousel | "4 loops that fix inconsistent posting" | LinkedIn | Day 2 |
| 3 | Short #1 | "You don't have an idea problem" | TikTok | Day 1 |
| 4 | Short #2 | "The 5-minute idea filter" | Shorts | Day 4 |
| 5 | Short #3 | "The week I almost quit" | Reels | Day 6 |
| 6 | Thread | "How I went from 2 to 9 posts a week" | X | Day 3 |
| 7 | Blog | "The 4-Loop Content Engine (full guide)" | Website | Day 5 |
| 8 | Quote graphic | "Filtering > generating" | IG | Day 6 |
| 9 | Audiogram | "The repurposing rule" (45s) | LinkedIn | Day 5 |
| 10 | Community post | "What's your biggest content bottleneck?" | YouTube | Day 7 |

### Effort Accounting

| Phase | Time |
|---|---|
| Flagship (research + script + edit) | 6 hrs |
| Repurposing session | 3 hrs |
| **Total** | **9 hrs for 11 assets** |
| **Average per asset** | **~49 min** |

Compare: 11 originals at ~2 hrs each = **22 hours.** Repurposing saves ~13 hours per cycle.

---

## 8. Quality Control

Repurposing fails when derivatives feel like leftovers. Run this checklist.

### The Derivative Quality Checklist
- [ ] **Standalone:** Does it make sense without the flagship?
- [ ] **Native:** Does it look made for this platform?
- [ ] **Hooked:** Does the first line/second stop the scroll?
- [ ] **Valuable:** Does it deliver one complete idea?
- [ ] **Branded:** Does it match your voice (see `brand-voice-swipe-file.md`)?
- [ ] **CTA'd:** Does it point somewhere (subscribe, download, follow)?

### Common Repurposing Mistakes

| Mistake | Why it fails | Fix |
|---|---|---|
| Copy-paste across platforms | Looks imported, underperforms | Adapt to native format |
| Watermarked cross-posts | Platforms suppress them | Re-export clean |
| Weak hooks | No one stops | Write a fresh hook per platform |
| Too many CTAs | Dilutes action | One CTA per asset |
| Repurposing too late | Momentum dies | Same-day session |
| No logging | Can't learn what works | Log every asset |

### The Golden Rule
> **A derivative should feel like a first-class piece, not a leftover.** If it wouldn't stand alone, don't post it.

---

## The Repurposing Loop

```
   PUBLISH FLAGSHIP
          │
          ▼
   EXTRACT (10 lines, 3 points, 1 story)
          │
          ▼
   MAP → ADAPT → SCHEDULE → LOG
          │
          ▼
   TRACK PERFORMANCE  ──────►  Which format won?
          │                          │
          ▼                          ▼
   Feed best format back        Make more of it
   into next flagship plan
```

**Next file:** `performance-tracker.md` — how to measure whether any of this is working.
