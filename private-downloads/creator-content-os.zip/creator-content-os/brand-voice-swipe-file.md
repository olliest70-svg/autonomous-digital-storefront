# Sound Like YOU Every Time — Your Brand Voice Swipe File

**The tone layer of Creator Content OS.** Your voice is the one thing competitors can't copy. This file defines it, protects it, and gives you swipe lines so every asset sounds recognizably *you* — even when a VA or AI drafts it.

---

## Table of Contents
1. [The Voice Profile](#1-the-voice-profile)
2. [The Tone Dials](#2-the-tone-dials)
3. [Voice Pillars](#3-voice-pillars)
4. [The Swipe File: Openers](#4-the-swipe-file-openers)
5. [The Swipe File: Transitions & Closers](#5-the-swipe-file-transitions--closers)
6. [Do / Don't Examples](#6-do--dont-examples)
7. [Platform Voice Adjustments](#7-platform-voice-adjustments)
8. [Voice QA Checklist](#8-voice-qa-checklist)

---

## 1. The Voice Profile

Fill this in once. It's the single source of truth for anyone who writes as you.

| Field | Your answer | Example (a systems creator) |
|---|---|---|
| **Who I am** | | A former ops manager who builds calm systems for chaotic brains |
| **Who I serve** | | Overwhelmed creators and solopreneurs |
| **The promise** | | "You can be consistent without burning out" |
| **What I stand for** | | Sustainability over hustle; systems over willpower |
| **What I stand against** | | Grind culture, tool-hoarding, vanity metrics |
| **My origin story** | | Burned out posting daily; built a system; never looked back |
| **My proof** | | 6 months of data, 3 years of systems |
| **3 words for my voice** | | Calm, direct, practical |
| **Words I never use** | | "Crush it", "hustle", "guru", "secret hack" |
| **My signature phrases** | | "Systems beat willpower." "Filter, don't generate." |

### The Voice Equation

```
VOICE = (Who I am) + (What I believe) + (How I say it)
```

If a draft doesn't reflect all three, it's off-voice.

---

## 2. The Tone Dials

Voice is constant; tone flexes. Set your default position on each dial, then note when you deviate.

```
Formal     1 ── 2 ── 3 ── 4 ── 5   Casual        [default: 4]
Serious    1 ── 2 ── 3 ── 4 ── 5   Playful       [default: 3]
Reserved   1 ── 2 ── 3 ── 4 ── 5   Bold          [default: 4]
Abstract   1 ── 2 ── 3 ── 4 ── 5   Concrete      [default: 5]
Humble     1 ── 2 ── 3 ── 4 ── 5   Authoritative [default: 3]
```

### When to Flex Each Dial

| Dial | Flex toward... | When |
|---|---|---|
| Casual ↔ Formal | Formal | Partnerships, guest posts, press |
| Serious ↔ Playful | Playful | Shorts, community posts, BTS |
| Reserved ↔ Bold | Bold | Contrarian takes, launch content |
| Abstract ↔ Concrete | Concrete | Always — concrete is your default |
| Humble ↔ Authoritative | Authoritative | Teaching, frameworks, data-backed claims |

> **Rule:** Never flex more than **2 points** from your default. Beyond that, it stops sounding like you.

---

## 3. Voice Pillars

Four traits that define how you sound. Each has a "sounds like" and a "never sounds like."

### Pillar 1 — Calm
- **Sounds like:** "Here's a simpler way." "You don't have to do all of it."
- **Never sounds like:** "You're doing it wrong!" "This changes EVERYTHING."

### Pillar 2 — Direct
- **Sounds like:** "Cut the lowest-priority slot." "One flagship per week."
- **Never sounds like:** "Perhaps you might consider possibly..."

### Pillar 3 — Practical
- **Sounds like:** "Do this in 10 minutes." "Here's the exact template."
- **Never sounds like:** "Just be more consistent." (vague advice)

### Pillar 4 — Honest
- **Sounds like:** "This didn't work for me." "I'm not sure yet."
- **Never sounds like:** "Trust me, it always works." (overpromising)

---

## 4. The Swipe File: Openers

Steal these. Adapt the brackets.

### Curiosity Openers
- "Most creators quit for a reason no one talks about."
- "I spent [time] doing this wrong so you don't have to."
- "There's a version of [X] that doesn't burn you out. Here it is."

### Contrarian Openers
- "You don't have an idea problem. You have a filtering problem."
- "Posting daily almost killed my channel."
- "Everything you've heard about [X] is backwards."

### Story Openers
- "Six months ago, I was [bad state]. Here's what changed."
- "I almost quit content last [month]. Then I built one system."
- "A reader asked me [question]. It broke my brain for a week."

### Direct-Value Openers
- "Here's the exact system I use to [outcome]."
- "Three rules that fixed my [problem]."
- "Steal my [template]. It takes 10 minutes."

### Question Openers
- "What if consistency had nothing to do with willpower?"
- "Why do you keep starting over every Monday?"

### Opener Rules
- **First line = the whole job.** If the opener doesn't earn line two, nothing else matters.
- **No throat-clearing.** Cut "In this post, I'll..." and "Let's dive in."
- **One idea per opener.** Don't stack hooks.

---

## 5. The Swipe File: Transitions & Closers

### Transitions (keep momentum)
- "Here's the part that matters:"
- "But there's a catch."
- "So what does that look like in practice?"
- "Let me make it concrete."
- "This is where most people stop. Don't."

### Closers (drive action)
- **Soft CTA:** "If this helped, the full system is in the link."
- **Direct CTA:** "Download the Content OS and start Monday."
- **Engagement CTA:** "What's your biggest bottleneck? Reply and tell me."
- **Series CTA:** "Next week: the repurposing engine. Follow so you don't miss it."

### Signature Phrases (use sparingly, ~1 per piece)
- "Systems beat willpower."
- "Filter, don't generate."
- "Create once, distribute many."
- "Consistency is a system, not a feeling."

> **Warning:** Signature phrases are seasoning, not the meal. Overuse makes them cringe.

---

## 6. Do / Don't Examples

### Example 1 — A teaching point

| ❌ Off-voice | ✅ On-voice |
|---|---|
| "You MUST post every single day or you'll fail. Hustle harder!" | "Daily posting isn't the goal. A system you can sustain is. Start with one flagship a week." |

**Why:** The off-voice version is aggressive and absolutist. The on-voice version is calm, direct, and practical.

### Example 2 — A contrarian take

| ❌ Off-voice | ✅ On-voice |
|---|---|
| "Everyone else is wrong and I'm the only one who gets it." | "I used to believe [X]. Then my own data showed the opposite. Here's what I changed." |

**Why:** Contrarian ≠ arrogant. Lead with your own experience, not superiority.

### Example 3 — A CTA

| ❌ Off-voice | ✅ On-voice |
|---|---|
| "BUY NOW before this once-in-a-lifetime offer disappears!!!" | "If you want the full system, it's here. No rush — it'll be waiting when you're ready." |

**Why:** Calm confidence beats manufactured urgency.

### Example 4 — A story

| ❌ Off-voice | ✅ On-voice |
|---|---|
| "I'm a productivity guru with 10 years of expertise." | "I burned out posting daily for 30 days. Then I built a system that saved my channel." |

**Why:** Specific and vulnerable beats credential-stacking.

### The Voice Test
Read a draft aloud. Ask: *"Would I say this to a friend over coffee?"* If no, rewrite.

---

## 7. Platform Voice Adjustments

Same voice, different dial settings.

| Platform | Tone shift | Example opener |
|---|---|---|
| **YouTube (long)** | Slightly more formal, teaching | "Let me show you the system I use." |
| **YouTube Shorts** | Punchier, faster | "Stop. You're doing this backwards." |
| **TikTok** | Most casual, playful | "ok so nobody told me this and I'm mad" |
| **Instagram Reels** | Warm, aesthetic | "Save this for your next planning day." |
| **LinkedIn** | Professional, insight-led | "I almost quit. Here's what saved me." |
| **X / Threads** | Blunt, opinionated | "Filtering > generating. That's it." |
| **Newsletter** | Personal, conversational | "I want to tell you something honest." |
| **Blog** | Clear, SEO-friendly, evergreen | "A content operating system has four parts." |

### The Constant Across Platforms
- **Calm, direct, practical, honest** — always.
- **Concrete examples** — always.
- **No hustle language** — always.

---

## 8. Voice QA Checklist

Run this before publishing anything. If you can't check every box, revise.

- [ ] **Opener earns the second line** — no throat-clearing.
- [ ] **One clear idea** — not three competing ones.
- [ ] **Concrete, not abstract** — examples, numbers, templates.
- [ ] **Sounds like me over coffee** — read it aloud.
- [ ] **No banned words** — no "hustle", "crush it", "guru", "secret hack".
- [ ] **Signature phrase used at most once** (or not at all).
- [ ] **Tone dials within 2 points of default.**
- [ ] **CTA is clear and singular.**
- [ ] **Honest** — no overpromising, no fake urgency.

### The 3-Second Voice Test
Show a random paragraph to someone who knows your content. Ask: *"Does this sound like me?"* If they hesitate, it's off-voice.

---

## Voice Drift: How to Catch It

Voice drifts when you chase trends, delegate, or use AI without editing. Catch it monthly.

| Drift symptom | Cause | Fix |
|---|---|---|
| Content feels generic | Copying competitors | Re-read your Voice Profile |
| Tone is too aggressive | Chasing engagement | Reset the "Reserved ↔ Bold" dial |
| Too many buzzwords | AI drafts unedited | Run the Voice QA checklist |
| Losing personality | Over-optimizing for SEO | Add one personal line per piece |
| Inconsistent across platforms | No shared source of truth | Share this file with your team |

### Monthly Voice Refresh (10 min)
1. Read 3 of your best-performing pieces.
2. Highlight the lines that sound most like you.
3. Add any new winners to the swipe file.
4. Remove any phrases that now feel stale.

---

## The Voice Layer in the System

```
   IDEA PIPELINE ──► CALENDAR ──► REPURPOSING ──► TRACKER
        │               │              │             │
        └───────────────┴──────────────┴─────────────┘
                            │
                    BRAND VOICE SWIPE FILE
              (the tone filter every asset passes through)
```

Every asset — flagship or derivative — passes through this file before it ships. Voice is the thread that makes a scattered feed feel like one coherent brand.

---

**End of Creator Content OS.** You now have the full system: plan it (`editorial-calendar.md`), source it (`idea-pipeline.md`), multiply it (`repurposing-workflow.md`), measure it (`performance-tracker.md`), and sound like yourself while doing it (`brand-voice-swipe-file.md`).
