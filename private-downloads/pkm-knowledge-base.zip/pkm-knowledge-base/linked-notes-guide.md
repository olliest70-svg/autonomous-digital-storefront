# Linked Notes — Turn Isolated Thoughts Into a Knowledge Web

A knowledge base becomes valuable when its notes connect. This guide covers how to link notes, how to name them so links read well, how to build Maps of Content (MOCs), and how to keep the graph healthy over time.

**The core idea:** the value of a vault lives in the *edges*, not the nodes. A hundred well-linked notes beat a thousand isolated ones.

---

## Why Links Beat Folders

Folders force every note into exactly one place. But ideas belong to many places at once. "Anchoring effect" is relevant to psychology, negotiation, pricing, and decision-making — a folder can hold it in only one.

Links solve this: a note can connect to unlimited others, and it appears in every context where it's relevant. Folders are for *storage*; links are for *meaning*.

| | Folders | Links |
|---|---------|-------|
| A note lives in | One place | Many contexts |
| Organised by | You, in advance | Emergent, over time |
| Scales to | A few hundred notes | Tens of thousands |
| Breaks when | You change your mind | Rarely |

**Use folders for coarse storage (PARA) and links for fine meaning.**

---

## The Three Link Types

### 1. Direct links (inline)
A link inside the prose of a note, where it's contextually relevant.

```markdown
The first offer in a negotiation sets an [[Anchoring effect]], which drags
every subsequent estimate toward it.
```

**Use when:** the linked idea is part of the sentence's meaning.

### 2. Hub links (structural)
A link in a "Connections" section at the bottom of a note, grouping related notes by relationship.

```markdown
## Connections
- Builds on: [[System 1 thinking is fast and automatic]]
- Contrasts with: [[Deliberate reasoning overrides intuition]]
- Part of: [[MOC — Negotiation]]
- Source: [[Kahneman — Thinking, Fast and Slow (2011)]]
```

**Use when:** you want to record the *type* of relationship, not just that one exists.

### 3. MOC links (navigational)
A link from a hub note to everything in a theme. Covered in detail below.

**Use when:** you need a browsable entry point into a topic.

---

## How to Name Notes So Links Read Well

Because links appear inside sentences, **titles must read grammatically in prose.**

| Weak (reads badly in a sentence) | Strong (reads naturally) |
|----------------------------------|--------------------------|
| `Anchoring` | `Anchoring biases the first offer` |
| `Deep work` | `Deep work produces disproportionate output` |
| `Spacing` | `Spaced repetition beats rereading` |
| `Feedback` | `Immediate feedback accelerates skill acquisition` |

**Test:** read the link inside a sentence. If it sounds like a fragment, rename it.

```markdown
❌ ...relates to [[Anchoring]].
✅ ...relates to [[Anchoring biases the first offer]].
```

> **Exception:** source notes and MOCs use noun-phrase titles (`Kahneman — Thinking, Fast and Slow (2011)`, `MOC — Negotiation`) because they're referenced, not read inline.

---

## Building Maps of Content (MOCs)

A **MOC** is a hub note that organises a theme. It's your navigation layer — more useful than folders and often more useful than search.

### When to create a MOC
- When a topic has **5+ notes** and no hub yet.
- When you find yourself repeatedly searching for the same cluster.
- When a project or area needs a curated index.

### MOC structure

```markdown
# MOC — Negotiation

**Scope:** tactics, psychology, and preparation for negotiations. Excludes
contract law (see [[MOC — Contracts]]).

## Start here
- [[BATNA defines your leverage]]
- [[Anchoring biases the first offer]]

## Core concepts
- [[Anchoring biases the first offer]]
- [[BATNA defines your leverage]]
- [[Silence is a negotiation tool]]
- [[Concede on small issues to win large ones]]

## Sources
- [[Fisher & Ury — Getting to Yes (1981)]]
- [[Kahneman — Thinking, Fast and Slow (2011)]]

## Open questions
- How do I handle a counterparty who refuses to name a number?

## Related MOCs
- [[MOC — Psychology]]
- [[MOC — Sales]]
```

### MOC types

| Type | Purpose | Example |
|------|---------|---------|
| **Topic MOC** | Organise a subject | `MOC — Negotiation` |
| **Project MOC** | Index a project | `MOC — Website Redesign` |
| **Person MOC** | Track a person/relationship | `MOC — Jane (client)` |
| **Index MOC** | Top-level hub of MOCs | `MOC — Home` |

### The top-level "Home" MOC
Create one `MOC — Home` that links to every other MOC. This becomes your vault's front door.

```markdown
# MOC — Home

## Work
- [[MOC — Negotiation]]
- [[MOC — Sales]]
- [[MOC — Productivity]]

## Learning
- [[MOC — Psychology]]
- [[MOC — Systems Thinking]]

## Life
- [[MOC — Finances]]
- [[MOC — Health]]
```

---

## The Linking Workflow

Every time you create or process a note, do these three things:

1. **Link to a MOC.** Which theme does this belong to? Add it to that MOC.
2. **Link to 1–2 related notes.** What does this connect to? Add inline or hub links.
3. **Add a back-link.** Go to the related note and link back. (Many tools do this automatically via backlinks.)

**The 2-minute rule:** if linking a note takes more than two minutes, you're overthinking it. Link to the obvious MOC and move on.

---

## Backlinks: The Hidden Network

Backlinks are links *pointing to* a note — automatically generated by tools like Obsidian, Logseq, and Roam. They mean you only have to link in one direction; the reverse appears automatically.

**Why they matter:** they surface connections you forgot you made. Reading "Anchoring biases the first offer," the backlinks panel shows every note that references it — often revealing an unexpected cluster.

**How to use them:**
- Check the backlinks panel when reading an old note.
- If a note has zero backlinks, it's an orphan — fix it.
- If a note has many backlinks, it's a hub — consider promoting it to a MOC.

---

## Finding and Fixing Orphans

An **orphan** is a note with no links in or out. Orphans are invisible — you'll never stumble onto them, and search only finds them if you remember the exact words.

### Finding orphans
- In Obsidian: use the Graph View, or a "find orphan notes" plugin.
- Manually: sort notes by link count; anything at zero is an orphan.
- Weekly: scan your Inbox and recent notes for unlinked items.

### Fixing orphans
For each orphan, decide:

| Situation | Action |
|-----------|--------|
| It belongs to a theme | Link it to that MOC |
| It relates to another note | Add a link |
| It's a duplicate | Merge and delete |
| It's genuinely standalone | Link it to `MOC — Home` |
| It's noise | Delete it |

**Target:** zero orphans. Every note reachable from your Home MOC within two hops.

---

## Graph Hygiene: Keeping the Network Healthy

### Weekly (10 minutes)
- Link any new orphan notes.
- Add new notes to their MOCs.
- Merge obvious duplicates.

### Monthly (30 minutes)
- Review MOCs — do any need splitting or merging?
- Promote clusters of 5+ related notes into a new MOC.
- Prune dead links (notes you deleted).

### Signals your graph is healthy
- Most notes have 2–10 links.
- MOCs have 10–50 outgoing links.
- You discover useful connections via backlinks.
- Search is a fallback, not your primary retrieval method.

### Signals your graph is unhealthy
- Many orphan notes.
- One giant MOC with 200 links (split it).
- Notes with 50+ links (probably a hub that should be a MOC).
- You can't find things you know you wrote.

---

## Advanced Linking Patterns

### The "Builds on / Contrasts with" pattern
Record the *relationship type*, not just the existence of a link:

```markdown
## Connections
- Builds on: [[System 1 thinking is fast and automatic]]
- Contrasts with: [[Deliberate reasoning overrides intuition]]
- Example of: [[Cognitive biases distort estimates]]
```

This makes the graph semantically richer and easier to navigate.

### The "Question" note
Create notes titled as questions; they become natural hubs.

```markdown
# How do I handle a counterparty who refuses to name a number?

Related: [[Anchoring biases the first offer]], [[BATNA defines your leverage]]
```

### The "Index" note
For a series (e.g. a course or book), create an index note linking every part.

```markdown
# Index — Deep Work (chapter notes)
1. [[Deep Work — Ch1 — Deep work is valuable]]
2. [[Deep Work — Ch2 — Deep work is rare]]
3. [[Deep Work — Ch3 — Deep work is meaningful]]
```

### Tags vs links
Use **tags** for status and type (`#status/active`, `#type/source`), and **links** for meaning. Tags are flat and multiply; links are contextual and scale. When in doubt, link.

| Use tags for | Use links for |
|--------------|---------------|
| Status (`#active`) | Concepts |
| Type (`#source`) | Sources |
| Cross-cutting flags (`#urgent`) | Relationships |

---

## A Worked Example: Growing a Graph

**Day 1:** You read an article on negotiation and capture it.
```
3-Resources/Negotiation/Fisher & Ury — Getting to Yes (1981).md
```

**Day 2:** You extract two ideas into concept notes.
```
3-Resources/Negotiation/BATNA defines your leverage.md
3-Resources/Negotiation/Separate people from the problem.md
```

**Day 3:** You create a MOC and link everything.
```
3-Resources/Negotiation/MOC — Negotiation.md
```
The MOC links to the source and both concepts. The concepts link back to the MOC.

**Week 2:** You read Kahneman and add `Anchoring biases the first offer`. You link it to the MOC and to `BATNA defines your leverage` (both are about leverage).

**Week 3:** A work negotiation comes up. You open `MOC — Negotiation`, read the summaries, and prepare in 20 minutes instead of an hour. You add a `Decision:` note recording what worked.

**Month 2:** The Negotiation MOC has 12 notes. You notice a cluster about *pricing* and split it into `MOC — Pricing`, cross-linking the two.

**Month 6:** You write an article on negotiation. You open the MOC, pull the summaries, and draft in an afternoon — from notes you'd otherwise have forgotten.

That's the compounding effect. Each link makes every future retrieval cheaper.

---

## Quick Reference

| Task | Do this |
|------|---------|
| Link a new note | Add to a MOC + 1–2 related notes |
| Name a concept note | Full sentence that reads well inline |
| Name a source note | `Author — Title (Year)` |
| Name a MOC | `MOC — Topic` |
| Find orphans | Graph view or link-count sort |
| Fix an orphan | Link to MOC, merge, or delete |
| Split a MOC | When it exceeds ~50 links |
| Create a MOC | When a topic hits 5+ notes |
| Record relationships | Use "Builds on / Contrasts with" sections |
| Prefer over tags | Links for meaning, tags for status |

---

## Summary

1. **Links beat folders** for meaning; folders are for storage.
2. **Name notes as sentences** so links read naturally.
3. **Create MOCs** when a topic reaches 5+ notes.
4. **Link every note** to a MOC and 1–2 related notes.
5. **Use backlinks** to discover forgotten connections.
6. **Kill orphans** weekly.
7. **Keep the graph healthy** with light, regular maintenance.

A well-linked vault turns a pile of notes into a thinking partner. Build the edges, and the value takes care of itself.
