# Note Templates — Copy, Paste, Refine

These templates standardise every note you create so that future-you can understand them instantly. Copy them into your `_templates/` folder. Fill in the blanks; delete what doesn't apply.

**Golden rule:** every note must answer *"What is this and why do I care?"* in the first three lines.

---

## 1. Quick Capture (Inbox)

Use for anything you don't have time to process. Dump and move on.

```markdown
---
captured: 2026-02-14 09:12
source: 
type: capture
---

# <one-line description>

<raw thought, quote, or link — messy is fine>

**Why I saved this:** <one sentence>
```

---

## 2. Concept / Permanent Note

The workhorse of your vault. One idea, fully explained, linked.

```markdown
---
created: 2026-02-14
type: concept
tags: [psychology, decision-making]
---

# <Full-sentence claim as the title>

**In one line:** <the idea distilled to a single sentence>

## Explanation
<2–5 paragraphs. Explain it as if to a smart colleague who lacks your context.>

## Why it matters
<Where this changes your behaviour, decisions, or work.>

## Evidence / Examples
- <example 1>
- <example 2>

## Counterpoints & limits
<When is this false or oversimplified?>

## Connections
- Builds on: [[related note]]
- Contrasts with: [[opposing note]]
- Part of: [[MOC — Topic]]
- Source: [[Author — Title (Year)]]
```

**Example, filled in:**

```markdown
# Anchoring biases the first offer in any negotiation

**In one line:** The first number mentioned drags every subsequent estimate toward it, even when it's arbitrary.

## Explanation
When people estimate an unknown quantity, they start from whatever number is in front of them and adjust insufficiently. In negotiations, whoever names a number first sets the anchor. Even absurd anchors (e.g. a "random" ID number) measurably shift estimates.

## Why it matters
In pricing, salary talks, and scope discussions, the anchor often decides the outcome more than the substance. Naming a well-justified number first is usually advantageous.

## Evidence / Examples
- Kahneman & Tversky's wheel-of-fortune study: participants anchored to a random number when estimating African nations in the UN.
- Real estate agents anchored to listing price when valuing a home.

## Counterpoints & limits
Anchoring is weaker when the other party is an expert or when the anchor is obviously self-serving.

## Connections
- Builds on: [[System 1 thinking is fast and automatic]]
- Contrasts with: [[Deliberate reasoning overrides intuition]]
- Part of: [[MOC — Negotiation]]
- Source: [[Kahneman — Thinking, Fast and Slow (2011)]]
```

---

## 3. Source / Literature Note

One note per book, article, talk, or paper. Holds your *processing* of the source.

```markdown
---
created: 2026-02-14
type: source
author: 
title: 
year: 
medium: book | article | video | podcast
rating: 
tags: []
---

# <Author> — <Title> (<Year>)

**Summary (my words):** <3–5 sentences>

## Key ideas
1. <idea> → [[linked concept note]]
2. <idea> → [[linked concept note]]
3. <idea> → [[linked concept note]]

## Best quotes
> "<quote>" — p. <page>

## My reactions
<What surprised, annoyed, or excited you. What you disagree with.>

## Actions / follow-ups
- [ ] <thing to try or investigate>

## Connections
- Part of: [[MOC — Topic]]
- Related: [[other source]]
```

---

## 4. MOC (Map of Content)

A hub note that organises a theme. This is your navigation layer.

```markdown
---
created: 2026-02-14
type: moc
tags: [moc]
---

# MOC — <Topic>

**Scope:** <what this MOC covers and what it excludes>

## Start here
- [[most important note]]
- [[second most important note]]

## Core concepts
- [[concept 1]]
- [[concept 2]]
- [[concept 3]]

## Sources
- [[Author — Title (Year)]]

## Open questions
- <what you still don't understand>

## Related MOCs
- [[MOC — adjacent topic]]
```

---

## 5. Project Hub

The single entry point for a project.

```markdown
---
created: 2026-02-14
type: project
status: active | paused | done
deadline: 2026-03-31
---

# <Project Name>

**Outcome:** <the concrete end state>
**Deadline:** <date>
**Status:** <active>

## Next actions
- [ ] <action>
- [ ] <action>

## Notes & research
- [[note]]
- [[note]]

## Decisions
| Date | Decision | Rationale |
|------|----------|-----------|
| 2026-02-14 | Chose X over Y | cheaper, faster |

## Log
- 2026-02-14 — Project started
```

---

## 6. Area Hub

For ongoing responsibilities.

```markdown
---
created: 2026-02-14
type: area
review: weekly | monthly
---

# Area — <Name>

**Standard:** <what "maintained" looks like>
**Review cadence:** <weekly / monthly>

## Standing notes
- [[checklist]]
- [[reference doc]]

## Metrics
- <metric>: <current value>

## Open loops
- [ ] <thing to keep an eye on>
```

---

## 7. Meeting Note

```markdown
---
created: 2026-02-14
type: meeting
attendees: []
project: 
---

# 2026-02-14 — <Meeting name>

**Attendees:** <names>
**Purpose:** <one line>

## Notes
- <point>

## Decisions
- <decision>

## Action items
- [ ] <action> — @owner — due <date>

## Follow-ups
- [[related note]]
```

---

## 8. Daily Note

The backbone of a daily-capture workflow.

```markdown
---
date: 2026-02-14
type: daily
---

# 2026-02-14

## Focus
- <top 1–3 priorities>

## Captured
- <quick captures, links, thoughts>

## Notes
- [[meeting note]]
- [[concept note]]

## Reflection
- <what worked, what didn't>
```

---

## 9. Decision Log

Record *why* you decided something — invaluable months later.

```markdown
---
created: 2026-02-14
type: decision
status: decided
---

# Decision: <what you decided>

**Date:** 2026-02-14
**Context:** <the situation>
**Options considered:**
1. <option A> — pros/cons
2. <option B> — pros/cons

**Decision:** <what you chose>
**Rationale:** <why>
**Revisit by:** <date>
```

---

## 10. Idea / Spark Note

For half-formed ideas worth keeping.

```markdown
---
created: 2026-02-14
type: idea
status: seed | developing | shelved
---

# <Idea in one sentence>

**The spark:** <what triggered it>

**Why it could matter:** <potential value>

**First steps if pursued:**
- [ ] <step>

**Connections:** [[related note]]
```

---

## Template Usage Cheat Sheet

| Situation | Template |
|-----------|----------|
| Random thought, no time | Quick Capture |
| Finished processing an idea | Concept / Permanent |
| Read a book or article | Source / Literature |
| Theme has 5+ notes | MOC |
| New project with a deadline | Project Hub |
| Ongoing responsibility | Area Hub |
| Attended a meeting | Meeting Note |
| Start of the day | Daily Note |
| Made a choice worth remembering | Decision Log |
| Half-baked idea | Idea / Spark |

---

## Frontmatter Fields Reference

| Field | Values | Used in |
|-------|--------|---------|
| `type` | capture, concept, source, moc, project, area, meeting, daily, decision, idea | All |
| `status` | active, paused, done, seed, developing, shelved, decided | Project, Idea, Decision |
| `tags` | lower-case, hyphenated | All |
| `created` / `date` | YYYY-MM-DD | All |
| `source` | URL or citation | Capture, Source |

> **Tip:** keep frontmatter minimal. Only add a field if you'll actually filter or search on it. Every unused field is friction.

---

## Writing Good Titles

Titles are how you find notes and how they read inside other notes.

| Weak title | Strong title |
|------------|--------------|
| "Notes" | "Spaced repetition beats rereading for retention" |
| "Marketing idea" | "Scarcity framing increases conversion on limited offers" |
| "Book" | "Newport — Deep Work (2016)" |
| "Meeting" | "2026-02-14 — Client kickoff" |

**Test:** can you understand the note's point from the title alone? If not, rewrite it.
