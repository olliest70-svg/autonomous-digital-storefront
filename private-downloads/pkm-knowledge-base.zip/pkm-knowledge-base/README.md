# PKM Knowledge Base

**A complete, opinionated system for building a personal knowledge management (PKM) vault that actually gets used.**

Most people who try to "build a second brain" end up with a graveyard of half-finished notes, a folder structure they keep redesigning, and a nagging feeling that they're doing it wrong. This product fixes that. It gives you a working method — not a philosophy — for capturing, processing, connecting, and *retrieving* knowledge so that your notes compound in value instead of rotting in a folder.

This kit is built for people who think for a living: writers, researchers, consultants, developers, students, and founders. If you read a lot, have too many ideas and too little recall, and want a system that survives contact with real life, this is for you.

---

## What's Inside

| File | What it does | Use it when |
|------|--------------|-------------|
| `README.md` | The full system overview, philosophy, and workflow | Read first, then keep as reference |
| `para-setup.md` | Step-by-step setup of a PARA-based folder structure | Day 1 — build your vault |
| `note-templates.md` | Copy-paste templates for every note type | Whenever you create a note |
| `progressive-summarisation.md` | The layered note-taking method for reading & research | When processing sources |
| `linked-notes-guide.md` | How to connect notes, name them, and build a graph that works | Ongoing — the connective tissue |

---

## The Core Problem This Solves

Knowledge work fails at three points:

1. **Capture is lossy.** You read something brilliant, highlight it, and never see it again.
2. **Storage is a junk drawer.** Notes go into folders that reflect *when* you saved them, not *what they're for*.
3. **Retrieval is broken.** You *know* you wrote something about pricing psychology six months ago — but you can't find it, so you rewrite it from scratch.

The result is that your notes cost you time and return nothing. A PKM system is only valuable if it closes the loop: **capture → process → connect → retrieve → create.**

This kit is engineered around that loop.

---

## The Philosophy: Notes Are Assets, Not Archives

Three principles run through every file in this kit.

### 1. Organise by actionability, not by topic
Topic folders ("Marketing", "Psychology", "Tech") feel tidy but are useless because everything is equally important. Instead, organise by **how you'll use the note**: is it an active project, an ongoing area of responsibility, a reference, or dead weight? That's the PARA method, and it's the backbone of `para-setup.md`.

### 2. Write notes for your future self, who has amnesia
Your future self will not remember the context. Every note must stand alone: a clear title, a one-line summary, and enough links that it can be understood without the source. Templates enforce this.

### 3. Connections beat collections
A thousand isolated notes are worth less than a hundred well-linked ones. The value of a PKM vault is in the *edges* between notes, not the nodes. `linked-notes-guide.md` is dedicated to this.

---

## The Workflow at a Glance

```
┌─────────────┐   ┌──────────────┐   ┌───────────────┐   ┌──────────────┐
│   CAPTURE   │──▶│   PROCESS    │──▶│    CONNECT    │──▶│   RETRIEVE   │
│  Inbox note │   │ Progressive  │   │  Link to MOCs │   │ Search + MOC │
│  (fast, raw)│   │ summarisation│   │  & related    │   │  + backlinks │
└─────────────┘   └──────────────┘   └───────────────┘   └──────────────┘
       ▲                                                        │
       └──────────────────────  CREATE  ◀───────────────────────┘
                    (write, decide, build)
```

### Stage 1 — Capture (seconds)
Everything lands in a single **Inbox** note or folder. No decisions, no filing. If you have to think about where something goes, you'll stop capturing. Capture friction must be near zero. Use a mobile shortcut, a browser clipper, or a single "Quick Capture" note.

### Stage 2 — Process (minutes, daily)
Once a day, empty the inbox. For each item, ask: *Is this actionable, reference, or noise?* Noise gets deleted. Actionable items become tasks in a project. Reference items get processed using **progressive summarisation** (`progressive-summarisation.md`): highlight the good bits, bold the best bits, write a one-paragraph summary at the top.

### Stage 3 — Connect (ongoing)
When you create or process a note, link it. At minimum, link it to a **Map of Content (MOC)** — a hub note for a theme. Over time, MOCs become your real navigation layer, more useful than folders or search.

### Stage 4 — Retrieve (instant)
You retrieve in three ways: **search** (when you know the keyword), **MOCs** (when you know the theme), and **backlinks** (when you're reading one note and want to see what else touches it). A good vault makes all three work.

### Stage 5 — Create (the payoff)
The whole point. You write the article, make the decision, ship the project — using assembled notes as raw material instead of a blank page.

---

## Choosing Your Tool

This system is **tool-agnostic**. It works in Obsidian, Logseq, Roam, Notion, Apple Notes, Bear, or plain Markdown files in a folder. The files use Markdown conventions (`[[wikilinks]]`, `#tags`) that map cleanly to most modern tools.

| Tool | Best for | Link syntax | Notes |
|------|----------|-------------|-------|
| **Obsidian** | Local-first, power users | `[[Note Name]]` | Best fit for this kit; huge plugin ecosystem |
| **Logseq** | Outliners, daily-note workflow | `[[Note Name]]` | Block-level references |
| **Notion** | Teams, databases | `@` mentions / relations | Use a "Notes" database with relations |
| **Apple Notes** | Simplicity, Apple ecosystem | `[[` (limited) | Use tags heavily; no real graph |
| **Plain Markdown** | Maximum portability | `[[...]]` convention | Works everywhere, no lock-in |

**Recommendation:** if you're starting fresh and value longevity, use **Obsidian** with local Markdown files. Your notes are yours, forever, in a format that will outlive any app.

---

## Quick Start (Your First 60 Minutes)

1. **Create your vault** — a single folder. Name it something neutral like `brain` or `vault`.
2. **Build the PARA skeleton** — follow `para-setup.md` to create `0-Inbox`, `1-Projects`, `2-Areas`, `3-Resources`, `4-Archive`.
3. **Add the templates** — copy the templates from `note-templates.md` into a `_templates` folder.
4. **Capture 5 things** — dump whatever's in your head right now into the Inbox. Don't organise.
5. **Process one item** — pick the most interesting and run it through progressive summarisation.
6. **Create your first MOC** — make a note called `MOC — <a topic you care about>` and link three notes to it.
7. **Set a daily 10-minute review** — same time each day. This is the habit that makes everything else work.

That's it. You now have a functioning system. Everything else is refinement.

---

## The Daily & Weekly Rhythm

A PKM system lives or dies on maintenance. Keep it light.

### Daily (10 minutes)
- Empty the Inbox (process or delete every item)
- Capture anything new that surfaced
- Link today's notes to at least one MOC

### Weekly (30 minutes)
- Review each active Project — is it still active? Archive if done or dead
- Promote any recurring theme into a new MOC
- Prune orphan notes (notes with no links) — link them or delete them

### Monthly (60 minutes)
- Review Areas — are you neglecting any?
- Merge duplicate notes
- Re-read one old note and see what it sparks

---

## Common Failure Modes (and Fixes)

| Failure | Why it happens | Fix |
|---------|----------------|-----|
| **Collector's fallacy** | Saving feels like learning | Only save what you'll use; process within 48h |
| **Folder churn** | Redesigning structure instead of writing | Lock your structure for 90 days |
| **Orphan notes** | Capturing without linking | Every note links to ≥1 MOC |
| **Over-tagging** | Tags multiply endlessly | Max 20 tags total; prefer links |
| **Never reviewing** | No scheduled ritual | Daily 10-min inbox zero |
| **Perfect notes** | Trying to write final drafts | Capture rough, refine later |

---

## Design Principles (The Rules)

1. **One inbox.** Everything enters through one door.
2. **Capture fast, process later.** Never block capture with filing decisions.
3. **Notes are atomic.** One idea per note where possible.
4. **Titles are sentences.** "Pricing anchors reduce perceived cost" beats "Pricing notes".
5. **Link generously.** A note with no links is a note you'll never find.
6. **Summarise in layers.** Highlight → bold → summary → remix.
7. **Review on a schedule.** Systems decay without rituals.
8. **Archive, don't delete.** Move things out of sight, keep them recoverable.
9. **Let structure emerge.** Don't pre-build folders for things that don't exist yet.
10. **Optimise for retrieval, not for tidiness.** A messy vault you can search beats a tidy one you can't.

---

## What "Good" Looks Like After 90 Days

- Your Inbox is empty most days.
- You have 5–15 MOCs covering your real interests.
- New notes link to existing notes automatically because the graph is dense.
- You can find any past idea in under 30 seconds.
- You've written at least one thing (article, decision, plan) directly from assembled notes.
- You no longer rewrite things you already figured out.

---

## How to Use This Kit

- **First read:** skim this README, then work through `para-setup.md` top to bottom.
- **Daily reference:** keep `note-templates.md` open; copy templates as needed.
- **When reading/researching:** follow `progressive-summarisation.md`.
- **When your graph feels messy:** return to `linked-notes-guide.md`.

Each file is self-contained but they're designed to be used together. The folder structure (PARA) holds the notes, the templates standardise them, progressive summarisation distils them, and linking turns them into a network.

---

## License & Usage

This kit is for personal and professional use by the purchaser. Adapt the templates freely — they're starting points, not scripture. Attribution appreciated but not required. Do not redistribute or resell.

---

*Build the system once. Feed it daily. Let it pay you back for years.*
