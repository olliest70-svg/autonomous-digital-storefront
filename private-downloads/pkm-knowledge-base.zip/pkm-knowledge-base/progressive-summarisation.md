# Progressive Summarisation — How to Read Less and Remember More

Progressive summarisation is a method (popularised by Tiago Forte) for processing sources in **layers**, so you can extract value now *and* later without re-reading everything. The idea: each pass adds a layer of compression, and you only go deeper when a note proves useful.

The core principle: **summarise in proportion to how often you revisit.** Most notes get one layer. The few that matter get four.

---

## The Four Layers

| Layer | Name | Effort | What you do |
|-------|------|--------|-------------|
| 1 | **Capture** | Seconds | Save the full source as-is |
| 2 | **Highlight** | Minutes | Bold the passages that matter |
| 3 | **Bold** | Minutes | Bold the best of the highlights |
| 4 | **Summary** | Minutes | Write an executive summary at the top |
| 5 | **Remix** | On demand | Turn it into something new |

> Layer 1 is capture; layers 2–5 are the summarisation passes. You do them progressively — never all at once.

---

## Layer 1 — Capture

Save the whole thing. Article text, book highlights, transcript, PDF. Don't edit, don't judge.

**Rules:**
- Capture the *entire* source, not just the bits you like — you don't know yet what you'll need.
- Include the source link and date.
- Put it in `0-Inbox/` or straight into `3-Resources/`.

**Why keep everything?** Because the context around a highlight is often what makes it meaningful later. Trimming at capture time loses information you can't recover.

---

## Layer 2 — Highlight

On first read-through, **bold** the passages that stand out. Don't think too hard — if it catches your eye, bold it.

**Rules:**
- Bold whole sentences or short paragraphs, not single words.
- Aim to bold ~10–20% of the text.
- Do this in one pass, quickly.

**Example (raw):**

```
Deep work is the ability to focus without distraction on a cognitively
demanding task. It's a skill that allows you to quickly master complicated
information and produce better results in less time. Deep work will make
you better at what you do and provide the sense of true fulfillment that
comes from craftsmanship.
```

**After highlighting:**

```
Deep work is the ability to focus without distraction on a cognitively
demanding task. **It's a skill that allows you to quickly master complicated
information and produce better results in less time.** Deep work will make
you better at what you do and provide the sense of true fulfillment that
comes from craftsmanship.
```

---

## Layer 3 — Bold the Best

When you return to the note (because it's relevant to something), **bold the best of the highlights**. This is a second compression pass.

**Rules:**
- Only bold what's *most* important — maybe 20–30% of the highlights.
- This is where the note's essence starts to emerge.
- Don't do this on first capture — only when you revisit.

**After bolding the best:**

```
Deep work is the ability to focus without distraction on a cognitively
demanding task. **It's a skill that allows you to quickly master complicated
information and produce better results in less time.** Deep work will make
you better at what you do and provide the sense of true fulfillment that
comes from craftsmanship.
```

*(In a real note, the bolded sentence would be visually distinct — e.g. highlighted in a second colour or bolded within an already-highlighted block.)*

---

## Layer 4 — Executive Summary

Write a short summary **at the top** of the note, in your own words. This is the layer you'll actually read 90% of the time.

**Rules:**
- 3–5 sentences maximum.
- In your own words — not copied.
- Include *why it matters to you*, not just what it says.

**Example summary:**

```markdown
**Summary:** Deep work is undistracted focus on hard cognitive tasks. It's
the skill that produces disproportionate output and mastery. The book argues
that this ability is becoming rarer and more valuable simultaneously, so
cultivating it is a competitive advantage. For me: my best writing happens
in 90-minute deep blocks, so protecting them is the highest-leverage habit.
```

Now the note reads top-down: summary → best bits → highlights → full source. Anyone can stop at any layer.

---

## Layer 5 — Remix

When a note becomes raw material for something new — an article, a decision, a plan — **remix** it. Pull the summary and key ideas into a new note and build on them.

This is the payoff layer. It's also the *only* layer that creates new value rather than compressing existing value.

**Example remix note:**

```markdown
# Why I'm blocking mornings for deep work

Building on [[Newport — Deep Work (2016)]]:
- Deep work produces disproportionate output
- It's becoming rarer, so more valuable
- My best writing happens in 90-min blocks

**Decision:** block 8–10am daily, no meetings, phone in another room.
See [[Decision: Morning deep work blocks]].
```

---

## The Compression Ladder (Worked Example)

Watch a note compress across passes:

| Layer | Size | Content |
|-------|------|---------|
| Capture | 8,000 words | Full article |
| Highlight | ~1,200 words | 15% bolded |
| Bold best | ~300 words | Top 25% of highlights |
| Summary | ~60 words | Exec summary |
| Remix | ~20 words | One bullet in a new note |

**The point:** you can read the note at any resolution. Need the gist? Read the summary. Need detail? Read the highlights. Need everything? Read the source. You never have to re-read 8,000 words to get 60 words of value.

---

## When to Do Each Layer

| Trigger | Do this layer |
|---------|---------------|
| You just captured it | Layer 1 (capture) |
| First read-through | Layer 2 (highlight) |
| You return to the note for a real reason | Layer 3 (bold best) |
| The note is clearly important | Layer 4 (summary) |
| You're using it to create something | Layer 5 (remix) |

**Critical rule:** don't do layers 3–5 speculatively. Only compress when a note has *earned* the effort by being useful. This is what keeps the system sustainable.

---

## Progressive Summarisation for Different Media

### Books
- Highlight as you read (Kindle export or manual).
- On finishing, write the summary layer.
- Bold the best across the whole book.

### Articles / Blog posts
- Capture full text.
- Highlight in one pass.
- Summarise immediately — articles are short enough.

### Videos / Podcasts
- Capture the transcript (many tools auto-generate one).
- Timestamp key moments.
- Highlight the transcript; summarise.

### Meetings
- Capture raw notes.
- Highlight decisions and action items.
- Summarise into a meeting note template.

### Your own thinking
- Capture the raw dump.
- Highlight the parts that feel true.
- Summarise into a concept note.

---

## Common Mistakes

| Mistake | Fix |
|---------|-----|
| Doing all layers at once | Do layer 2 on capture; the rest only when you revisit |
| Highlighting everything | Cap at ~15%; if everything matters, nothing does |
| Copying instead of summarising | Summary must be in your own words |
| Never remixing | Set a monthly "remix" session to turn notes into output |
| Over-processing low-value notes | Let most notes stay at layer 2 forever |
| Losing the source | Always keep the original text below your layers |

---

## A Full Worked Note

```markdown
---
created: 2026-02-14
type: source
author: Cal Newport
title: Deep Work
year: 2016
tags: [productivity, focus]
---

# Newport — Deep Work (2016)

**Summary (Layer 4):** Deep work is undistracted focus on cognitively
demanding tasks; it produces disproportionate output and mastery. Newport
argues the ability is becoming rarer and more valuable at once, making it a
competitive edge. For me: my best writing happens in 90-minute deep blocks,
so protecting them is my highest-leverage habit.

## Key ideas
1. **Deep work produces disproportionate value** → [[Deep work is a competitive advantage]]
2. **Shallow work is easy to replicate, so it's low value** → [[Shallow work is fungible]]
3. **Focus is trainable** → [[Attention is a muscle you can train]]

## Highlights (Layer 2/3)
> **It's a skill that allows you to quickly master complicated information
> and produce better results in less time.** Deep work will make you better
> at what you do and provide the sense of true fulfillment that comes from
> craftsmanship.

## Full source
<full text or link to source>

## Connections
- Part of: [[MOC — Productivity]]
- Related: [[Ego is the Enemy — focus chapter]]
```

---

## Summary

1. **Capture** everything.
2. **Highlight** what stands out.
3. **Bold** the best of the highlights — only on revisit.
4. **Summarise** in your own words — only for important notes.
5. **Remix** into new work — the payoff.

Compress in proportion to value. Most notes stay shallow; the important ones get deep. That's the whole method.
