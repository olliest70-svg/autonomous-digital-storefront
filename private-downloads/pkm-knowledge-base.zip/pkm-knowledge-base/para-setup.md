# PARA Setup — Build Your Vault Structure

PARA is a four-category organising system created by Tiago Forte. It sorts everything by **actionability** rather than topic, which is why it survives contact with real life. This guide walks you through building it step by step.

**The four categories:**

- **P — Projects:** short-term efforts with a goal and a deadline.
- **A — Areas:** ongoing responsibilities with a standard to maintain.
- **R — Resources:** topics of interest that may become useful later.
- **A — Archive:** inactive items from the other three.

The key insight: **Projects and Areas are about *you*; Resources are about *the world*.** A project is "Launch newsletter"; an area is "Writing practice"; a resource is "Email marketing tactics".

---

## Step 1 — Create the Folder Skeleton

Create these top-level folders in your vault. The number prefixes force sort order and keep the Inbox on top.

```
vault/
├── 0-Inbox/            # Everything lands here first
├── 1-Projects/         # Active, deadline-driven efforts
├── 2-Areas/            # Ongoing responsibilities
├── 3-Resources/        # Reference material by topic
├── 4-Archive/          # Inactive projects & areas
├── _templates/         # Note templates (excluded from search)
└── _attachments/       # Images, PDFs, files
```

> **Why numbers?** They guarantee the Inbox sorts first and the Archive last in any file explorer, regardless of tool. If you dislike numbers, use emoji or plain names — just keep the *order*.

---

## Step 2 — Populate Projects

A **Project** has a clear finish line. If it doesn't, it's an Area. Create one folder per active project. Aim for **5–15 active projects** — more than that and nothing gets done.

**Examples:**

| Project folder | Goal | Deadline |
|----------------|------|----------|
| `Launch Newsletter` | Ship first issue to 100 subscribers | Mar 31 |
| `Website Redesign` | New site live | Apr 15 |
| `Q2 Tax Filing` | File returns | May 31 |
| `Book Proposal` | Send to 3 agents | Jun 30 |

Each project folder contains:

```
1-Projects/Launch Newsletter/
├── Launch Newsletter.md      # Project hub note (overview + links)
├── Drafts/
├── Research/
└── Assets/
```

**The project hub note** is the single entry point. It links to every note related to the project, tracks status, and lists next actions. Template:

```markdown
# Launch Newsletter

**Status:** In progress
**Deadline:** 2026-03-31
**Outcome:** First issue sent to 100 subscribers

## Next Actions
- [ ] Choose email platform
- [ ] Write welcome sequence
- [ ] Design template

## Notes
- [[Email platform comparison]]
- [[Newsletter positioning]]
- [[Welcome sequence draft]]

## Log
- 2026-02-01 — Project started
```

---

## Step 3 — Populate Areas

An **Area** is an ongoing standard you maintain with no end date. You don't "finish" your health, your finances, or your writing practice — you maintain them.

**Examples:**

| Area folder | Standard to maintain |
|-------------|----------------------|
| `Health` | Exercise 4x/week, sleep 7h+ |
| `Finances` | Budget reviewed monthly |
| `Writing Practice` | Publish weekly |
| `Team Management` | 1:1s every 2 weeks |
| `Home & Admin` | Bills paid, docs filed |

Areas hold **reference material and recurring notes** — meeting notes, checklists, standing docs. Each area gets a hub note too:

```markdown
# Area — Writing Practice

**Standard:** Publish one essay per week
**Review cadence:** Weekly

## Standing Notes
- [[Essay ideas backlog]]
- [[Style guide]]
- [[Publishing checklist]]

## Metrics
- Essays published this quarter: 6
```

**Projects vs Areas test:** *Will this ever be "done"?* Yes → Project. No → Area.

---

## Step 4 — Populate Resources

**Resources** are topics you're interested in that aren't tied to an active project or responsibility. This is where most of your reading notes, book highlights, and reference material live.

Organise resources by **topic**, but don't over-nest. Two levels max.

```
3-Resources/
├── Psychology/
├── Marketing/
├── Systems Thinking/
├── Design/
└── Productivity/
```

Inside each topic, notes are **flat** — no sub-folders. Use links and MOCs to organise, not folders.

```
3-Resources/Psychology/
├── MOC — Psychology.md
├── Anchoring effect.md
├── Loss aversion.md
├── Cognitive load theory.md
└── Spaced repetition.md
```

> **Rule:** if a topic has fewer than 5 notes, don't create a folder — just put the notes in `3-Resources/` root. Let structure emerge.

---

## Step 5 — Use the Archive

The Archive is where things go when they're **no longer active but worth keeping**. This is what keeps your active workspace clean.

Move to Archive when:
- A project is complete or abandoned
- An area is no longer your responsibility
- A resource topic no longer interests you

**Never delete** — archive. You lose nothing and gain a clean workspace. If you need something later, search finds it.

```
4-Archive/
├── 2025/
│   ├── Old Website Project/
│   └── Podcast Idea/
└── 2026/
    └── Completed Course Notes/
```

---

## Step 6 — The Inbox Workflow

The Inbox is sacred: **everything enters here, nothing stays here.**

### Capture rules
- One tap to capture (mobile shortcut, browser clipper, or a single `0-Inbox/Quick Capture.md`)
- No filing decisions at capture time
- Speed over structure

### Processing rules (daily, 10 minutes)
For each item, decide in under 10 seconds:

| Question | Action |
|----------|--------|
| Is it actionable? | → Task in a Project |
| Is it reference? | → Resource note (process it) |
| Is it a responsibility? | → Area note |
| Is it noise? | → Delete |
| Not sure yet? | → Leave it one more day (max 3) |

**Inbox Zero** means the inbox is empty of *undecided* items — not that you've finished everything. Decide, file, move on.

---

## Step 7 — Naming Conventions

Consistent names make search and linking reliable.

| Type | Convention | Example |
|------|------------|---------|
| Project hub | `Project — Name` or just `Name` | `Launch Newsletter` |
| Area hub | `Area — Name` | `Area — Finances` |
| MOC | `MOC — Topic` | `MOC — Psychology` |
| Source note | `Author — Title (Year)` | `Kahneman — Thinking Fast and Slow (2011)` |
| Concept note | Full sentence | `Anchoring biases first offers` |
| Meeting note | `YYYY-MM-DD — Meeting name` | `2026-02-14 — Client kickoff` |
| Daily note | `YYYY-MM-DD` | `2026-02-14` |

**Why sentence titles for concepts?** Because they're self-describing and link naturally in prose. "Anchoring biases first offers" reads well inside another note; "Anchoring" doesn't.

---

## Step 8 — Migrating an Existing Mess

Don't rebuild from scratch. Migrate incrementally:

1. **Create the new skeleton** alongside your old structure.
2. **Move active projects first** — the ones with deadlines this quarter.
3. **Move areas** you actively maintain.
4. **Bulk-move the rest to Resources** — don't sort it now.
5. **Archive everything you haven't touched in 6 months** — in bulk, without review.
6. **Process the Inbox daily** from now on.

You'll have 90% of the value within a week, and you can refine Resources over months.

---

## Folder Structure Cheat Sheet

```
vault/
├── 0-Inbox/
│   └── Quick Capture.md
├── 1-Projects/
│   ├── Launch Newsletter/
│   │   ├── Launch Newsletter.md
│   │   └── Research/
│   └── Website Redesign/
├── 2-Areas/
│   ├── Area — Finances.md
│   └── Area — Health.md
├── 3-Resources/
│   ├── Psychology/
│   │   ├── MOC — Psychology.md
│   │   └── Anchoring effect.md
│   └── Marketing/
├── 4-Archive/
│   └── 2025/
├── _templates/
└── _attachments/
```

---

## Common PARA Mistakes

| Mistake | Fix |
|---------|-----|
| Too many projects | Keep 5–15; archive the rest |
| Confusing Areas and Resources | Areas = your responsibilities; Resources = the world's topics |
| Deep folder nesting in Resources | Max 2 levels; use links instead |
| Never archiving | Schedule a monthly archive pass |
| Filing at capture time | Capture to Inbox, decide later |
| Rebuilding structure constantly | Lock it for 90 days |

---

## Next Steps

Once your structure is in place:
1. Copy the templates from `note-templates.md` into `_templates/`.
2. Learn the reading method in `progressive-summarisation.md`.
3. Start linking with `linked-notes-guide.md`.

Your structure is now done. Don't touch it again for 90 days — spend that energy on notes instead.
