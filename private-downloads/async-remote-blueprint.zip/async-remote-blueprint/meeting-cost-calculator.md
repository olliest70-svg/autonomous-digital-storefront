# See Exactly How Much That Meeting Cost (Then Never Schedule It Again)

> **Goal:** Put a real dollar figure on every recurring meeting so you can decide — with data — which ones to keep, shorten, or kill. Most teams cut 30–50% of their meeting load in the first month.

---

## Why this matters

Meetings feel free. They aren't. A 30-minute call with 8 people isn't "30 minutes" — it's **4 person-hours**, plus the context-switching cost of interrupting 8 people mid-task. This calculator makes that cost visible.

---

## The formula

```
Cost per meeting = Attendees × Duration (hours) × Average hourly cost

Annual cost     = Cost per meeting × Meetings per year
```

**Average hourly cost** = (annual salary × overhead multiplier) ÷ working hours per year

- Overhead multiplier: **1.25–1.4** (benefits, equipment, software, management).
- Working hours per year: **~1,800** (after holidays, PTO, sick days).

---

## Quick reference: hourly cost by salary

| Annual salary | Hourly cost (×1.3 overhead) |
|---|---|
| $50,000 | ~$36 |
| $80,000 | ~$58 |
| $120,000 | ~$87 |
| $160,000 | ~$116 |
| $200,000 | ~$144 |

---

## Worked example

**The weekly all-hands.** 20 people, 45 minutes, average salary $120k.

```
Hourly cost     = ($120,000 × 1.3) ÷ 1,800 = $86.67
Cost per meeting = 20 × 0.75 × $86.67     = $1,300
Annual cost      = $1,300 × 52             = $67,600
```

**$67,600 a year** for one recurring meeting. If half of it is status updates that could be a written digest, you're burning ~$34k annually on information that could be a doc.

---

## Calculator table (fill in your meetings)

| Meeting | Attendees | Minutes | Hourly cost | Cost/meeting | Frequency | Annual cost | Verdict |
|---|---|---|---|---|---|---|---|
| Daily standup | 8 | 15 | $87 | $174 | 250× | $43,500 | Replace with async |
| Weekly all-hands | 20 | 45 | $87 | $1,300 | 52× | $67,600 | Shorten to 20 min |
| Sprint planning | 10 | 120 | $87 | $1,740 | 26× | $45,240 | Keep (high value) |
| Design review | 6 | 60 | $87 | $522 | 26× | $13,572 | Keep |
| Status sync | 5 | 30 | $87 | $218 | 52× | $11,310 | Kill → doc |
| 1:1 | 2 | 30 | $87 | $87 | 26× | $2,262 | Keep |
| **TOTAL** | | | | | | **$183,484** | |

> Copy this table into a spreadsheet and sort by annual cost. Attack the top of the list first.

---

## The decision tree: keep, shorten, or kill?

Ask these questions in order for each recurring meeting:

```
1. Does it have a written agenda sent in advance?
   └─ NO → Add one, or cancel the next instance.

2. Could the outcome be achieved with a doc, thread, or short video?
   └─ YES → Replace it. (Status updates, FYIs, one-way announcements.)

3. Does it require real-time back-and-forth (debate, brainstorm, negotiation)?
   └─ NO → Make it async.

4. Is every attendee essential to the outcome?
   └─ NO → Trim the list. "Optional" attendees should get a summary.

5. Could it be half as long?
   └─ YES → Halve it. Most meetings expand to fill their slot.

6. Does it still earn its cost?
   └─ NO → Kill it. Announce the replacement channel.
```

---

## Meeting types: what to do

| Meeting type | Async-able? | Recommendation |
|---|---|---|
| Daily status | ✅ Fully | Replace with async standup |
| Weekly all-hands | 🟡 Partly | Keep 15 min live + written digest |
| Sprint planning | 🟡 Partly | Async pre-read + 60-min live |
| Retrospective | ❌ Mostly | Keep live (needs trust + nuance) |
| Brainstorm | 🟡 Partly | Async idea doc first, then live synthesis |
| 1:1 | ❌ No | Keep — highest ROI meeting you have |
| Decision meeting | 🟡 Partly | Async RFC + short live to ratify |
| Demo / show-and-tell | ✅ Fully | Record a 5-min Loom instead |
| Client status | 🟡 Partly | Written update + optional call |

---

## The "cost of a bad meeting" add-on

Interrupting a person mid-deep-work costs more than the meeting itself. Research on context switching suggests **~15–25 minutes to fully refocus**. Factor it in:

```
True cost = Meeting cost + (Attendees × Refocus time × Hourly cost)

Example: 8 people, 30-min meeting, 20 min refocus each
= $348 + (8 × 0.33 × $87)
= $348 + $230 = $578 true cost
```

**Rule of thumb:** a meeting's true cost is roughly **1.5× its naive cost** when it fragments deep work.

---

## Meeting hygiene rules (adopt these)

1. **No agenda, no meeting.** If the organizer can't write 3 bullets, cancel it.
2. **Default to 25 or 50 minutes**, not 30 or 60 — leave buffer.
3. **Cap attendees.** If you need more than 8, you probably need a doc.
4. **Record and summarize.** Anyone who couldn't attend reads the notes.
5. **End with owners and dates.** Every action item gets a name and a deadline.
6. **Review recurring meetings quarterly.** Delete the ones nobody defends.

---

## Quarterly meeting audit template

```markdown
## Q3 Meeting Audit — [Team]

**Total recurring meeting cost:** $183,484/yr
**Target reduction:** 30% → save $55,045/yr

| Meeting | Action | Owner | Effective |
|---|---|---|---|
| Daily standup | → async | @lead | 2026-07-01 |
| Weekly all-hands | 45 → 20 min | @lead | 2026-07-01 |
| Status sync | Kill | @lead | 2026-07-01 |

**Result after 30 days:** meetings down 42%, reclaimed 6.2 hrs/person/week.
```

---

## Copy-paste calculator (spreadsheet formulas)

If you're building this in Google Sheets or Excel:

```
A1: Annual salary         B1: 120000
A2: Overhead multiplier   B2: 1.3
A3: Hours per year        B3: 1800
A4: Hourly cost           B4: =B1*B2/B3

A6: Attendees             B6: 8
A7: Minutes               B7: 30
A8: Frequency/year        B8: 52
A9: Cost per meeting      B9: =B6*(B7/60)*B4
A10: Annual cost          B10: =B9*B8
```

> **Pro tip:** Sort your meeting list by annual cost and screenshot the top 5. That screenshot is the most persuasive argument for change you'll ever show a manager.
