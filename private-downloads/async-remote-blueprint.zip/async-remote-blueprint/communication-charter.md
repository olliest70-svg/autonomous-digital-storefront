# The Rules Your Remote Team Needs (But Nobody Wrote Down)

> **Goal:** One shared agreement on *where* we talk, *how fast* we respond, and *how* we escalate — so nobody guesses and nobody gets pinged at midnight.

**Team:** [Team name] · **Owner:** [Name] · **Last reviewed:** YYYY-MM-DD · **Next review:** YYYY-MM-DD

---

## 1. Our principles

1. **Written by default.** If it isn't written, it didn't happen.
2. **Async first, sync when it matters.** Meetings are the exception.
3. **Respect focus time.** No expectation of instant replies.
4. **Public by default.** Decisions happen in channels, not DMs.
5. **Context over speed.** A clear message beats a fast one.
6. **Assume good intent.** Text loses tone; give people the benefit of the doubt.

---

## 2. Channels: what goes where

| Channel | Purpose | Example | Response expectation |
|---|---|---|---|
| **#announcements** | One-way, company/team-wide news | Policy changes, launches | Read within 1 day |
| **#team-general** | Team discussion, questions, FYIs | "Anyone know how X works?" | Within 1 business day |
| **#project-x** | Everything about one project | Updates, blockers, decisions | Within 1 business day |
| **#incidents** | Live outages and urgent issues | "Prod is down" | Immediate |
| **#random / #watercooler** | Social, non-work | Memes, weekend plans | No expectation |
| **DMs** | Sensitive or personal only | 1:1 feedback, HR matters | Within 1 business day |
| **Email** | External parties, formal records | Contracts, clients | Within 1 business day |
| **Docs / Wiki** | Durable knowledge | Specs, decisions, runbooks | N/A (async read) |

**Rule:** If a DM turns into a decision that affects others, **move it to a channel or a doc.**

---

## 3. Response-time expectations

We distinguish **urgent** from **normal**. Most things are normal.

| Priority | How to signal | Expected response |
|---|---|---|
| **P0 — Urgent** | `@channel` in #incidents, or call | Immediately during on-call hours |
| **P1 — Today** | Direct `@name` mention | Within 4 working hours |
| **P2 — Normal** | Post in the right channel | Within 1 business day |
| **P3 — FYI** | Post, no mention | When you get to it |
| **P4 — Nice to have** | Backlog / doc comment | No expectation |

> **Default assumption:** if someone hasn't replied, they're heads-down or offline. Wait one business day before following up.

---

## 4. Working hours & time zones

- **Core overlap hours:** 13:00–16:00 UTC (everyone aims to be online).
- **Outside overlap:** async only. No expectation of replies.
- **Post your hours** in your Slack/Teams profile and calendar.
- **Never expect a reply** outside someone's stated hours unless it's a P0.
- **Schedule meetings** inside overlap hours whenever possible.

```
Example team spread:
  Sam   (UTC-8)  06:00–14:00  → overlap 13:00–14:00
  Priya (UTC+0)  09:00–17:00  → overlap 13:00–16:00
  Maya  (UTC+5.5) 14:30–22:30 → overlap 14:30–16:00
  Dan   (UTC+10) 23:00–07:00  → mostly async
```

---

## 5. How to write a good async message

Use this structure for anything non-trivial:

```
**Context:** What's the situation? (1–2 lines)
**Ask:** What do you need from me / what do I need from you?
**Deadline:** By when?
**Links:** Relevant docs, tickets, threads.
```

**Example:**

```
**Context:** The beta invite email is going out Friday to 500 users.
**Ask:** Can you review the copy for tone and typos?
**Deadline:** Thursday 12:00 UTC.
**Links:** /docs/beta/invite-copy
```

**Do:** be specific, link sources, state the ask, give a deadline.
**Don't:** say "quick question" with no context, send "hi" and wait, or bury the ask in paragraph 4.

---

## 6. Escalation path

```
1. Post in the relevant channel and tag the owner.
2. If no response in 1 business day → tag the owner's lead.
3. If still blocked after 2 business days → raise in the team sync or to the manager.
4. If it's a P0 incident → follow the incident process immediately (skip steps 1–3).
```

| Situation | Escalate to |
|---|---|
| Technical blocker | Tech lead |
| Scope / priority conflict | Product lead |
| People / interpersonal | Manager (DM) |
| Security / legal | Security lead / Legal |
| Client emergency | Account owner |

---

## 7. Meetings

- **No agenda, no meeting.** Agenda shared at least 4 hours ahead.
- **Default durations:** 25 or 50 minutes.
- **Record** any meeting where someone can't attend; post notes within 24 hours.
- **Every meeting ends with:** owners, actions, deadlines.
- **Recurring meetings** are reviewed quarterly and killed if nobody defends them.

---

## 8. Documentation & decisions

- **Decisions** go in the [Decision Log](./decision-log.md) within 48 hours.
- **Specs and plans** live in the wiki, not in chat.
- **Handoffs** use the [Project Handoff](./project-handoff.md) template.
- **Daily updates** use the [Async Standup](./async-standup-template.md) format.

---

## 9. Norms & etiquette

- **Use threads** to keep channels scannable.
- **Don't `@channel`** unless it's genuinely urgent.
- **Respect status/quiet hours** — no pings outside working hours except P0.
- **React to acknowledge** (`👀` = seen, `✅` = done) instead of sending "ok".
- **Turn off notifications** when you need deep work; you're not expected to be always-on.
- **Over-communicate context** when handing off across time zones.
- **Assume good intent** — clarify before escalating.

---

## 10. Review & change

- This charter is reviewed **quarterly** by the team.
- Anyone can propose a change via a doc comment or channel thread.
- Changes are agreed async and logged in the decision log.
- If a rule isn't working, we change it — the charter serves the team, not the reverse.

---

## Team sign-off

| Name | Role | Agreed |
|---|---|---|
| @sam | Engineer | ✅ |
| @priya | Tech Lead | ✅ |
| @maya | Designer | ✅ |
| @dan | Manager | ✅ |

---

> **How to adopt this in 30 minutes:** copy it into a doc, delete the rows that don't apply, fill in your core overlap hours, and ask everyone to reply "agreed" in the channel. Done.
