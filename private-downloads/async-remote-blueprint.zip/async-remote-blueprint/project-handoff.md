# Zero Drop-Offs — The Handoff Template That Keeps Projects Moving

> **Goal:** Transfer ownership of a project, workstream, or task so the next person can pick it up **without a single synchronous meeting** — even if they're in a different time zone and start 12 hours after you log off.

---

## When to use this

- Handing off before **vacation or parental leave**.
- **Reassigning** a project when someone changes teams or roles.
- **Cross-timezone shift handoffs** (e.g. a follow-the-sun support or ops rotation).
- **Onboarding** a new owner onto an existing workstream.
- **Contractor → full-time** or **agency → in-house** transitions.

---

## The golden rule

> **The handoff is complete when the receiver can act without asking you a single question.**

If they have to ping you, the handoff failed. Write for the person who knows *nothing* about your context.

---

## The template (copy this)

```markdown
# Project Handoff — [Project Name]

| Field | Value |
|---|---|
| **From** | @name |
| **To** | @name |
| **Effective date** | YYYY-MM-DD |
| **Handoff type** | Full transfer / Temporary (return date: YYYY-MM-DD) |
| **Last day of overlap** | YYYY-MM-DD |

---

## 1. What is this project?

One paragraph a stranger could understand. What problem does it solve? Who is it for?

## 2. Current status

- **Stage:** Discovery / Building / Testing / Launched / Maintaining
- **Health:** 🟢 On track / 🟡 At risk / 🔴 Blocked
- **% complete (rough):** 60%
- **Next milestone:** Beta launch, due 2026-05-01

## 3. What's done

- [x] User research (12 interviews) — findings in /docs/research
- [x] Wireframes approved
- [x] Backend API scaffolded (PR #301)

## 4. What's next (in priority order)

1. Build the settings page (design ready, ~3 days)
2. Connect Stripe billing
3. Run a 5-person usability test

## 5. Open decisions & risks

| Item | Type | Detail | Owner |
|------|------|--------|-------|
| Pricing model | Decision | Free vs $9/mo undecided — see DEC-021 | @you |
| Vendor API rate limit | Risk | Could cap us at 10k calls/day | @you |

## 6. Key people & stakeholders

| Name | Role | When to involve them |
|------|------|----------------------|
| @maya | Designer | Any UI change |
| @dan | Manager | Budget or scope changes |
| @client | External | Weekly Friday update email |

## 7. Where everything lives

| Resource | Link |
|----------|------|
| Main doc | /docs/project-x |
| Repo | github.com/org/project-x |
| Design file | figma.com/file/abc |
| Task board | linear.app/team/project-x |
| Dashboards | grafana/project-x |

## 8. Credentials & access

- [ ] Added @newowner to the repo (admin)
- [ ] Added to Figma project
- [ ] Added to Linear team
- [ ] Shared 1Password vault "Project X"
- [ ] Added to vendor dashboard (Stripe, etc.)

> ⚠️ Never paste secrets in this doc. Use your password manager's sharing feature.

## 9. Recurring commitments

| Cadence | What | Where |
|---------|------|-------|
| Weekly Mon | Client status email | Email |
| Biweekly Wed | Sprint review | #project-x |
| Monthly | Vendor invoice check | Stripe |

## 10. How to reach me after handoff

- **Available until:** 2026-04-30
- **Async only after:** 2026-05-01
- **Best channel:** #project-x thread (tag @me)
- **Response expectation:** within 1 business day for 2 weeks, then best-effort

## 11. First 3 actions for the new owner

1. Read sections 1–4 and confirm you understand the goal.
2. Get added to all access in section 8.
3. Post a standup introducing yourself and your first task.

---

**Handoff accepted by:** @newowner on YYYY-MM-DD
```

---

## Worked example (short)

```markdown
# Project Handoff — Billing Migration

| From | @sam | To | @priya |
| Effective | 2026-06-01 | Type | Full transfer |

**What:** Migrating 4,200 customers from legacy Stripe to the new
subscription engine without downtime.

**Status:** 🟡 At risk — 70% complete. 1,200 customers migrated.

**Next:** Migrate the remaining 3,000 in 3 batches (500/day). Batch 2
scheduled for 2026-06-03.

**Risk:** 40 customers have duplicate subscriptions that must be merged
manually. List in /docs/billing/dupes.csv.

**Access:** Added @priya to Stripe (admin), the migration repo, and the
1Password vault "Billing".

**First 3 actions:**
1. Verify you can log into Stripe and see the migration dashboard.
2. Read the runbook at /docs/billing/runbook.
3. Run batch 2 on 2026-06-03 and post results in #billing.
```

---

## Quality checklist (run before you hand off)

- [ ] A stranger could read this and know what to do next.
- [ ] Every link actually works (click them all).
- [ ] All access is granted and **verified** by the receiver.
- [ ] Open decisions and risks are listed with owners.
- [ ] Recurring commitments are captured.
- [ ] The receiver has confirmed acceptance in writing.
- [ ] No secrets are pasted in the doc.

---

## Anti-patterns

| Anti-pattern | Why it hurts | Do this instead |
|---|---|---|
| "It's all in my head, just ping me" | Creates a permanent dependency | Write the doc |
| A 60-min "knowledge transfer call" | Not searchable, time-zone hostile | Async doc + optional Q&A thread |
| Dumping 40 links with no context | Receiver can't prioritize | Annotate each link with its purpose |
| No acceptance step | Handoff silently fails | Require written acceptance |
| Sharing passwords in the doc | Security risk | Use a password manager vault |

---

## Notion setup

Make this a **database** so every handoff is tracked:

| Property | Type |
|---|---|
| Project | Title |
| From / To | Person |
| Effective date | Date |
| Type | Select: Full / Temporary |
| Status | Select: Drafting / Ready / Accepted |
| Health | Select: 🟢 / 🟡 / 🔴 |

**View:** "Pending acceptance" — filter Status = Ready, so nothing slips through.
