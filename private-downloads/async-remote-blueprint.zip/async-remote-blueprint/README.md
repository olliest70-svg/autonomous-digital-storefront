# Kill Pointless Meetings Forever — The Async Team Playbook

**The complete operating system for running a high-performing remote team without drowning in meetings.**

Most remote teams don't fail because of time zones or tools. They fail because they copy-paste office habits into a distributed environment: status meetings that could be a doc, decisions made in DMs that vanish, and handoffs that break the moment someone goes offline.

The **Async Remote Blueprint** replaces those habits with six battle-tested systems. Every file is a ready-to-use template you can drop straight into Notion, Google Docs, or your wiki today.

---

## What's inside

| # | File | What it does | Best for |
|---|------|--------------|----------|
| 1 | [`async-standup-template.md`](./async-standup-template.md) | A written daily standup format that takes 4 minutes to write and 90 seconds to read | Teams replacing daily sync calls |
| 2 | [`decision-log.md`](./decision-log.md) | A single source of truth for every decision, owner, and rationale | Stopping "wait, why did we do it that way?" |
| 3 | [`project-handoff.md`](./project-handoff.md) | A structured handoff doc so work never stalls when someone logs off | Cross-timezone and cross-team transitions |
| 4 | [`meeting-cost-calculator.md`](./meeting-cost-calculator.md) | A calculator + decision tree to kill low-value meetings | Managers defending calendar time |
| 5 | [`communication-charter.md`](./communication-charter.md) | Team-wide rules for channels, response times, and escalation | New teams and remote-first resets |

---

## Who this is for

- **Remote-first and hybrid teams** (5–200 people) that want fewer meetings and faster decisions.
- **Engineering, product, design, and ops teams** working across 2+ time zones.
- **Managers and team leads** who need a repeatable system, not another productivity hack.
- **Founders and operators** building a company handbook from scratch.

---

## The core idea: default to async, escalate to sync

Async isn't "no communication." It's a **priority order**:

```
1. Write it down  →  a doc, a thread, a comment
2. If unclear     →  a short async video or voice note
3. If blocked     →  a focused 1:1 or huddle (15 min max)
4. If urgent+wide →  a scheduled sync with an agenda
```

Every file in this blueprint reinforces that order. Meetings become the *exception*, not the default.

---

## How to roll this out (30-day plan)

### Week 1 — Baseline
- [ ] Run the **meeting-cost-calculator** on your last two weeks of recurring meetings.
- [ ] List every meeting that costs more than $500 per occurrence.
- [ ] Share the results with the team (no blame — just data).

### Week 2 — Charter
- [ ] Adapt the **communication-charter** to your team.
- [ ] Agree on channel purposes, response-time expectations, and escalation rules.
- [ ] Pin the charter where everyone can find it.

### Week 3 — Replace status meetings
- [ ] Swap your daily sync for the **async-standup-template**.
- [ ] Run both in parallel for one week so nobody feels cut off.
- [ ] Collect feedback, then retire the sync call.

### Week 4 — Institutionalize memory
- [ ] Start the **decision-log** and backfill the last 10 decisions.
- [ ] Use the **project-handoff** doc for your next transition.
- [ ] Review: how many meetings did you remove? What broke? Fix it.

---

## Quick-start checklist

- [ ] Pick a home for these docs (Notion, Confluence, or a `/team` folder in your repo).
- [ ] Assign an owner for each doc (someone must keep it alive).
- [ ] Add a link to the charter in your Slack/Teams channel topic.
- [ ] Set a recurring **quarterly review** to prune stale rules.
- [ ] Celebrate the first meeting you delete. Seriously.

---

## Design principles behind these templates

1. **Written by default.** If it isn't written, it didn't happen.
2. **One source of truth.** No decision lives only in a DM.
3. **Time-zone neutral.** Nothing assumes everyone is awake at once.
4. **Low ceremony.** Templates should take minutes, not hours.
5. **Reversible.** Every rule can be changed with a documented decision.

---

## FAQ

**Do these work for small teams (2–5 people)?**
Yes. Skip the heavier ceremony and use the standup + decision log. Scale up as you grow.

**We're hybrid, not fully remote. Still useful?**
Absolutely. Hybrid teams suffer the *worst* of both worlds — these templates force clarity on who is async and who is in-room.

**What tools do I need?**
None specific. These are plain Markdown. They work in Notion, Obsidian, Confluence, GitHub, or a shared drive.

**How long until we see results?**
Most teams report 3–6 hours per person per week reclaimed within the first month.

---

## License & usage

Personal and internal team use. Adapt freely. Attribution appreciated but not required.

> *Built for teams that would rather ship than schedule.*
