# Tax Estimator

**Stop being surprised every quarter. Stop overpaying. Set aside the right amount, every time.**

As a freelancer you are, in the eyes of the tax authority, a small business. Nobody is withholding tax from your paychecks — so *you* are the payroll department. This file gives you the math, the set-aside rules, and the deduction checklist to handle it without panic.

> **Disclaimer:** This is an educational planning tool, not tax advice. Tax rules vary by country, state, and situation. Confirm rates and rules with a qualified accountant in your jurisdiction. The *method* here is universal; the *numbers* are yours to plug in.

---

## How to use this file

1. **Know your set-aside percentage** (see the calculator below) and move that money the moment you get paid.
2. **Track income and expenses monthly** so your estimates are based on reality.
3. **Run the quarterly estimate** before each payment deadline.
4. **Keep every receipt** — deductions are the difference between paying 30% and paying 22%.
5. **Reconcile annually** with your accountant.

---

## The set-aside method (the one habit that saves you)

Every time a client pays you, immediately move a percentage into a separate "Tax" account. Not later. Now.

```
Client pays $2,600
    │
    ├── 30% → Tax savings account   ($780)
    └── 70% → Business account      ($1,820)
```

**Recommended set-aside by situation:**

| Situation | Set aside |
|---|---|
| Low income, few deductions | 25% |
| Typical freelancer, standard deductions | 30% |
| High income / higher bracket | 35–40% |
| VAT/GST registered | + your VAT/GST rate on top |
| Unsure | **30% is a safe default** |

> **Why 30% and not 20%?** Because you owe both income tax *and* self-employment/social contributions. Most freelancers who get burned set aside too little. Over-saving is painless — that money is yours if you don't owe it.

---

## Income & Expense Log

Track this monthly. It feeds every estimate below.

| Month | Gross Income | Expenses | Net Income | Set-aside (30%) | Running Tax Pot |
|---|---|---|---|---|---|
| Jul 2026 | $8,400 | $1,250 | $7,150 | $2,520 | $2,520 |
| Aug 2026 | $6,900 | $980 | $5,920 | $2,070 | $4,590 |
| Sep 2026 | $9,200 | $1,410 | $7,790 | $2,760 | $7,350 |
| Oct 2026 (partial) | $4,100 | $620 | $3,480 | $1,230 | $8,580 |
| **YTD Total** | **$28,600** | **$4,260** | **$24,340** | **$8,580** | **$8,580** |

---

## Quarterly Estimated Tax Calculator

Fill this in before each quarterly deadline.

```markdown
# Q[X] 2026 Estimated Tax

## 1. Income
YTD gross income ......................... $28,600
Minus YTD expenses ....................... −$4,260
= Net profit (YTD) ....................... $24,340

## 2. Deductions
Standard deduction / allowance ........... −$[amount]
Retirement contributions ................. −$[amount]
Health insurance premiums ................ −$[amount]
Half of self-employment tax .............. −$[amount]
= Taxable income ......................... $[amount]

## 3. Tax calculation
Income tax ([X]% effective) .............. $[amount]
Self-employment / social contributions ... $[amount]
= Total estimated tax .................... $[amount]

## 4. Payment
Already paid this year ................... −$[amount]
Amount due this quarter .................. $[amount]
Deadline: [date]
```

### Worked example (Q3, US-style, illustrative)

| Line | Amount |
|---|---|
| YTD net profit | $24,340 |
| Standard deduction (single) | −$14,600 |
| Retirement (SEP-IRA) | −$3,000 |
| Half of self-employment tax | −$1,720 |
| **Taxable income** | **$5,020** |
| Income tax (~12%) | $602 |
| Self-employment tax (~15.3% on 92.35% of profit) | $3,440 |
| **Total estimated tax** | **$4,042** |
| Already paid (Q1+Q2) | −$2,800 |
| **Due this quarter** | **$1,242** |

> **The self-employment tax is the one people forget.** In the US it's ~15.3% on 92.35% of net profit, and it's *on top of* income tax. In the UK it's National Insurance; in the EU it's social contributions. Whatever it's called where you are, budget for it.

---

## Quarterly deadlines (US reference)

| Quarter | Period covered | Deadline |
|---|---|---|
| Q1 | Jan–Mar | April 15 |
| Q2 | Apr–May | June 15 |
| Q3 | Jun–Aug | September 15 |
| Q4 | Sep–Dec | January 15 (next year) |

*UK: payments on account are due 31 January and 31 July. Other countries differ — set your own reminders.*

---

## Deduction checklist

Tick everything that applies. Every tick lowers your taxable income.

### Home office
- [ ] Dedicated workspace (simplified or actual-expense method)
- [ ] Rent/mortgage portion (by square footage)
- [ ] Utilities portion
- [ ] Internet portion
- [ ] Home office furniture & equipment

### Equipment & software
- [ ] Computer / laptop
- [ ] Monitor, keyboard, mouse
- [ ] Camera, microphone, lighting
- [ ] Software subscriptions (design, dev, accounting, AI tools)
- [ ] Cloud storage & hosting
- [ ] Phone & phone plan (business portion)

### Professional
- [ ] Professional development / courses
- [ ] Books & industry publications
- [ ] Professional memberships & dues
- [ ] Conferences & workshops
- [ ] Business insurance (liability, E&O)
- [ ] Accounting / legal fees

### Marketing
- [ ] Website hosting & domain
- [ ] Advertising & paid promotion
- [ ] Branding & design assets
- [ ] Business cards & print
- [ ] Client gifts (within limits)

### Travel & meals
- [ ] Business travel (flights, trains, lodging)
- [ ] Mileage / vehicle (business portion)
- [ ] Meals with clients (usually 50% deductible)
- [ ] Coworking space / desk rental

### Financial
- [ ] Retirement contributions (SEP-IRA, Solo 401k, SIPP)
- [ ] Health insurance premiums
- [ ] Bank & payment processing fees
- [ ] Business loan interest
- [ ] Self-employment tax (half is deductible)

> **The receipt rule:** No receipt, no deduction. Photograph every receipt the day you get it and drop it in a `Receipts/2026/` folder. Ten seconds now saves hundreds later.

---

## Expense tracker

| Date | Vendor | Category | Amount | Deductible? | Receipt? |
|---|---|---|---|---|---|
| 2026-10-12 | Adobe Creative Cloud | Software | $59.99 | ✅ 100% | ✅ |
| 2026-10-10 | Figma | Software | $15.00 | ✅ 100% | ✅ |
| 2026-10-08 | WeWork day pass | Coworking | $35.00 | ✅ 100% | ✅ |
| 2026-10-05 | Client lunch — Okafor | Meals | $84.00 | ✅ 50% | ✅ |
| 2026-10-03 | New monitor | Equipment | $420.00 | ✅ 100% | ✅ |
| 2026-10-01 | Home internet | Utilities | $70.00 | ✅ 40% | ✅ |

---

## Annual tax planning calendar

| Month | Task |
|---|---|
| January | Reconcile prior year; file returns; make Q4 payment |
| February | Organize receipts; send 1099s / contractor forms |
| March | Max prior-year retirement contributions |
| April | Q1 estimated payment; review YTD profit |
| May | Mid-year rate review — are you charging enough? |
| June | Q2 estimated payment |
| July | Mid-year tax check-in with accountant |
| August | Review deductions captured so far |
| September | Q3 estimated payment |
| October | Plan year-end purchases (equipment, software) |
| November | Estimate full-year liability; adjust set-aside |
| December | Year-end deductions; retirement contributions |

---

## Tax savings tracker

| Goal | Target | Actual | Status |
|---|---|---|---|
| Tax pot balance | $8,580 | $8,580 | ✅ On track |
| Retirement contributed | $3,000 | $3,000 | ✅ Met |
| Deductions captured | $4,260 | $4,260 | ✅ Met |
| Emergency fund (3 mo) | $18,000 | $11,200 | 🟡 In progress |

---

## Quarterly tax checklist

- [ ] Income & expense log updated for the quarter
- [ ] Set-aside percentage reviewed and correct
- [ ] All receipts filed
- [ ] Estimated payment calculated
- [ ] Payment scheduled before the deadline
- [ ] Tax pot reconciled against estimate
- [ ] Any changes discussed with accountant

---

*Next: open `weekly-review.md` to keep the whole system running.*
