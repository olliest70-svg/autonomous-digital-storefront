# Project Board

**A Kanban board built for one person — because you are the whole team.**

Team task apps assume you have a PM, a standup, and five people to notify. You don't. You need a board that shows you, at a glance, exactly what to do next and whether you actually have room to take on more work.

---

## How to use this file

1. **Every active project lives in exactly one column.** No project is in two places.
2. **Move cards right, never left.** If something moves backward, that's a signal — log why.
3. **Cap your WIP.** You can only have **3 projects in "In Progress"** at once. More than that and everything slows down.
4. **Every card has a "next action."** If you can't name the next physical step, the card is stuck.
5. **Review the board every Monday** and at the start of every Weekly Review.

> **The WIP limit is the whole system.** The reason freelancers feel overwhelmed isn't too much work — it's too many *open* projects. Three in progress, everything else queued or parked.

---

## The Board

### 📥 Backlog
*Ideas, signed-but-not-started, and someday projects.*

| Project | Client | Type | Est. Hours | Value | Priority |
|---|---|---|---|---|---|
| Mobile app onboarding flow | Okafor Fintech | Design | 40 | $6,000 | High |
| Q1 email sequence | Bright Path Agency | Copy | 20 | $2,400 | Medium |
| Website refresh | Reyes Wellness | Design + Build | 60 | $7,500 | Low |

### 📋 Ready (This Week)
*Scoped, scheduled, and next up. Max 2 cards.*

| Project | Client | Kickoff | Deadline | Est. Hours | Next Action |
|---|---|---|---|---|---|
| Brand refresh — Phase 1 | Northwind Studio | 2026-10-13 | 2026-11-07 | 35 | Finish wireframes |

### 🔨 In Progress (WIP limit: 3)
*Actively being worked on right now.*

| Project | Client | Started | Deadline | Hours Spent | Est. Total | Next Action |
|---|---|---|---|---|---|---|
| Dashboard redesign | Okafor Fintech | 2026-10-06 | 2026-10-24 | 22 | 45 | Build chart components |
| Landing page copy | Bell & Co. Legal | 2026-10-09 | 2026-10-20 | 8 | 16 | Draft hero + 3 sections |
| Brand refresh — Phase 1 | Northwind Studio | 2026-10-13 | 2026-11-07 | 6 | 35 | Finish wireframes |

### 🔍 In Review / Waiting on Client
*Blocked on feedback, approval, or assets. Track these hard — they kill timelines.*

| Project | Client | Waiting On | Sent | Days Waiting | Risk |
|---|---|---|---|---|---|
| Logo concepts | Northwind Studio | Client feedback on 3 concepts | 2026-10-12 | 3 | 🟡 |
| Contract review | Okafor Fintech | Legal sign-off on SOW | 2026-10-10 | 5 | 🔴 |

### ✅ Done
*Shipped. Log the win — you'll forget it otherwise.*

| Project | Client | Completed | Final Hours | Invoiced? |
|---|---|---|---|---|
| Pricing page redesign | Bright Path Agency | 2026-10-04 | 18 | ✅ Yes |
| Brand guidelines doc | Reyes Wellness | 2026-09-28 | 26 | ✅ Yes |

### 🗄️ Archive
*Cancelled, abandoned, or long-since delivered. Keep for reference.*

| Project | Client | Outcome | Notes |
|---|---|---|---|
| Newsletter template | Salter Logistics | Cancelled | Budget pulled; revisit Q1 |

---

## Project Brief template

Fill this out **before** a project enters "Ready." A project without a brief is a project that will scope-creep.

```markdown
# Project Brief: [Project Name]

**Client:** [Client name]
**Contact:** [Primary contact + email]
**Kickoff:** YYYY-MM-DD
**Deadline:** YYYY-MM-DD
**Budget:** $[amount] ([hourly / fixed / retainer])
**Est. hours:** [X]

## Objective
One sentence: what does "done" look like for the client?

## Deliverables
- [ ] Deliverable 1
- [ ] Deliverable 2
- [ ] Deliverable 3

## Out of scope
- Thing the client might assume is included but isn't
- Another boundary

## Milestones
| Milestone | Date | Payment |
|---|---|---|
| Kickoff / deposit | YYYY-MM-DD | 50% |
| First draft | YYYY-MM-DD | — |
| Final delivery | YYYY-MM-DD | 50% |

## Success metrics
How will we know this worked?

## Risks
- Risk 1 → mitigation
- Risk 2 → mitigation
```

---

## Capacity Planner

**Know your real capacity before you say yes.** A full-time freelancer has roughly **160 hours/month**, but only ~60% is billable once you subtract admin, sales, and breaks.

| Week | Mon | Tue | Wed | Thu | Fri | Billable hrs | Notes |
|---|---|---|---|---|---|---|---|
| Oct 13–17 | Okafor | Okafor | Northwind | Bell | Bell | 30 | Northwind kickoff |
| Oct 20–24 | Okafor | Okafor | Northwind | Northwind | Admin | 28 | Okafor deadline 10-24 |
| Oct 27–31 | Northwind | Northwind | Bright Path | Bright Path | Admin | 26 | — |
| Nov 3–7 | Northwind | Northwind | Northwind | Buffer | Review | 24 | Northwind deadline 11-07 |

**Monthly capacity math:**

```
Total working hours        = 160
Minus admin/sales/breaks   = −64  (40%)
= Billable capacity        = 96 hours/month

At $100/hr → $9,600/month gross ceiling
```

> **The "say no" test:** Before accepting a new project, add its estimated hours to your current committed hours. If the total exceeds your billable capacity for the timeline, you must either decline, extend the deadline, or subcontract. Saying yes to everything is how quality collapses.

---

## Time tracking log

Log hours per project so you can compare estimates to reality and price better next time.

| Date | Project | Hours | Task | Billable? |
|---|---|---|---|---|
| 2026-10-14 | Okafor Fintech | 3.5 | Dashboard chart components | ✅ |
| 2026-10-14 | Bell & Co. Legal | 2.0 | Landing page hero draft | ✅ |
| 2026-10-13 | Northwind Studio | 4.0 | Wireframes | ✅ |
| 2026-10-13 | Internal | 1.5 | Invoicing + email | ❌ |

**Estimate vs. actual tracker:**

| Project | Estimated | Actual | Variance | Lesson |
|---|---|---|---|---|
| Pricing page redesign | 16 | 18 | +12% | Client feedback rounds took longer |
| Brand guidelines doc | 20 | 26 | +30% | Underestimated asset gathering |
| Dashboard redesign | 45 | in progress | — | — |

> **Use variance to fix your estimates.** If you consistently run 20–30% over, add that buffer to every future quote. Your estimates aren't wrong — they're just optimistic.

---

## Standard Operating Procedures (SOPs)

Turn your repeatable work into checklists so you never forget a step.

### SOP: Starting a new project

- [ ] Brief completed and signed
- [ ] Deposit invoice sent
- [ ] Project folder created
- [ ] Kickoff call scheduled
- [ ] Access/credentials collected
- [ ] Milestones added to calendar
- [ ] Card moved to "Ready"

### SOP: Delivering a milestone

- [ ] Deliverable checked against brief
- [ ] Sent with a clear "what I need from you" note
- [ ] Due date for feedback stated
- [ ] Card moved to "In Review"
- [ ] Follow-up reminder set for 3 days

### SOP: Closing a project

- [ ] Final deliverable approved
- [ ] Final invoice sent
- [ ] Files handed over / archived
- [ ] Testimonial requested
- [ ] Referral asked for
- [ ] Card moved to "Done"
- [ ] Retro note added (what went well / what to fix)

---

## Weekly board checklist

- [ ] No more than 3 cards in "In Progress"
- [ ] Every card has a next action
- [ ] Nothing stuck in "In Review" for more than 5 days without a nudge
- [ ] Done cards moved and invoiced
- [ ] New week's capacity checked against committed hours

---

*Next: open `invoice-tracker.md` to get paid for the work you've shipped.*
