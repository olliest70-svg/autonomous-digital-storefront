# Weekly Review

**The 45-minute ritual that keeps your entire business running.**

You don't need more hours. You need a weekly checkpoint that catches problems before they become fires. This is the metronome that keeps the CRM, the board, the invoices, and your taxes all in sync.

Do it at the same time every week. Friday afternoon works best — you close the loop while the week is fresh and start Monday with a clean slate.

---

## How to use this file

1. **Block 45 minutes** in your calendar, recurring, every Friday.
2. **Work top to bottom.** Don't skip the money section.
3. **Write the review down** — a review you only think about doesn't count.
4. **Copy the template** each week and fill it in.
5. **Once a month, do the Monthly Review. Once a quarter, the Quarterly Review.**

> **The 45-minute rule:** If your review takes longer than 45 minutes, you're either doing it too rarely or trying to fix everything at once. The point is consistency, not perfection.

---

## The 45-minute agenda

| Minutes | Section | What you do |
|---|---|---|
| 0–5 | **Money check** | Review invoices, chase overdue, move tax set-aside |
| 5–15 | **Pipeline check** | Update CRM, action every lead, send follow-ups |
| 15–25 | **Board check** | Move cards, confirm next actions, check WIP limit |
| 25–35 | **Week in review** | What shipped, what slipped, what drained you |
| 35–40 | **Next week plan** | Top 3 priorities, capacity check |
| 40–45 | **One improvement** | Pick one thing to fix or automate |

---

## Weekly Review template

Copy this block every week.

```markdown
# Weekly Review — Week of YYYY-MM-DD

## 💰 Money
- Total outstanding: $______
- Overdue invoices: $______ (chased? Y/N)
- Paid this week: $______
- Tax set-aside moved: $______
- Cash position: $______

## 📇 Pipeline
- Leads in pipeline: ____
- Weighted pipeline value: $______
- Follow-ups sent: ____
- New leads added: ____

## 🔨 Board
- Cards in progress: ____ (limit 3)
- Shipped this week: ____
- Stuck / blocked: ____
- Next actions confirmed: Y/N

## 📊 Week in review
- Biggest win:
- Biggest slip:
- What drained me:
- What energized me:

## 🎯 Next week
1. [Top priority]
2. [Second priority]
3. [Third priority]
- Capacity check: committed ____ hrs / available ____ hrs

## 🔧 One improvement
- [One thing to fix, automate, or systemize this week]
```

---

## Worked example

```markdown
# Weekly Review — Week of 2026-10-13

## 💰 Money
- Total outstanding: $12,750
- Overdue invoices: $4,100 (chased: YES — INV-0037 + INV-0038)
- Paid this week: $3,300
- Tax set-aside moved: $990
- Cash position: $14,200

## 📇 Pipeline
- Leads in pipeline: 6
- Weighted pipeline value: $20,500
- Follow-ups sent: 4
- New leads added: 1 (Hannah Liu referral)

## 🔨 Board
- Cards in progress: 3 (at limit)
- Shipped this week: Pricing page redesign
- Stuck / blocked: Contract review (Okafor, 5 days waiting)
- Next actions confirmed: YES

## 📊 Week in review
- Biggest win: Okafor approved the dashboard direction on first pass
- Biggest slip: Didn't start Northwind wireframes until Thursday
- What drained me: The Salter Logistics overdue invoice
- What energized me: The Priya Nair referral call

## 🎯 Next week
1. Finish Northwind wireframes
2. Build Okafor chart components
3. Draft Bell & Co. landing copy
- Capacity check: committed 30 hrs / available 24 hrs ⚠️ OVER — push Bell to next week

## 🔧 One improvement
- Add a "pause work at 21 days overdue" clause to my contract template
```

---

## Monthly Review

Once a month, add 30 minutes to zoom out.

```markdown
# Monthly Review — [Month YYYY]

## Financials
- Gross income: $______
- Expenses: $______
- Net profit: $______
- Profit margin: ____%
- Tax set-aside: $______

## Clients
- Active clients: ____
- New clients won: ____
- Clients lost: ____
- Client value scores updated: Y/N

## Delivery
- Projects completed: ____
- On-time rate: ____%
- Estimate accuracy: ____%

## Business health
- Effective hourly rate: $______
- Average days to payment: ____
- Referrals received: ____
- Testimonials collected: ____

## Reflection
- What's working:
- What's not:
- One thing to change next month:
```

---

## Quarterly Review

Once a quarter, take 90 minutes and make the big calls.

```markdown
# Quarterly Review — Q[X] YYYY

## Scorecard
| Metric | Target | Actual | Status |
|---|---|---|---|
| Revenue | $______ | $______ | 🟢🟡🔴 |
| Profit margin | ____% | ____% | 🟢🟡🔴 |
| New clients | ____ | ____ | 🟢🟡🔴 |
| Avg days to payment | ____ | ____ | 🟢🟡🔴 |

## Big questions
1. Am I charging enough? (Compare effective hourly rate to target.)
2. Which clients should I fire or renegotiate?
3. Which service line is most profitable? Least?
4. What should I stop doing entirely?
5. What's my #1 goal for next quarter?

## Decisions
- [ ] Rate change: ______
- [ ] Client changes: ______
- [ ] Service changes: ______
- [ ] Systems to build: ______
```

---

## Key metrics to track over time

| Metric | Why it matters | Healthy range |
|---|---|---|
| **Effective hourly rate** | Real income ÷ real hours worked | Rising every quarter |
| **Average days to payment** | How fast cash arrives | ≤ your payment terms |
| **Pipeline coverage** | Weighted pipeline ÷ monthly target | 2–3× monthly target |
| **Profit margin** | Net profit ÷ gross income | 50–70% for services |
| **On-time delivery** | Projects shipped by deadline | >90% |
| **Estimate accuracy** | Actual hours ÷ estimated hours | 90–110% |
| **Billable ratio** | Billable hrs ÷ total hrs | 55–65% |
| **Client concentration** | Top client revenue ÷ total | <40% |

> **Watch client concentration.** If one client is more than 40% of your income, you don't have a business — you have a job with extra steps and no benefits. Diversify before you're forced to.

---

## The "one improvement" habit

Every week, pick exactly **one** thing to fix, automate, or systemize. Over a year that's 52 improvements — which compounds into a business that runs far more smoothly than it did in January.

Examples of good "one improvements":

- Add a deposit clause to my contract template
- Create an SOP for client onboarding
- Set up an automatic 30% transfer to my tax account
- Build a proposal template I can send in 10 minutes
- Add a "pause work at 21 days overdue" policy
- Batch all invoicing into one Friday block

---

## Weekly review checklist

- [ ] Money section complete — invoices chased, tax set aside
- [ ] Pipeline updated — every lead has a next action
- [ ] Board updated — WIP limit respected
- [ ] Week reflected on honestly
- [ ] Next week's top 3 chosen
- [ ] Capacity checked
- [ ] One improvement identified
- [ ] Review written down

---

*You've reached the end of the Freelancer Business OS. Run the Weekly Review every Friday and the system runs itself.*
