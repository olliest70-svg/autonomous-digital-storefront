# Freelancer Business OS

**The complete operating system for running a solo business like a real company — without hiring anyone.**

You are a freelancer, consultant, designer, developer, writer, or coach. You are brilliant at your craft. But your business runs on sticky notes, half-finished spreadsheets, and a growing sense that money is leaking out somewhere you can't see.

The **Freelancer Business OS** replaces that chaos with five interlocking systems that cover the entire lifecycle of a solo business:

1. **Client CRM** — know exactly who your clients are, what they're worth, and what happens next.
2. **Project Board** — deliver work on time without drowning in a task app built for teams of 50.
3. **Invoice Tracker** — get paid faster, chase late payers politely, and never lose a dollar to "I forgot."
4. **Tax Estimator** — stop being surprised every quarter, and stop overpaying.
5. **Weekly Review** — the 45-minute ritual that keeps the whole machine running.

Everything is plain Markdown. No subscriptions. No lock-in. Works in Notion, Obsidian, Bear, Craft, VS Code, or a plain text editor.

---

## Who this is for

| You are... | You'll use this to... |
|---|---|
| A freelance designer/dev/writer | Track clients, projects, invoices, and taxes in one place |
| A consultant billing hourly or retainer | Forecast income and protect your effective hourly rate |
| A coach or creator with 1:1 clients | Run a lightweight CRM without paying for HubSpot |
| A part-time freelancer with a day job | Keep the side business organized in under an hour a week |
| A freelancer going full-time | Build the financial discipline that makes the leap survivable |

---

## What's inside

| File | Purpose | Time to set up |
|---|---|---|
| `README.md` | This file. Start here. | 10 min read |
| `client-crm.md` | Full client + lead pipeline, contact log, value scoring | 30 min |
| `project-board.md` | Kanban board, project briefs, capacity planner, SOPs | 45 min |
| `invoice-tracker.md` | Invoice log, payment status, late-payment scripts | 20 min |
| `tax-estimator.md` | Quarterly tax math, deduction checklist, set-aside rules | 30 min |
| `weekly-review.md` | The 45-minute weekly ritual + monthly/quarterly reviews | 15 min |

---

## The system at a glance

```
LEADS ──► CLIENT CRM ──► PROJECT BOARD ──► INVOICE TRACKER ──► TAX ESTIMATOR
   │           │                │                  │                 │
   └───────────┴────────────────┴──────────────────┴─────────────────┘
                                   │
                            WEEKLY REVIEW
                    (the loop that keeps it all honest)
```

Every dollar you earn starts as a lead in the CRM, becomes a project on the board, turns into an invoice, and lands in your tax set-aside. The Weekly Review is the metronome that keeps the beat.

---

## How to set this up (60-minute quick start)

**Step 1 — Import the files (10 min).**
Create a new folder in your notes app called `Business OS`. Copy all six `.md` files into it. If you use Obsidian or Notion, link them to a single dashboard page.

**Step 2 — Fill in the CRM (20 min).**
Open `client-crm.md`. Add every current client and every live lead. Don't perfect it — just get the names and statuses in. You'll refine as you go.

**Step 3 — Load your active projects (15 min).**
Open `project-board.md`. Put every project you're currently working on into the correct column. Anything you're not actively working on goes to `Backlog`.

**Step 4 — Log your open invoices (10 min).**
Open `invoice-tracker.md`. Add every invoice you've sent that isn't paid yet. Note the due date and amount.

**Step 5 — Run your first Weekly Review (5 min).**
Open `weekly-review.md` and follow the checklist. That's it — you now have a working business OS.

---

## The three rules that make this work

> **Rule 1: One source of truth.**
> If it's not in the OS, it doesn't exist. No more "I think I sent that invoice." If it's not in `invoice-tracker.md`, it wasn't sent.

> **Rule 2: Review weekly, no exceptions.**
> The system only works if you feed it. The Weekly Review takes 45 minutes and prevents 90% of the fires that would otherwise burn your weekend.

> **Rule 3: Money moves first.**
> Every Friday, before anything else: check the invoice tracker, chase anything overdue, and move your tax set-aside. Cash flow is the oxygen of a solo business.

---

## Recommended tools (all optional)

| Tool | Use it for | Cost |
|---|---|---|
| Obsidian | Local Markdown vault, powerful linking | Free |
| Notion | Database views of the same tables | Free tier |
| VS Code + Markdown Preview | Editing and printing | Free |
| Google Sheets | If you prefer spreadsheets for numbers | Free |
| A plain text editor | Zero friction | Free |

You do **not** need any paid software to use this system. It was designed to run on free tools.

---

## Conventions used in these files

- **`[ ]` checkboxes** — actionable items you tick off.
- **Tables** — the core data structure. Copy a row, change the values.
- **`>` blockquotes** — rules, warnings, and pro tips.
- **`**Bold**`** — the single most important thing in a section.
- **Currency** — examples use `$` (USD). Swap for your local symbol; the math is identical.
- **Dates** — `YYYY-MM-DD` for sorting sanity.

---

## A note on scope

This OS is built for **one person**. It deliberately excludes features that only make sense for teams: permissions, approvals, shared calendars, and endless notification settings. Every field and every table exists because a solo operator needs it. If a section feels optional, it is — but the freelancers who use all five files consistently are the ones who stop living invoice-to-invoice.

---

## Version

**Freelancer Business OS v1.0** — a complete, self-contained system. No updates required to use it; fork and adapt freely.

---

*Next step: open `client-crm.md` and add your first client.*
