# Invoice Tracker

**Get paid faster. Chase late payers politely. Never lose a dollar to "I forgot."**

Cash flow is the oxygen of a solo business. You can be profitable on paper and still go broke because three invoices are 45 days late. This tracker makes sure you always know exactly who owes you what, and when to chase.

---

## How to use this file

1. **Log every invoice the moment you send it.** Not the moment you remember.
2. **Set the due date and the follow-up dates** at send time.
3. **Check this file every Friday** (it's step 1 of your Weekly Review).
4. **Never send a new invoice to a client with an overdue one** without a conversation first.
5. **Track days-late, not just status.** "Unpaid" hides the problem; "23 days late" forces action.

> **The golden rule of getting paid:** Invoice immediately on delivery, keep terms short (Net 14 > Net 30), and follow up the day after the due date — not a week later. The longer you wait, the less likely you get paid.

---

## Invoice status key

| Status | Meaning | Action |
|---|---|---|
| **Draft** | Not sent yet | Send it today |
| **Sent** | Delivered, not due yet | Wait |
| **Due Soon** | Due within 3 days | Send a friendly reminder |
| **Overdue** | Past due date | Follow up per escalation ladder |
| **Paid** | Money received | Mark paid, move to tax set-aside |
| **Disputed** | Client contesting | Resolve in writing |
| **Written Off** | Uncollectible | Log the loss, learn, move on |

---

## Invoice Log

| Invoice # | Client | Project | Issued | Due | Amount | Status | Days Late | Paid Date |
|---|---|---|---|---|---|---|---|---|
| INV-0042 | Okafor Fintech | Dashboard redesign — deposit | 2026-10-06 | 2026-11-05 | $3,000 | Sent | — | — |
| INV-0041 | Northwind Studio | Brand refresh — deposit | 2026-10-13 | 2026-10-27 | $1,750 | Sent | — | — |
| INV-0040 | Bell & Co. Legal | Landing page copy | 2026-10-09 | 2026-10-23 | $2,100 | Sent | — | — |
| INV-0039 | Bright Path Agency | Pricing page redesign | 2026-10-04 | 2026-10-18 | $1,800 | Due Soon | — | — |
| INV-0038 | Reyes Wellness | Brand guidelines doc | 2026-09-28 | 2026-10-12 | $2,600 | Overdue | 3 | — |
| INV-0037 | Salter Logistics | Retainer — Sept | 2026-09-01 | 2026-10-01 | $1,500 | Overdue | 14 | — |
| INV-0036 | Okafor Fintech | Q3 maintenance | 2026-09-15 | 2026-09-29 | $2,400 | Paid | — | 2026-09-27 |
| INV-0035 | Northwind Studio | Discovery workshop | 2026-09-10 | 2026-09-24 | $900 | Paid | — | 2026-09-22 |

---

## Accounts Receivable Summary

| Metric | Value |
|---|---|
| Total outstanding | $12,750 |
| Overdue (>0 days late) | $4,100 |
| Overdue >30 days | $0 |
| Paid this month | $3,300 |
| Average days to payment | 11 days |
| Oldest unpaid invoice | INV-0037 (14 days late) |

> **Watch two numbers above all others:** total outstanding and average days-to-payment. If average days-to-payment creeps above your terms, your clients are using you as a free credit line. Fix it with reminders and shorter terms.

---

## Payment terms cheat sheet

| Term | Meaning | When to use |
|---|---|---|
| **Due on receipt** | Pay immediately | Small one-off jobs |
| **Net 7** | 7 days | New clients, small projects |
| **Net 14** | 14 days | Your default — short and fair |
| **Net 30** | 30 days | Larger clients with AP departments |
| **50/50** | Half upfront, half on delivery | Most fixed-price projects |
| **Milestone** | Paid per milestone | Long projects (3+ months) |
| **Retainer** | Fixed monthly, billed in advance | Ongoing relationships |

> **Always take a deposit.** 50% upfront is standard and it filters out non-serious clients instantly. A client who won't pay a deposit is a client who won't pay the final invoice either.

---

## Late-payment escalation ladder

Follow these steps in order. Stay professional — the goal is payment, not a fight.

| Day | Action | Tone |
|---|---|---|
| Due date + 1 | Friendly reminder email | Warm, assumes oversight |
| + 7 | Second reminder + copy of invoice | Polite, references terms |
| + 14 | Direct email + phone call | Firm, asks for a payment date |
| + 21 | Formal notice, pause work | Serious, cites contract |
| + 30 | Final notice, late fee applied | Formal, states next steps |
| + 45 | Collections / small claims | Legal, factual |

---

## Templates

### Friendly reminder (due date + 1)

```
Subject: Quick reminder — Invoice INV-0038

Hi [Name],

Hope you're well! Just a gentle reminder that invoice INV-0038 for
$2,600 was due on [date]. I know these things slip through — no worries
at all.

Here's the invoice again for convenience: [link/attachment]

Let me know if you need anything from me to process it.

Thanks!
[Your name]
```

### Firm follow-up (day +14)

```
Subject: Invoice INV-0037 — now 14 days overdue

Hi [Name],

I'm following up on invoice INV-0037 for $1,500, which was due on
[date] and is now 14 days overdue.

Could you confirm a payment date this week? If there's an issue with
the invoice or a delay in your AP process, I'd appreciate knowing so we
can sort it out.

Per our agreement, payment terms are Net 30. I'd like to keep our
working relationship running smoothly, so a quick update would help a lot.

Thanks,
[Your name]
```

### Final notice (day +30)

```
Subject: Final notice — Invoice INV-0037 (30 days overdue)

Hi [Name],

This is a formal notice that invoice INV-0037 for $1,500 is now 30 days
overdue. As per our agreement, a late fee of [X]% now applies.

I value our relationship and would much rather resolve this directly.
Please arrange payment by [date]. If I don't hear from you by then, I'll
need to [pause work / refer this to collections].

If there's a genuine problem, call me and let's talk.

Regards,
[Your name]
```

---

## Invoice template

Use this structure for every invoice. Keep it clean and unambiguous.

```
INVOICE

[Your Name / Business Name]
[Address]
[Email] · [Phone]
[Tax ID if applicable]

Invoice #: INV-00XX
Issue date: YYYY-MM-DD
Due date: YYYY-MM-DD
Payment terms: Net 14

Bill to:
[Client Name]
[Client Address]
[Client Email]

------------------------------------------------------------
Description                     Qty     Rate      Amount
------------------------------------------------------------
[Service / deliverable]         [X]     $[rate]   $[amount]
[Service / deliverable]         [X]     $[rate]   $[amount]
------------------------------------------------------------
                                   Subtotal:     $[amount]
                                   Tax ([X]%):   $[amount]
                                   TOTAL DUE:    $[amount]
------------------------------------------------------------

Payment methods:
- Bank transfer: [details]
- Card / PayPal: [link]

Thank you for your business!
```

---

## Weekly invoicing checklist

- [ ] Every delivered project invoiced (nothing sitting un-invoiced)
- [ ] All invoices marked with correct status
- [ ] Overdue invoices chased per the escalation ladder
- [ ] "Due Soon" invoices reminded
- [ ] Paid invoices moved to tax set-aside
- [ ] Accounts Receivable Summary updated
- [ ] Average days-to-payment reviewed

---

*Next: open `tax-estimator.md` to set aside what you owe before you spend it.*
