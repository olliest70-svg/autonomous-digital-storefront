# Never Lose Track of a Client Again — Your Zero-Leak CRM

**Your single source of truth for every human who pays you — or might.**

Most freelancers lose money not because they lack clients, but because they lose *track* of them. A lead goes cold because you forgot to follow up. A past client would have rehired you but you never checked in. This CRM fixes that in one file.

---

## How to use this file

1. **Every lead starts in the Pipeline table.** Move it through stages as it progresses.
2. **Every won deal becomes a Client row** in the Client Directory.
3. **Log every meaningful interaction** in the Contact Log — even a two-line note.
4. **Score your clients** quarterly so you know who to protect and who to fire.
5. **Set a follow-up date on everything.** A lead with no next action is a dead lead.

> **The 7-day rule:** No lead should ever go more than 7 days without a next action. If you can't think of one, the lead is either dead (archive it) or you owe them a follow-up (do it now).

---

## Pipeline stages

| Stage | Definition | Exit criteria |
|---|---|---|
| **1. Lead** | Name + contact captured. No conversation yet. | You've had a real conversation |
| **2. Qualified** | Budget, timeline, and fit confirmed. | You've sent a proposal |
| **3. Proposal Sent** | Proposal/quote is in their hands. | They respond (yes or no) |
| **4. Negotiation** | Discussing scope, price, or terms. | Contract signed |
| **5. Won** | Signed. Moves to Client Directory. | Project kicks off |
| **6. Lost** | Declined or went cold. | Log the reason, archive |
| **7. Nurture** | Not now, but maybe later. | Re-engage in 90 days |

---

## Lead Pipeline

| Lead | Company | Source | Stage | Est. Value | Probability | Weighted Value | Next Action | Follow-up Date |
|---|---|---|---|---|---|---|---|---|
| Priya Nair | Northwind Studio | Referral (Tom R.) | Qualified | $6,500 | 60% | $3,900 | Send proposal | 2026-10-17 |
| Marcus Bell | Bell & Co. Legal | LinkedIn DM | Proposal Sent | $4,200 | 40% | $1,680 | Nudge — proposal sent 5 days ago | 2026-10-16 |
| Sofia Reyes | Reyes Wellness | Website form | Lead | $2,800 | 15% | $420 | Book intro call | 2026-10-18 |
| Daniel Okafor | Okafor Fintech | Cold outreach | Negotiation | $12,000 | 75% | $9,000 | Finalize SOW, send contract | 2026-10-16 |
| Hannah Liu | Bright Path Agency | Referral (Priya) | Qualified | $8,000 | 50% | $4,000 | Discovery call | 2026-10-20 |
| Greg Salter | Salter Logistics | Past client | Nurture | $5,000 | 30% | $1,500 | Check in — Q4 budget? | 2026-12-01 |

**Pipeline total (weighted): $20,500**

> **Weighted value** = Est. Value × Probability. It's the number you should use for forecasting, not the raw total. A $12k deal at 75% is worth more to your calendar than a $20k deal at 20%.

---

## Client Directory

| Client | Primary Contact | Email | Phone | Rate | Billing | Since | Status | Health |
|---|---|---|---|---|---|---|---|---|
| Northwind Studio | Priya Nair | priya@northwind.co | +1 415 555 0142 | $95/hr | Net 14 | 2025-03 | Active | 🟢 Green |
| Bell & Co. Legal | Marcus Bell | m.bell@bellco.com | +1 212 555 0198 | $4,200/proj | Net 30 | 2026-08 | Active | 🟡 Watch |
| Reyes Wellness | Sofia Reyes | hello@reyeswellness.com | +1 512 555 0177 | $110/hr | Net 14 | 2026-01 | Paused | 🟢 Green |
| Okafor Fintech | Daniel Okafor | d.okafor@okafor.io | +1 646 555 0110 | $140/hr | Net 30 | 2024-11 | Active | 🟢 Green |
| Bright Path Agency | Hannah Liu | hannah@brightpath.ag | +1 305 555 0165 | $85/hr | Net 21 | 2025-09 | Active | 🟢 Green |
| Salter Logistics | Greg Salter | greg@salterlog.com | +1 773 555 0134 | $100/hr | Net 30 | 2023-06 | Dormant | 🔴 At Risk |

### Health key

| Status | Meaning | Action |
|---|---|---|
| 🟢 Green | Pays on time, good scope, enjoyable work | Protect. Ask for referrals. |
| 🟡 Watch | Slow to pay, scope creep, or unclear briefs | Tighten terms, raise rate, or renegotiate |
| 🔴 At Risk | Chronic late payment, disrespect, or low margin | Fire them or fix the relationship |

---

## Client Value Scoring

Score each client **quarterly** on five dimensions (1–5 each). Total out of 25.

| Client | Revenue | Ease | Margin | Referrals | Enjoyment | **Total** | Tier |
|---|---|---|---|---|---|---|---|
| Okafor Fintech | 5 | 4 | 5 | 3 | 4 | **21** | A — Protect |
| Northwind Studio | 4 | 5 | 4 | 5 | 5 | **23** | A — Protect |
| Bright Path Agency | 4 | 4 | 3 | 4 | 4 | **19** | B — Grow |
| Reyes Wellness | 3 | 5 | 4 | 2 | 4 | **18** | B — Grow |
| Bell & Co. Legal | 3 | 2 | 3 | 1 | 2 | **11** | C — Fix or Exit |
| Salter Logistics | 2 | 2 | 2 | 1 | 2 | **9** | C — Fix or Exit |

**Tier definitions:**

- **A (20–25):** Your best clients. Over-serve them. Ask for referrals and testimonials.
- **B (14–19):** Solid. Look for ways to grow scope or raise rates.
- **C (5–13):** Draining you. Either renegotiate terms or transition out gracefully.

> **The 80/20 audit:** Once a year, sort clients by revenue. You'll usually find 20% of clients generate 80% of income. Spend your best energy there and stop subsidizing the rest.

---

## Contact Log

Log every meaningful interaction. Date-stamp everything.

| Date | Client / Lead | Type | Summary | Next Step |
|---|---|---|---|---|
| 2026-10-14 | Okafor Fintech | Call | Reviewed Q4 roadmap. Wants 3 new dashboard screens. | Send updated SOW by Fri |
| 2026-10-13 | Marcus Bell | Email | Sent proposal v2 with revised scope. | Follow up 10-16 |
| 2026-10-11 | Northwind Studio | Meeting | Kickoff for brand refresh. Assets received. | Start wireframes |
| 2026-10-10 | Priya Nair (referral) | Call | Intro call. Budget ~$6.5k, timeline 6 weeks. | Send proposal 10-17 |
| 2026-10-09 | Salter Logistics | Email | No response to Q3 check-in. | Try again in Dec |
| 2026-10-08 | Reyes Wellness | Email | Paused retainer until Jan. Confirmed happy. | Re-engage Dec 15 |

---

## Follow-up cadence

Never let a relationship go silent by accident. Use this cadence:

| Relationship | Cadence | Channel |
|---|---|---|
| Active client | Weekly during project | Project tool / email |
| Active client (between projects) | Every 3 weeks | Email |
| Past client | Every 90 days | Email or LinkedIn |
| Hot lead (Proposal/Negotiation) | Every 3–4 days | Email |
| Warm lead (Qualified) | Weekly | Email |
| Nurture | Every 90 days | Email |

---

## Templates

### Discovery call questions

```
1. What does success look like for this project in 6 months?
2. What's the deadline, and what's driving it?
3. Who else needs to approve this?
4. What's your budget range? (Ask directly — it saves everyone time.)
5. Have you worked with a freelancer before? What went well/poorly?
6. What's the single biggest risk to this project?
```

### Follow-up email (proposal nudge)

```
Subject: Quick nudge on the [Project] proposal

Hi [Name],

Just circling back on the proposal I sent on [date]. No rush — I know
Q4 gets busy. Two quick things that might help:

1. I can hold your start date until [date].
2. Happy to jump on a 15-min call if any part of the scope needs adjusting.

Anything I can clarify?

[Your name]
```

### Re-engagement email (past client)

```
Subject: Thinking about [their business]

Hi [Name],

It's been a few months since we wrapped [project]. I was thinking about
[their business] the other day and noticed [specific observation].

If you're planning anything for [quarter], I have a little space opening
up in [month]. Want me to send over a few ideas?

[Your name]
```

### Referral ask

```
Hi [Name],

So glad [project] turned out well — it was a pleasure.

One small ask: if you know anyone wrestling with [problem you solve],
I'd love an intro. I have room for one more project this quarter.

No pressure at all — and thank you either way.

[Your name]
```

---

## Weekly CRM checklist

- [ ] Every lead has a next action and a follow-up date
- [ ] Any lead with a follow-up date in the past gets actioned today
- [ ] New conversations logged in the Contact Log
- [ ] Won deals moved to the Client Directory
- [ ] Lost deals archived with a reason
- [ ] At least one re-engagement or referral email sent

---

*Next: open `project-board.md` to turn won deals into delivered work.*
