# Track Every Invoice, Flag Every Late Payment, Miss Nothing

Track every invoice from **draft → sent → paid → overdue**, know exactly who owes you what, and never let a payment slip through the cracks.

---

## How to Use This File

1. Every time you send an invoice, add a row to the **Master Invoice Log**.
2. Update the **Status** column as things move: `Draft → Sent → Paid` (or `Overdue`).
3. Once a week, run the **Aging Report** view to see who's late.
4. Use the **Follow-Up Templates** below to chase politely and effectively.

---

## Master Invoice Log

| # | Invoice ID | Client | Issue Date | Due Date | Amount | Tax/VAT | Total | Status | Days Late | Notes |
|---|-----------|--------|-----------|----------|--------|---------|-------|--------|-----------|-------|
| 1 | INV-2026-001 | Northwind Design Co. | 2026-09-01 | 2026-09-15 | 4,500.00 | 900.00 | 5,400.00 | Paid | 0 | Paid on time |
| 2 | INV-2026-002 | Brightpath Consulting | 2026-09-05 | 2026-09-19 | 2,800.00 | 560.00 | 3,360.00 | Paid | 0 | — |
| 3 | INV-2026-003 | Lumen Studios | 2026-09-10 | 2026-09-24 | 6,200.00 | 1,240.00 | 7,440.00 | Overdue | 21 | 2nd reminder sent |
| 4 | INV-2026-004 | Cedar & Co. | 2026-09-18 | 2026-10-02 | 1,950.00 | 390.00 | 2,340.00 | Sent | 0 | Awaiting payment |
| 5 | INV-2026-005 | Atlas Freelance Ltd. | 2026-10-01 | 2026-10-15 | 3,300.00 | 660.00 | 3,960.00 | Sent | 0 | Due today |
| 6 | INV-2026-006 | Meridian Tech | 2026-10-05 | 2026-10-19 | 8,000.00 | 1,600.00 | 9,600.00 | Draft | — | Not yet sent |
| 7 | INV-2026-007 | Harborline Media | 2026-08-20 | 2026-09-03 | 1,200.00 | 240.00 | 1,440.00 | Overdue | 42 | Escalation stage |

> **Tip:** Keep the `Invoice ID` format `INV-YYYY-NNN` so sorting is chronological and each invoice is unique forever.

---

## Status Key

| Status | Meaning | Action |
|--------|---------|--------|
| 🟡 **Draft** | Created but not sent | Review line items, then send |
| 🔵 **Sent** | Delivered, awaiting payment | Nothing yet — wait until due date |
| 🟢 **Paid** | Money received & reconciled | Archive, thank the client |
| 🟠 **Overdue** | Past due date, unpaid | Start follow-up sequence |
| 🔴 **Escalated** | 30+ days late | Formal notice / collections / pause work |
| ⚫ **Written off** | Uncollectable | Record as bad debt, claim if allowed |

---

## Aging Report (run weekly)

Group outstanding invoices by how long they've been overdue. This is the single most useful view for cash flow.

| Bucket | Invoices | Total Outstanding | % of Receivables |
|--------|----------|-------------------|------------------|
| **Not yet due** | INV-004, INV-005 | 6,300.00 | 22% |
| **1–15 days late** | — | 0.00 | 0% |
| **16–30 days late** | INV-003 | 7,440.00 | 26% |
| **31–60 days late** | INV-007 | 1,440.00 | 5% |
| **61–90 days late** | — | 0.00 | 0% |
| **90+ days late** | — | 0.00 | 0% |
| **TOTAL** | 4 invoices | **15,180.00** | 53% of all billed |

> **Watch this number:** If more than 20% of your receivables sit in the 30+ day buckets, tighten your payment terms or require deposits.

---

## Payment Terms Cheat Sheet

| Term | When payment is due | Use when |
|------|---------------------|----------|
| **Due on receipt** | Immediately | Small, fast jobs |
| **Net 7** | 7 days | Retainers, trusted clients |
| **Net 14** | 14 days | Most freelance work |
| **Net 30** | 30 days | Larger corporates (standard) |
| **Net 45/60** | 45–60 days | Enterprise clients — charge more for the wait |
| **50% upfront** | Half now, half on delivery | New clients, big projects |
| **100% upfront** | Before work starts | Products, workshops, risky clients |

**Golden rule:** The longer the terms, the higher the price. Net 60 means you're financing the client — charge for it.

---

## Follow-Up Sequence

| Day | Stage | Tone | Channel |
|-----|-------|------|---------|
| **Due date** | Friendly nudge | Warm | Email |
| **+7 days** | First reminder | Polite | Email |
| **+14 days** | Second reminder | Firm | Email + phone |
| **+30 days** | Formal notice | Serious | Email, mention late fee |
| **+45 days** | Escalation | Final | Phone call + written notice |
| **+60 days** | Collections / pause work | Formal | Letter, small claims, or agency |

---

## Follow-Up Templates

### Day 0 — Friendly Nudge (Due Date)

```
Subject: Quick reminder — Invoice INV-2026-005 due today

Hi [Name],

Just a friendly reminder that invoice INV-2026-005 for $3,960.00
is due today. No action needed if it's already scheduled — just
let me know if you need anything from me.

Thanks!
[Your name]
```

### Day 7 — First Reminder

```
Subject: Invoice INV-2026-005 — payment now 7 days overdue

Hi [Name],

I wanted to follow up on invoice INV-2026-005 ($3,960.00), which
was due on [date] and is now 7 days past due.

Could you confirm the expected payment date? If there's an issue
with the invoice, I'm happy to help sort it out.

Best,
[Your name]
```

### Day 14 — Second Reminder (Firm)

```
Subject: Overdue invoice INV-2026-005 — action needed

Hi [Name],

Invoice INV-2026-005 ($3,960.00) is now 14 days overdue. I've
attached a copy for convenience.

Please arrange payment by [date + 7 days]. If payment has already
been made, please send the remittance so I can reconcile it.

Thank you,
[Your name]
```

### Day 30 — Formal Notice

```
Subject: FORMAL NOTICE — invoice INV-2026-005, 30 days overdue

Dear [Name],

Despite two previous reminders, invoice INV-2026-005 for $3,960.00
remains unpaid and is now 30 days overdue.

As per our agreement, a late fee of [X]% now applies. Payment is
required within 7 days to avoid further action.

Please contact me immediately to resolve this.

Regards,
[Your name]
```

---

## Late Fees & Deposits

| Policy | Typical value | Notes |
|--------|---------------|-------|
| **Late fee** | 1.5% per month (or 0.05%/day) | Check local legal limits |
| **Deposit** | 25–50% upfront | Standard for projects > $2,000 |
| **Kill fee** | 25–50% of remaining value | If client cancels mid-project |
| **Rush fee** | +25–50% | For expedited turnaround |

> **State it upfront.** Late fees only work if they're in your contract or invoice terms. Add a line: *"Payments more than 7 days late incur a 1.5% monthly late fee."*

---

## Invoice Template (copy-paste)

```
INVOICE

From:
[Your Name / Business Name]
[Address]
[Email] · [Phone]
[Tax ID / VAT number]

Bill To:
[Client Name]
[Client Address]
[Client Email]

Invoice Number: INV-2026-XXX
Issue Date:     [YYYY-MM-DD]
Due Date:       [YYYY-MM-DD]
Payment Terms:  Net 14

─────────────────────────────────────────────
Description                    Qty   Rate     Amount
─────────────────────────────────────────────
[Service / product]             [x]   [rate]   [amount]
[Service / product]             [x]   [rate]   [amount]
─────────────────────────────────────────────
                            Subtotal:          [amount]
                            Tax/VAT ([x]%):    [amount]
                            TOTAL DUE:         [amount]
─────────────────────────────────────────────

Payment Details:
Bank:           [Bank name]
Account Name:   [Name]
Account Number: [Number]
Sort/Routing:   [Code]
Reference:      INV-2026-XXX

Terms: Payment due within 14 days. A 1.5% monthly late fee applies
to overdue balances. Thank you for your business!
```

---

## Monthly Summary

| Month | Invoiced | Collected | Outstanding | Collection Rate |
|-------|----------|-----------|-------------|-----------------|
| Jul 2026 | 18,400.00 | 18,400.00 | 0.00 | 100% |
| Aug 2026 | 21,750.00 | 20,310.00 | 1,440.00 | 93% |
| Sep 2026 | 22,890.00 | 8,760.00 | 14,130.00 | 38% |
| Oct 2026 (MTD) | 13,250.00 | 0.00 | 13,250.00 | 0% |

> **Collection rate** = Collected ÷ Invoiced. Below 90% means you have a follow-up problem, not a sales problem.

---

## DSO Calculator (Days Sales Outstanding)

DSO tells you the average number of days it takes to get paid.

```
DSO = (Accounts Receivable ÷ Total Credit Sales) × Number of Days

Example:
  Accounts Receivable (outstanding) = $15,180
  Credit sales over last 90 days      = $57,000
  DSO = (15,180 ÷ 57,000) × 90 = 24 days
```

| DSO | Verdict |
|-----|---------|
| < 15 days | Excellent — you get paid fast |
| 15–30 days | Healthy |
| 30–45 days | Watch it — tighten terms |
| 45–60 days | Problem — cash flow risk |
| > 60 days | Serious — you're financing clients |

---

*Next: reconcile paid invoices into `profit-dashboard.md` and set aside tax using `tax-calculator.md`.*
