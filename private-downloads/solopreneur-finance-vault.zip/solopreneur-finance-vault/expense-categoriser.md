# Tax Season in One Click — Your Expense Categoriser

A rule-based system to sort every business expense into the right category — so your books stay clean, your deductions are maximised, and tax time is painless.

---

## How to Use This File

1. **Export** your transactions from your bank/card (CSV or manual).
2. **Apply the rules** in the Rule Engine below — match the merchant/keyword to a category.
3. **Log** the categorised expense in the Expense Log.
4. **Flag** anything ambiguous for your accountant.
5. **Review** the category summary monthly.

> **5-minute rule:** Categorise weekly. A small pile is trivial; a year's pile is a nightmare.

---

## The Categories

| Code | Category | Deductible? | Notes |
|------|----------|-------------|-------|
| **COGS** | Cost of Goods Sold | ✅ | Direct cost of delivering your service/product |
| **SW** | Software & Subscriptions | ✅ | SaaS, hosting, tools |
| **MKT** | Marketing & Advertising | ✅ | Ads, content, design, PR |
| **CON** | Contractors & Freelancers | ✅ | Subcontractors, VAs, editors |
| **OFF** | Office & Admin | ✅ | Supplies, postage, stationery |
| **TRA** | Travel & Meals | ✅ (partial) | Business travel; meals often 50% |
| **VEH** | Vehicle | ✅ (business %) | Mileage, fuel, insurance, maintenance |
| **HOME** | Home Office | ✅ (business %) | Internet, utilities, rent portion |
| **INS** | Insurance & Fees | ✅ | Liability, professional, bank fees |
| **EDU** | Education & Training | ✅ | Courses, books, conferences |
| **PRO** | Professional Services | ✅ | Accountant, lawyer, consultant |
| **RET** | Retirement | ✅ | SEP, Solo 401k, SIPP, RRSP, Super |
| **HEA** | Health | ✅ (varies) | Self-employed health premiums |
| **EQP** | Equipment | ✅ (depreciate) | Computers, cameras, furniture |
| **TAX** | Taxes & Licences | ✅ | Business licences, permits |
| **INT** | Loan Interest | ✅ | Business loan/credit interest |
| **PER** | Personal | ❌ | NOT deductible — keep separate |
| **OWN** | Owner's Draw | ❌ | Not an expense — it's a distribution |

---

## The Rule Engine

Match the merchant or keyword on the left to the category on the right. Copy this into a spreadsheet as a lookup, or just use it as a mental checklist.

| If the transaction contains… | Category | Deductible |
|------------------------------|----------|------------|
| Adobe, Figma, Canva, Notion, Slack, Zoom, Google Workspace | SW | ✅ 100% |
| AWS, Vercel, DigitalOcean, Cloudflare, hosting, domain | SW | ✅ 100% |
| OpenAI, Anthropic, AI tools | SW | ✅ 100% |
| Meta Ads, Google Ads, LinkedIn Ads, Facebook | MKT | ✅ 100% |
| Mailchimp, ConvertKit, Buffer, Hootsuite | MKT | ✅ 100% |
| Upwork, Fiverr, "contractor", "freelance" | CON | ✅ 100% |
| Staples, Amazon (office), postage, stamps | OFF | ✅ 100% |
| Uber, Lyft, taxi, train, flight, hotel, Airbnb (business) | TRA | ✅ 100% |
| Restaurant, café, coffee (client meeting) | TRA | ✅ 50% (US) |
| Shell, BP, Chevron, fuel, parking, tolls, Uber (business) | VEH | ✅ business % |
| AT&T, Verizon, ISP, electric, water, rent (home) | HOME | ✅ business % |
| State Farm, Hiscox, liability, E&O, bank fee, Stripe fee | INS | ✅ 100% |
| Udemy, Coursera, conference, books, workshop | EDU | ✅ 100% |
| Accountant, lawyer, bookkeeper, consultant | PRO | ✅ 100% |
| Vanguard, Fidelity, SEP-IRA, pension, SIPP | RET | ✅ 100% |
| Health insurance, Blue Cross, medical premium | HEA | ✅ 100% (self-employed) |
| Apple Store, Dell, Best Buy, camera, laptop, desk | EQP | ✅ (depreciate) |
| Business licence, LLC fee, permit, trademark | TAX | ✅ 100% |
| Loan interest, credit card interest (business) | INT | ✅ 100% |
| Groceries, Netflix, gym, personal rent, clothes | PER | ❌ 0% |
| Transfer to personal account, "owner draw" | OWN | ❌ 0% |

---

## Expense Log

| Date | Merchant | Description | Amount | Category | Deductible % | Deductible Amount | Receipt? |
|------|----------|-------------|--------|----------|--------------|-------------------|----------|
| 2026-10-01 | Adobe | Creative Cloud | 59.99 | SW | 100% | 59.99 | ✅ |
| 2026-10-02 | Google Ads | Campaign Oct | 450.00 | MKT | 100% | 450.00 | ✅ |
| 2026-10-03 | Upwork | Editor — Oct | 800.00 | CON | 100% | 800.00 | ✅ |
| 2026-10-05 | Shell | Fuel | 62.40 | VEH | 70% | 43.68 | ✅ |
| 2026-10-06 | Starbucks | Client meeting | 14.50 | TRA | 50% | 7.25 | ✅ |
| 2026-10-08 | Apple | MacBook Air | 1,299.00 | EQP | 100%* | 1,299.00 | ✅ |
| 2026-10-09 | Comcast | Internet | 89.99 | HOME | 40% | 36.00 | ✅ |
| 2026-10-10 | Fidelity | SEP-IRA | 1,500.00 | RET | 100% | 1,500.00 | ✅ |
| 2026-10-11 | Whole Foods | Groceries | 120.00 | PER | 0% | 0.00 | ❌ |
| 2026-10-12 | Stripe | Processing fees | 87.30 | INS | 100% | 87.30 | ✅ |

> \*Equipment is typically **depreciated** over its useful life rather than expensed all at once (unless you use a small-business expensing election like Section 179 or the Annual Investment Allowance).

---

## Category Summary (monthly)

| Category | Total Spend | Deductible | % of Total |
|----------|-------------|-----------|-----------|
| SW | 320.00 | 320.00 | 8.5% |
| MKT | 450.00 | 450.00 | 12.0% |
| CON | 800.00 | 800.00 | 21.3% |
| VEH | 62.40 | 43.68 | 1.7% |
| TRA | 14.50 | 7.25 | 0.4% |
| EQP | 1,299.00 | 1,299.00 | 34.6% |
| HOME | 89.99 | 36.00 | 2.4% |
| RET | 1,500.00 | 1,500.00 | 40.0% |
| INS | 87.30 | 87.30 | 2.3% |
| PER | 120.00 | 0.00 | 3.2% |
| **Total** | **4,743.19** | **4,543.23** | — |

**Deductible rate: 95.8%** — excellent. Only the groceries were personal.

---

## Business-Use Percentage Calculator

For mixed-use expenses (home office, vehicle, phone), calculate the business portion.

### Home Office (simplified method)

```
Business % = (Hours worked from home ÷ Total hours in month) × 100

Example:
  160 business hours ÷ 720 total hours = 22%
  Rent $1,800 × 22% = $396 deductible
```

### Home Office (actual method)

```
Business % = (Home office sq ft ÷ Total home sq ft) × 100

Example:
  150 sq ft office ÷ 1,200 sq ft home = 12.5%
  Utilities $200 × 12.5% = $25 deductible
```

### Vehicle

```
Business % = (Business miles ÷ Total miles) × 100

Example:
  8,000 business miles ÷ 12,000 total = 66.7%
  Or use standard mileage rate (~67¢/mile in 2026)
  8,000 miles × $0.67 = $5,360 deductible
```

### Phone & Internet

```
Business % = (Business usage ÷ Total usage) × 100

Example:
  Internet 40% business × $89.99 = $36.00 deductible
```

---

## Receipt Management

| Method | Tool | Best for |
|--------|------|----------|
| **Photo + folder** | Phone camera → cloud folder by month | Simple, free |
| **Email receipts** | Auto-forward to a dedicated inbox | Subscriptions |
| **Scanning app** | Expensify, Wave, Dext | High volume |
| **Bank feed** | Connect card to software | Hands-off |

**Naming convention:** `YYYY-MM-DD_Merchant_Amount.pdf`
Example: `2026-10-08_Apple_1299.00.pdf`

> **Keep receipts for 6–7 years** (varies by country). Digital copies are accepted in most jurisdictions.

---

## Country Notes

| Country | Key point |
|---------|-----------|
| 🇺🇸 **US** | Meals 50% deductible; Section 179 for equipment; track mileage carefully |
| 🇬🇧 **UK** | "Wholly and exclusively" test; £1,000 trading allowance; simplified expenses for home/mileage |
| 🇨🇦 **Canada** | Reasonable business purpose required; CCA for equipment; keep logbooks |
| 🇦🇺 **Australia** | Substantiation required > $300; instant asset write-off; 67¢/hr home office rate |

---

## Red Flags (don't do these)

- ❌ Claiming personal expenses as business — triggers audits
- ❌ Mixing personal and business accounts — impossible to untangle
- ❌ No receipts for large claims — deductions get denied
- ❌ Claiming 100% of a mixed-use item (phone, car, home)
- ❌ Deducting owner's draws as an expense — they're distributions
- ❌ Round-number "estimates" with no backup

---

## Monthly Categorisation Checklist

- [ ] Exported all transactions
- [ ] Applied rules to every line
- [ ] Flagged ambiguous items for accountant
- [ ] Calculated business-use % for mixed expenses
- [ ] Filed all receipts with correct naming
- [ ] Updated category summary
- [ ] Moved personal items out of business books
- [ ] Fed totals into `profit-dashboard.md`

---

## Quick Decision Tree

```
Is it for the business?
├── No  → PER (personal) — keep OUT of business books
└── Yes → Is it a direct cost of delivering your work?
          ├── Yes → COGS
          └── No  → Is it used only for business?
                    ├── Yes → full deduction (SW, MKT, CON, etc.)
                    └── No  → mixed use → apply business % (HOME, VEH)
```

---

*Categorised totals feed `profit-dashboard.md`. Deductible expenses reduce taxable profit in `tax-calculator.md`.*
