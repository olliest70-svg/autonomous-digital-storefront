# Async Standup Template

> **Goal:** Replace the daily status call with a written update that takes ~4 minutes to write and ~90 seconds to read. Everyone stays informed without anyone losing their morning.

---

## Why async standups work

A 15-minute daily call with 8 people costs **2 person-hours every day** — 40 hours a month. A written standup costs each person 4 minutes and lets people read on their own schedule, across time zones, with a searchable history.

| | Sync standup | Async standup |
|---|---|---|
| Time cost (8 people) | ~2 hrs/day | ~35 min/day |
| Time-zone friendly | ❌ | ✅ |
| Searchable history | ❌ | ✅ |
| Interrupts deep work | ✅ (bad) | ❌ |
| Forces clarity | Sometimes | Always |

---

## The format (copy this)

Post in your team channel each morning (or at the start of your working day). Keep it to **three sections**.

```markdown
**Daily Update — [Your Name] — [Date]**

**✅ Yesterday**
- Shipped the CSV export endpoint (PR #482 merged)
- Reviewed Maya's onboarding copy

**🎯 Today**
- Wire up export button in the dashboard UI
- Pair with Sam at 14:00 UTC on the auth refactor

**🚧 Blockers / Needs**
- Waiting on design tokens from @maya — blocking the button styling
- Need someone to approve the staging deploy
```

That's it. Three headers, bullets, links where relevant.

---

## Rules that make it work

1. **Post by a fixed time** (e.g. within 60 min of starting your day). Consistency beats perfection.
2. **Blockers get tagged.** Use `@name` so the right person is notified. A blocker with no tag is a blocker nobody owns.
3. **Link, don't describe.** Point to the PR, ticket, or doc instead of summarizing it in prose.
4. **No essays.** If a bullet needs more than two lines, it belongs in a doc — link to it.
5. **Read, don't reply.** Only respond if you can unblock someone. Silence is fine.
6. **Skip when nothing changed.** "No update today — heads-down on X" is a valid post.

---

## Blocker escalation ladder

A blocker posted in standup should never sit for more than one working day.

| Age of blocker | Action |
|---|---|
| < 4 hours | Owner responds in thread |
| 4–24 hours | Owner tags their lead |
| > 24 hours | Lead escalates in the weekly sync or to the manager |
| > 48 hours | Add to the risk register; assign a decision owner |

---

## Weekly digest (optional, for managers)

On Fridays, the team lead posts a roll-up so leadership doesn't need to read every daily post:

```markdown
**Weekly Digest — Week of [Date]**

**Shipped:** CSV export, new onboarding flow, auth refactor (phase 1)
**In progress:** Dashboard export UI, billing migration
**Risks:** Auth refactor slipping 2 days — dependency on vendor API
**Decisions needed:** Do we extend the beta by one week? (See decision log #34)
**Shoutouts:** @sam unblocked the deploy at 22:00 UTC 🙌
```

---

## Where to post it

| Tool | Setup |
|---|---|
| **Slack / Teams** | One `#standup` channel. Use a thread per day to keep it tidy, or one post per person per day. |
| **Notion** | A database with columns: Person, Date, Yesterday, Today, Blockers. Filter by today. |
| **GitHub / Linear** | A daily issue or discussion thread. Auto-archive weekly. |
| **Geekbot / Standuply** | Automates the prompt + collection. Good for larger teams. |

---

## Common failure modes (and fixes)

| Failure | Fix |
|---|---|
| People post generic updates ("working on stuff") | Add a rule: every bullet names a concrete artifact (PR, doc, ticket). |
| Updates get ignored | Lead reads daily and reacts to blockers within 4 hours. |
| Posts get too long | Enforce 2-line max per bullet; move detail to linked docs. |
| Time zones make "morning" meaningless | Use "within 60 min of your local start" instead of a fixed UTC time. |
| It fades after 3 weeks | Put the standup link in the channel topic and review it in retro. |

---

## Notion-ready block

Paste this into a Notion template button or database:

```
✅ Yesterday
- 

🎯 Today
- 

🚧 Blockers / Needs
- 
```

> **Pro tip:** Create a Notion *template button* called "Post Standup" that inserts the three sections with today's date pre-filled. One click, done.
