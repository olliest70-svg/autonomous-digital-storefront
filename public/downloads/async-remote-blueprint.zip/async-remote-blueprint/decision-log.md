# Decision Log

> **Goal:** A single, searchable record of every meaningful decision — what we chose, why, who owns it, and when we'll revisit. No more "wait, why did we do it that way?"

---

## Why keep a decision log

In a remote team, decisions made in DMs, calls, or hallway chats **evaporate**. New hires re-litigate settled questions. People build on assumptions that were never agreed. A decision log turns tribal memory into institutional memory.

**A good decision log answers five questions:**
1. **What** did we decide?
2. **Why** did we decide it (the rationale)?
3. **Who** decided and who is accountable?
4. **When** does it take effect, and when do we revisit?
5. **What** did we consider and reject?

---

## What counts as a "decision"?

Log anything that is:
- **Hard to reverse** (architecture, pricing, hiring, vendor choice), **or**
- **Cross-team** (affects more than one squad), **or**
- **Likely to be questioned later** ("why don't we just use X?").

Do **not** log: routine task assignments, obvious bug fixes, or anything reversible in under a day.

---

## The template (copy this)

```markdown
### DEC-### — [Short decision title]

| Field | Value |
|---|---|
| **Status** | Proposed / Accepted / Superseded / Deprecated |
| **Date** | YYYY-MM-DD |
| **Decider** | @name (accountable) |
| **Consulted** | @names |
| **Informed** | @group / channel |
| **Revisit by** | YYYY-MM-DD |
| **Supersedes** | DEC-### (or —) |

**Context**
What's the situation that forced a decision? 2–4 sentences.

**Decision**
The choice, stated in one clear sentence. Start with "We will…"

**Rationale**
Why this option. The trade-offs we accepted.

**Alternatives considered**
- Option B — rejected because…
- Option C — rejected because…

**Consequences**
What changes as a result. What we now owe (docs, migrations, comms).

**Links**
- Related doc / PR / thread
```

---

## Worked example

```markdown
### DEC-014 — Use Postgres instead of MongoDB for the events store

| Field | Value |
|---|---|
| **Status** | Accepted |
| **Date** | 2026-03-11 |
| **Decider** | @priya (Staff Engineer) |
| **Consulted** | @sam, @maya, @dan |
| **Informed** | #engineering |
| **Revisit by** | 2026-09-01 |
| **Supersedes** | — |

**Context**
The events store is growing ~40% quarter over quarter. Our current MongoDB setup
requires custom aggregation pipelines that only two engineers understand, and
reporting queries are slow and hard to maintain.

**Decision**
We will migrate the events store to Postgres with a partitioned table per month.

**Rationale**
Our team already runs Postgres in production, so operational burden is near zero.
SQL lets analysts query events directly without engineering help. Partitioning gives
us predictable performance and cheap archival (drop old partitions).

**Alternatives considered**
- Stay on MongoDB — rejected: bus factor of 2, slow reporting.
- ClickHouse — rejected: new operational surface, overkill at our volume.
- BigQuery — rejected: cost unpredictable at our write rate.

**Consequences**
- 3-week migration project owned by @sam.
- Analytics team can self-serve; remove the custom pipeline.
- Update the data architecture doc and onboarding guide.

**Links**
- RFC: /docs/rfc/events-store
- Migration ticket: ENG-2291
```

---

## Status values (use exactly these)

| Status | Meaning |
|---|---|
| **Proposed** | Under discussion, not yet binding |
| **Accepted** | In effect — build on this |
| **Superseded** | Replaced by a newer decision (link it) |
| **Deprecated** | No longer relevant, but kept for history |

**Never delete a decision.** Supersede it. The history is the value.

---

## The decision log index

Keep a scannable table at the top of your log (or as a Notion database view):

| ID | Decision | Status | Decider | Date | Revisit |
|----|----------|--------|---------|------|---------|
| DEC-014 | Use Postgres for events store | Accepted | @priya | 2026-03-11 | 2026-09-01 |
| DEC-013 | Freeze feature work during Q1 audit | Superseded | @dan | 2026-02-02 | — |
| DEC-012 | Adopt trunk-based development | Accepted | @sam | 2026-01-20 | 2026-07-20 |

---

## Operating rules

1. **One decider per decision.** Committees don't decide; people do. Name the accountable person.
2. **Write it within 48 hours.** Memory decays fast. Log while context is fresh.
3. **Link, don't copy.** Point to the RFC or thread; don't duplicate the whole discussion.
4. **Set a revisit date** for anything reversible or assumption-based.
5. **Review monthly.** In your team sync, scan decisions whose revisit date has passed.
6. **Announce accepted decisions** in the channel so nobody is surprised.

---

## Notion setup

Create a **database** with these properties:

| Property | Type |
|---|---|
| ID | Text (e.g. DEC-014) |
| Title | Title |
| Status | Select: Proposed / Accepted / Superseded / Deprecated |
| Decider | Person |
| Date | Date |
| Revisit by | Date |
| Tags | Multi-select (e.g. architecture, pricing, hiring) |
| Context / Decision / Rationale | Text (or use the page body) |

**Views to create:**
- **Active** — filter Status = Accepted, sort by Date desc.
- **Needs revisit** — filter Revisit by ≤ today.
- **By tag** — group by Tags.

> **Pro tip:** Add a database automation that pings the decider when the "Revisit by" date arrives.
