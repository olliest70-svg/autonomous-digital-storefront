# 🧠 ADHD Focus Flow System

**A gentle, low-friction system for getting things done with an ADHD brain.**

No shame. No 47-step morning routine. No "just use a planner" advice.

Just a small set of tools that work *with* your brain instead of against it — built for real days, real energy dips, and real dopamine.

---

## What this is

A complete, ready-to-use focus system you can start using in the next 10 minutes. It's built around three ideas:

1. **Lower the bar until starting is easy.** Motivation follows action, not the other way around.
2. **Externalize everything.** Your working memory is for thinking, not for storing. Get it out of your head and onto paper.
3. **Feed the dopamine.** Focus isn't a willpower problem — it's a chemistry problem. We work with it.

---

## What's inside

| File | What it's for | When to use it |
|---|---|---|
| `README.md` | You're here. Start here. | Once, right now |
| `today-board.md` | Your single daily dashboard | Every morning (2 min) |
| `daily-focus-system.md` | The core method: how to actually focus | Read once, then daily |
| `dopamine-menu.md` | A menu of rewards + stimulation snacks | Whenever you need a boost |
| `brain-dump-inbox.md` | A parking lot for every stray thought | All day, constantly |
| `weekly-reset.md` | A 20-minute weekly tidy-up | Once a week |

---

## How to start (the 10-minute version)

You don't need to read everything. Do this:

1. **Open `today-board.md`** and fill in just the top section. Three things. That's it.
2. **Skim `daily-focus-system.md`** — read the "The 3-Bucket Day" section only.
3. **Keep `brain-dump-inbox.md` open** in a tab or on your desk all day.
4. **Bookmark `dopamine-menu.md`** for when you hit a wall.
5. **Set a reminder for Sunday** to do your first `weekly-reset.md`.

That's the whole onboarding. Everything else is optional depth.

---

## The 5 rules of this system

> **1. If it's not written down, it doesn't exist.**
> Your brain is a brilliant idea machine and a terrible filing cabinet. Write it down.

> **2. Three things is a full day.**
> Not three *big* things. Three *real* things. If you finish them, you won. Anything else is a bonus.

> **3. Start ugly.**
> The first version is allowed to be bad. Bad and done beats perfect and imaginary.

> **4. Rest is part of the work.**
> A brain that never idles can't think. Breaks aren't cheating.

> **5. Missing a day means nothing.**
> This system has no streaks to break. You can't fall off a wagon that has no wagon. Just come back.

---

## A note on bad days

Some days, the system won't work. You'll be too tired, too overwhelmed, too *everything*.

On those days, the whole system reduces to one question:

**"What's the smallest useful thing I can do right now?"**

Maybe that's drinking water. Maybe it's sending one email. Maybe it's closing your eyes for ten minutes. All of it counts.

You are not behind. You are a person with a brain that works differently, doing your best on a hard day. That's enough.

---

## Customizing this system

This is *your* system now. Feel free to:

- Delete anything that feels like a chore.
- Rename sections to words that feel good to you.
- Add your own dopamine rewards.
- Print the pages and stick them on a wall.
- Use it on paper, in Notion, in Obsidian, or in a notes app.

The best system is the one you'll actually open tomorrow.

---

*Made for the beautifully non-linear brain. Go gently.* 🌿
