# 🍫 Dopamine Menu

**For when your brain says "I want *something*" but won't tell you what.**

ADHD brains run low on dopamine — the "let's do this" chemical. That's why boring tasks feel physically painful and why you can scroll for two hours without noticing. This menu is your toolkit for topping up your dopamine **on purpose**, in ways that actually help.

---

## How to use this menu

1. When you feel restless, foggy, or stuck — **don't fight it. Feed it.**
2. Pick a **Starter** (small, quick) or a **Main** (bigger, more satisfying).
3. Set a timer so the reward doesn't become the whole day.
4. Come back and do one more tiny thing.

> **The golden rule:** A reward only works if it's *after* something, not *instead of* it.

---

## 🥗 Starters (2–5 minutes)

Quick hits. Perfect between sprints or when you need a reset.

| Reward | Time | Why it works |
|---|---|---|
| Glass of cold water + a stretch | 2 min | Physical reset, zero effort |
| Step outside / open a window | 2 min | Daylight = dopamine + mood |
| 10 slow, deep breaths | 2 min | Calms the "I'm behind" panic |
| One song, loud, dancing optional | 3 min | Instant mood shift |
| Pet an animal / look at cute photos | 2 min | Genuine micro-joy |
| Make a hot drink | 4 min | Ritual + warmth + a small win |
| Tidy exactly one surface | 5 min | Visible progress = dopamine |
| Write 3 things you're glad about | 3 min | Cheap, fast, effective |

---

## 🍝 Mains (15–60 minutes)

Bigger rewards. Earn these after a solid block of work, or when you genuinely need to recharge.

| Reward | Time | Notes |
|---|---|---|
| A proper walk (ideally outside) | 20–40 min | The single best ADHD reset |
| A favourite show episode | 30–45 min | Set a timer so it stays one episode |
| A hobby you love (game, art, music) | 30–60 min | Joy is fuel, not a distraction |
| A real meal, sitting down | 20–30 min | Fed brain = working brain |
| A nap (20 min max) | 20 min | Resets focus better than caffeine |
| Call a friend who gets you | 20–30 min | Connection is a dopamine source |
| A long shower or bath | 20–30 min | Sensory reset + calm |
| Exercise / gym / dancing | 30–60 min | Best long-term dopamine builder |

---

## 🍰 Desserts (use sparingly)

These feel great and give you nothing back. They're not *bad* — they're just not fuel. Have them knowingly.

- Doomscrolling social media
- One more "quick" video
- Online shopping with no intention to buy
- Refreshing your inbox for no reason
- Reorganizing your notes app instead of working

> **Not a moral failing.** Just be honest with yourself: *"I'm choosing a dessert right now."* Naming it keeps you in charge.

---

## 🎁 The Stimulation Snack Box

Sometimes you don't need a reward — you need **background stimulation** to make a boring task bearable. That's legitimate. Try:

- **Music:** Lo-fi, video game soundtracks, or a "focus" playlist.
- **Brown noise / white noise:** Great for blocking out chaos.
- **A fidget toy or a pen to click.**
- **A podcast or video essay** while doing physical chores.
- **Standing up** instead of sitting.
- **A timer you can watch** (visual timers are magic).
- **A body double** (see `daily-focus-system.md`).

---

## 🧪 The Dopamine Reset (when nothing works)

If *everything* feels flat and pointless, your dopamine tank is empty. Try this 15-minute reset:

```
1. Drink water. Eat something with protein.        (2 min)
2. Go outside or stand in daylight.                (5 min)
3. Move your body — walk, stretch, dance.          (5 min)
4. Do ONE tiny task you can finish in 2 minutes.   (2 min)
5. Notice that you did it. That's a win.           (1 min)
```

The goal isn't to feel amazing. It's to get one small "done" feeling — which is the spark that starts the engine.

---

## 🧠 Why this works (the science, briefly)

- **Dopamine drives motivation, not pleasure.** Low dopamine = tasks feel impossible, not just unappealing.
- **Anticipation beats reward.** Knowing a reward is *coming* is often more motivating than the reward itself. So plan rewards *before* you start.
- **Novelty and movement boost dopamine.** That's why a walk, a new playlist, or a change of scenery can unlock focus.
- **Small wins compound.** Each finished micro-task releases a little dopamine — which makes the next one easier.

---

## 📋 Build your own menu

Everyone's dopamine is different. Fill this in with *your* rewards:

**My Starters:**
- 
- 
- 

**My Mains:**
- 
- 
- 

**My Desserts (use knowingly):**
- 
- 

**My Stimulation Snacks:**
- 
- 

> **Tip:** Keep this list somewhere you'll see it. When you're stuck, you won't have the energy to *think* of a reward — you'll need it ready-made. 🌿
