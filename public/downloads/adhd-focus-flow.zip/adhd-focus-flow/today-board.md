# ☀️ Today Board

> **Fill this in every morning. It takes 2 minutes.**
> If you only ever use one file from this system, use this one.

---

## 📅 Today

**Date:** _______________
**Energy level right now:** ☐ Low ☐ Medium ☐ High
**One word for how I feel:** _______________

---

## 🎯 My 3 Things

The rule: **three real things is a full day.** Not three *big* things — three *real* ones. If you finish these, today is a win.

| # | The thing | How long (guess) | Done? |
|---|---|---|---|
| 1 | | | ☐ |
| 2 | | | ☐ |
| 3 | | | ☐ |

> **Stuck on what to put here?** Pick the thing that, if done, would make you feel most relieved tonight. That's #1.

---

## 🪄 The One Thing

If everything else falls apart today, this is the one I'll still be proud of:

**→** _______________________________________________

---

## ⚡ First Tiny Step

Not the whole task. Just the *first 2-minute action* that starts it.

**→** _______________________________________________

*(Examples: "open the document," "find the email," "put on my shoes," "write one bad sentence.")*

---

## 🍫 My Dopamine Plan

What I'll give myself **after** each thing (pick from your Dopamine Menu):

| After... | I get... |
|---|---|
| Thing 1 | |
| Thing 2 | |
| Thing 3 | |

---

## 🧺 Brain Dump

Everything else floating around in my head. Park it here so it stops nagging me.

- 
- 
- 
- 
- 

*(Move anything important to `brain-dump-inbox.md` at the end of the day.)*

---

## 🌿 Body Check

Tick what you've done. These aren't chores — they're fuel.

- ☐ Water (a glass, right now)
- ☐ Something to eat
- ☐ Moved my body (even 2 minutes counts)
- ☐ Stepped outside / saw daylight
- ☐ Took my meds (if you take them)

---

## 🌙 End of Day

**What actually got done:** _______________________________________________

**What I'm proud of, even if small:** _______________________________________________

**One thing to carry to tomorrow:** _______________________________________________

> **Reminder:** You don't have to finish everything. You just have to have started. Look at what you did — it counts.

---

## 📋 Copy-paste template (for digital use)

```markdown
## Today — [DATE]
Energy: [low/med/high]

### My 3 Things
1. [ ] 
2. [ ] 
3. [ ] 

### The One Thing
→ 

### First Tiny Step (2 min)
→ 

### Dopamine Plan
- After 1: 
- After 2: 
- After 3: 

### Brain Dump
- 
- 

### Body Check
- [ ] Water  - [ ] Food  - [ ] Movement  - [ ] Daylight  - [ ] Meds

### End of Day
- Done: 
- Proud of: 
- Carry forward: 
```
