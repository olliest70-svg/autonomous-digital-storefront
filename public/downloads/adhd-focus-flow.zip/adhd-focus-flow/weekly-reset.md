# 🔄 Weekly Reset

**20 minutes, once a week. The tidy-up that keeps everything else working.**

Your daily system keeps you moving. The Weekly Reset keeps you *pointed in the right direction*. It's the one time you zoom out, clear the decks, and set up the week ahead.

**Pick a time and protect it.** Sunday evening works for many people. So does Monday morning, or Friday afternoon. The day matters less than the *ritual*.

---

## The 20-minute reset (step by step)

Set a timer for 20 minutes. Work through the five steps. If you don't finish, that's fine — do the rest next week.

### ⏱️ Step 1 — Empty the Brain Dump (5 min)
Open `brain-dump-inbox.md`. Sort every item using the **4 D's**:

- ✅ **Do** (under 2 min) → do it right now, or add to this week
- 📅 **Diary** (has a date) → put it in your calendar
- 📝 **Defer** (matters, not now) → move to your project list below
- 🗑️ **Delete** (doesn't matter) → let it go, no guilt

Then clear the inbox. A clean inbox = a quiet brain.

### ⏱️ Step 2 — Look Back (3 min)
Ask yourself, honestly:

- What actually got done this week? *(Write it down — you'll forget the wins.)*
- What didn't, and why? *(No shame — just data.)*
- What drained me? What gave me energy?

### ⏱️ Step 3 — Look Ahead (5 min)
Scan the week coming up:

- What's on the calendar? Any appointments, deadlines, birthdays?
- What's the **one thing** that, if done, would make next week feel like a win?
- What needs a head start so it doesn't become an emergency?

### ⏱️ Step 4 — Set Up Next Week (5 min)
- Choose your **3 priorities** for the week (not 30).
- Break each into a first tiny step.
- Pre-plan your dopamine rewards for the big ones.
- Block focus time in your calendar *before* the week fills up.

### ⏱️ Step 5 — Reset Your Space (2 min)
- Clear your desk / main surface.
- Close the tabs you're not using.
- Refill water, restock snacks, charge devices.
- A tidy space makes starting easier tomorrow.

---

## 📝 Your Weekly Reset (fill this in)

```markdown
# Weekly Reset — Week of ______________

## 1. Brain Dump
- Emptied? ☐   Items sorted: ___   Deleted: ___

## 2. Look Back
- Wins this week:
  - 
  - 
- Didn't happen (and why):
  - 
- Drained me: 
- Energized me: 

## 3. Look Ahead
- Calendar events: 
- Deadlines: 
- The One Thing for next week: 

## 4. Set Up Next Week
- Priority 1: 
- Priority 2: 
- Priority 3: 
- Rewards planned: 

## 5. Reset Space
- Desk cleared? ☐   Tabs closed? ☐   Water refilled? ☐
```

---

## 🗂️ The Parking Lot (Deferred items)

Things that matter but aren't for this week. Park them here so they stop nagging you.

| Item | Category | Revisit when |
|---|---|---|
| | | |
| | | |
| | | |
| | | |

**Categories:** Home · Money · Health · Work · People · Ideas · Someday

---

## 📊 The Weekly Scorecard

A gentle, judgment-free look at the week. Tick what's true.

| Question | Yes | Sort of | No |
|---|---|---|---|
| Did my One Thing get done? | ☐ | ☐ | ☐ |
| Did I use my Today Board most days? | ☐ | ☐ | ☐ |
| Did I take real breaks? | ☐ | ☐ | ☐ |
| Did I move my body? | ☐ | ☐ | ☐ |
| Did I get enough rest? | ☐ | ☐ | ☐ |
| Did I ask for help when I needed it? | ☐ | ☐ | ☐ |

> **How to read this:** There's no score to beat. This isn't a report card — it's a mirror. If something's consistently "No," that's your clue about what to change next week. One adjustment at a time.

---

## 🧭 The Monthly Zoom-Out (optional, 15 min)

Once a month, add a longer look:

- Am I working on things that actually matter to me?
- What have I been avoiding, and why?
- What's one thing I could *stop* doing?
- What's one small thing I want more of next month?

---

## 🌿 The spirit of the Weekly Reset

This isn't about being productive. It's about being **intentional**.

You're not tidying up to prove anything. You're clearing the fog so you can see where you're going — and so the week ahead feels *lighter*, not heavier.

If you miss a week, the system doesn't break. Just do the next one. There are no streaks here, only fresh starts.

**You've got this. Go gently.** 🌿
