# 🧺 Brain Dump Inbox

**Every thought, task, worry, and "oh I should..." goes here.**

Your brain is for having ideas, not for holding them. Every open loop in your head is quietly draining your focus. This file is where you put them so your brain can let go.

---

## How to use this inbox

1. **Keep it open all day** — a tab, a notes app, or a piece of paper on your desk.
2. **Dump everything.** No sorting. No judging. No "I'll remember it."
3. **Don't act on it.** The whole point is to *capture*, not to *do*.
4. **Empty it during your Weekly Reset** (see `weekly-reset.md`).

> **The rule:** If it's in your head, it's costing you energy. Get it out. You can always deal with it later — but only if you wrote it down.

---

## 📥 The Inbox

*Add anything here, any time. Newest at the top.*

### [Date: ____________]

- 
- 
- 
- 
- 
- 
- 
- 
- 
- 

---

## 🗂️ Sort it later (the 4 D's)

When you empty the inbox, every item goes into exactly one of these buckets:

| The 4 D's | Meaning | Where it goes |
|---|---|---|
| ✅ **Do** | Takes under 2 minutes | Just do it now |
| 📅 **Diary** | Has a real deadline or date | Add to your calendar |
| 📝 **Defer** | Matters, but not now | Move to your project list / Weekly Reset |
| 🗑️ **Delete** | Doesn't actually matter | Let it go. Guilt-free. |

**The ADHD trap:** Everything *feels* like it should go in "Do." Be ruthless. Most things are Defer or Delete.

---

## 🧠 Types of brain dumps

Not every dump is a to-do list. Here's how to handle each kind:

### 1. The Task Dump
Random things you need to do.
→ Goes into the Inbox, then gets sorted with the 4 D's.

### 2. The Worry Dump
Anxieties, "what ifs," things you're dreading.
→ Write them down. Then ask: *"Is this something I can act on?"* If yes, make it a task. If no, it's a worry — and worries get to sit here, not in your head.

### 3. The Idea Dump
Half-formed ideas, sparks, "wouldn't it be cool if..."
→ Capture it. Don't evaluate it now. Some of your best work starts as a messy note.

### 4. The Feeling Dump
Overwhelm, frustration, "I can't do this."
→ Write it out raw. No editing. Often, just naming the feeling shrinks it.

---

## 🧾 Example: A real brain dump

Here's what a genuine, messy dump looks like — and how it gets sorted.

**Raw dump (Monday, 3:47pm):**
```
- email Sarah back about the invoice
- I keep forgetting to book the dentist
- that idea for the podcast episode
- I'm so behind on everything
- buy cat food
- should I switch phone plans??
- the report is due Friday and I haven't started
- mom's birthday is coming up, get a gift
- why is this so hard today
- fix the leaky tap
- look up that ADHD book someone mentioned
```

**After sorting (the 4 D's):**

| Item | Bucket | Action |
|---|---|---|
| Email Sarah re: invoice | ✅ Do | 2 min — do it now |
| Book dentist | 📅 Diary | Calendar it for Thursday 10am |
| Podcast idea | 📝 Defer | Move to "Ideas" list |
| "I'm so behind" | 🧠 Worry | Name it, let it go — not actionable |
| Buy cat food | ✅ Do | On the way home |
| Switch phone plans | 📝 Defer | Weekly Reset — research later |
| Report due Friday | 📅 Diary | Block 2 sprints on Wed + Thu |
| Mom's birthday gift | 📅 Diary | Calendar reminder 1 week before |
| "Why is this so hard" | 🧠 Feeling | Acknowledge it. Rest tonight. |
| Fix leaky tap | 📝 Defer | Add to "Home" list |
| ADHD book | 📝 Defer | Add to "Read later" list |

> **Notice:** Only 2 things were "Do." Everything else got parked somewhere safe. That's the whole point — the brain dump doesn't create more work, it *reveals* how little is actually urgent.

---

## 📋 Copy-paste template

```markdown
## Brain Dump — [DATE]

- 
- 
- 

### Sort (4 D's)
- Do (2 min): 
- Diary (date): 
- Defer (later): 
- Delete (let go): 
```

---

## 🌿 A gentle reminder

A full inbox is not a sign of failure. It's a sign you're paying attention to your life.

You don't have to empty it perfectly. You just have to keep it *out of your head* and *somewhere you can find it*. That's already a huge win for an ADHD brain.
