# 🎯 Daily Focus System

**The core method. Read this once. Then use it every day.**

This is the engine behind the whole system. It's built for ADHD brains, which means: short, visual, forgiving, and designed to survive a bad day.

---

## Part 1 — The 3-Bucket Day

Every task in your life belongs in one of three buckets. When you know which bucket something is in, you know how to handle it.

| Bucket | What it is | How to handle it |
|---|---|---|
| 🟥 **Red** | Things that are urgent *and* matter | Do these first, with a timer |
| 🟨 **Yellow** | Things that matter but aren't urgent | Schedule them, don't "get to them" |
| 🟦 **Blue** | Things that feel urgent but don't actually matter | Delegate, delay, or delete |

**The ADHD trap:** Blue tasks *feel* the most urgent (email, notifications, "quick" favours) and eat the whole day. Red and Yellow are what actually move your life.

**Daily rule:** Pick **one Red**, **one Yellow**, and **one Blue-or-bonus** for your Today Board. That's your three.

---

## Part 2 — The Focus Sprint

The core unit of work. Not "work until it's done" — that's a trap. Instead:

### The Sprint Recipe

```
1. Pick ONE task (from your Today Board)
2. Set a timer: 15, 25, or 45 minutes
3. Close every tab that isn't the task
4. Phone in another room (or face down + silent)
5. Work until the timer rings — then STOP, even if you're on a roll
6. Take a real break (see Dopamine Menu)
7. Repeat, or switch tasks
```

**Why stop when you're on a roll?** Because stopping *while it feels good* makes it dramatically easier to start again next time. The ADHD brain remembers the last feeling. End on a high.

### Choosing your sprint length

| Your state | Sprint length | Why |
|---|---|---|
| Foggy, resistant, "can't start" | **10–15 min** | So short your brain can't argue |
| Normal, steady | **25 min** | Classic, sustainable |
| Locked in, hyperfocus-adjacent | **45 min** | Ride it, but set a hard stop |
| Post-medication window | **Your best 2–3 hours** | Protect this time fiercely |

---

## Part 3 — The 2-Minute Launch

The hardest part of any task is the first 2 minutes. So we only commit to 2 minutes.

**The rule:** You are allowed to quit after 2 minutes. Genuinely. No guilt.

**Why it works:** 80% of the time you won't quit — starting is the barrier, not doing. And when you *do* quit, you've still broken the freeze and made the task less scary next time.

### How to find your 2-minute launch

Take any task and shrink it until it's almost silly:

| The task | The 2-minute launch |
|---|---|
| "Write the report" | Open the doc and type the title |
| "Do the dishes" | Wash exactly three things |
| "Reply to emails" | Open the inbox and read one |
| "Go to the gym" | Put on your workout clothes |
| "Study for the exam" | Open the textbook to any page |
| "Clean the kitchen" | Clear one counter |

> **If you can't find a 2-minute version, the task is too vague.** Break it down further. "Get healthy" isn't a task — "fill my water bottle" is.

---

## Part 4 — Body Doubling & External Structure

ADHD brains often focus *better* when someone else is present. This is called **body doubling**, and it's a superpower, not a weakness.

**Ways to body double:**

- **In person:** Work in the same room as a friend, even in silence.
- **Video call:** Silent co-working on Zoom/FaceTime. Cameras on, mics off.
- **Livestream:** "Study with me" videos on YouTube.
- **Café/library:** The gentle pressure of strangers working.
- **Virtual coworking:** Apps and Discord servers built for this.

**Try it:** Schedule one 25-minute body-doubling session today. Notice how much easier starting feels.

---

## Part 5 — The Transition Ritual

ADHD brains struggle with *switching* tasks, not just starting them. A 30-second ritual makes transitions smoother.

**The ritual (say it out loud or in your head):**

```
1. "I'm closing this task."  → Save, close the tab, put the pen down
2. "Here's what's next."     → Read the next task from your Today Board
3. "First tiny step is..."   → Name the 2-minute launch
4. "Go."
```

The physical act of *closing* something tells your brain it's safe to let go.

---

## Part 6 — When You Get Stuck (the Unsticking Flowchart)

```
Stuck?
│
├─ "I don't know where to start"
│     → Do the 2-minute launch. Anything counts.
│
├─ "It's too big / overwhelming"
│     → Break it into 3 steps. Only do step 1.
│
├─ "I'm bored / it's not stimulating"
│     → Add stimulation: music, a timer, a reward, body double.
│
├─ "I'm anxious / avoiding it"
│     → Name the fear out loud. Then do 2 minutes anyway. You can stop after.
│
├─ "I'm exhausted"
│     → This is a rest problem, not a focus problem. Rest. Come back.
│
└─ "I keep getting distracted"
      → Remove one distraction. Just one. Then restart the sprint.
```

---

## Part 7 — A Real Day, Start to Finish

Here's what this looks like in practice.

> **8:40am** — Coffee in hand. Open `today-board.md`. Energy: medium.
> Three things: (1) Send the client proposal 🟥, (2) Draft the newsletter 🟨, (3) Tidy desk 🟦.
> One Thing: the proposal. First tiny step: *open the proposal doc.*
>
> **8:45am** — 2-minute launch: open the doc. Type a messy title. It's ugly. Good.
> **8:50am** — 25-min sprint. Phone in the drawer. One tab. Timer on.
> **9:15am** — Timer rings. Stop. Dopamine reward: 5-minute walk + a coffee refill.
> **9:25am** — Second sprint on the proposal. Get to a rough first draft.
> **9:50am** — Hit a wall. Brain is foggy. Brain-dump the stray thoughts into `brain-dump-inbox.md`.
> **10:00am** — Body-double on a video call. 25 min on the newsletter.
> **10:30am** — Energy dipping. Switch to a low-effort task (tidy desk). Movement counts as rest.
> **11:00am** — Two of three things done. The proposal is *sent*. Close the laptop.
>
> **Result:** Not a perfect day. A *real* one. The One Thing got done.

---

## Part 8 — The Golden Rules

1. **Start before you feel ready.** Readiness is a myth your brain tells you.
2. **One task at a time.** Multitasking is just rapid task-switching with extra guilt.
3. **Timers are your friend.** They make time visible — ADHD brains can't *feel* time passing.
4. **Stop while it feels good.** It makes tomorrow easier.
5. **Reward the starting, not just the finishing.** You did the hard part.
6. **A bad day is data, not a verdict.** Note what tripped you up and adjust.

---

> **Remember:** This system is a set of tools, not a test. Use the parts that help. Ignore the parts that don't. You're not failing the system — you're customizing it. 🌿
