# 🧮 Tax Calculator & Set-Aside Planner

Estimate your income tax and self-employment contributions, then set aside the right amount every time you get paid — so year-end never hurts.

> ⚠️ **Disclaimer:** This is a planning tool, not tax advice. Rates and thresholds change and vary by personal circumstances. Always confirm your final numbers with a qualified accountant or tax professional in your jurisdiction.

---

## Step 1 — Know Your Numbers

Fill this in first. Everything else flows from it.

| Input | Your figure | Example |
|-------|-------------|---------|
| Gross business revenue (annual) | | 120,000 |
| Business expenses (deductible) | | 28,000 |
| **Net profit (taxable income)** | | **92,000** |
| Other income (salary, dividends) | | 0 |
| Retirement contributions | | 6,000 |
| Health insurance premiums (self-paid) | | 4,800 |
| Home office deduction | | 1,500 |
| Mileage / vehicle (business %) | | 2,400 |
| Entity type | | Sole trader |

**Net profit = Revenue − Deductible expenses.** This is what tax is calculated on (before personal allowances/credits).

---

## Step 2 — The Set-Aside Rule (do this every time you're paid)

The simplest way to never get caught short:

| Your situation | Set aside |
|----------------|-----------|
| Low income / many deductions | **20%** |
| Typical sole trader | **25–30%** |
| Higher earner / no deductions | **35–40%** |
| VAT/GST registered | **+ your VAT/GST rate** on top |

**Worked example — you invoice $5,400:**

```
Invoice total:              $5,400.00
Set-aside rate:             × 30%
─────────────────────────────────────
Move to tax savings:        $1,620.00
Available for you:          $3,780.00
```

> **Habit:** The moment a client pays, transfer the set-aside amount to a separate "Tax" savings account. Treat it as money you never had.

---

## Step 3 — Calculate Your Tax

### 🇺🇸 United States

**Federal income tax brackets (single filer, 2026 — illustrative):**

| Taxable income | Rate |
|----------------|------|
| $0 – $11,600 | 10% |
| $11,601 – $47,150 | 12% |
| $47,151 – $100,525 | 22% |
| $100,526 – $191,950 | 24% |
| $191,951 – $243,725 | 32% |
| $243,726 – $609,350 | 35% |
| $609,351+ | 37% |

**Self-employment tax:** 15.3% on net earnings (12.4% Social Security up to the wage base, 2.9% Medicare), with **half deductible** against income tax.

**Worked example — net profit $92,000 (single):**

```
Self-employment tax base:  92,000 × 92.35% = 84,962
SE tax:                    84,962 × 15.3%  = 13,000
Deductible half of SE tax: 13,000 ÷ 2      =  6,500

Adjusted taxable income:   92,000 − 6,500 − 14,600 (std deduction) = 70,900

Federal income tax:
  10% on first 11,600        = 1,160
  12% on 11,601–47,150       = 4,266
  22% on 47,151–70,900       = 5,225
  ─────────────────────────────────
  Federal income tax         = 10,651

TOTAL FEDERAL TAX = 13,000 (SE) + 10,651 (income) = $23,651
Effective rate on $92,000 profit = 25.7%
```

**Quarterly estimated taxes** are due: Apr 15, Jun 15, Sep 15, Jan 15. Use Form 1040-ES.

**Deductions to remember:** QBI deduction (up to 20% of qualified business income), self-employed health insurance, SEP-IRA/Solo 401(k) contributions, home office, mileage (2026 standard rate ~67¢/mile).

---

### 🇬🇧 United Kingdom

**Income tax bands (2026/27 — illustrative):**

| Band | Taxable income | Rate |
|------|----------------|------|
| Personal allowance | £0 – £12,570 | 0% |
| Basic rate | £12,571 – £50,270 | 20% |
| Higher rate | £50,271 – £125,140 | 40% |
| Additional rate | £125,141+ | 45% |

**National Insurance (Class 4, self-employed):**
- ~6% on profits between the Lower Profits Limit (£12,570) and Upper Profits Limit (£50,270)
- ~2% on profits above £50,270
- Class 2 NI is now effectively voluntary/credited

**Worked example — net profit £92,000:**

```
Income tax:
  Personal allowance       £12,570 @ 0%   = 0
  Basic rate               £37,700 @ 20%  = 7,540
  Higher rate (£92,000−50,270) £41,730 @ 40% = 16,692
  ─────────────────────────────────────────────
  Income tax                              = 24,232

Class 4 NI:
  (£50,270 − £12,570) = £37,700 @ 6%      = 2,262
  (£92,000 − £50,270) = £41,730 @ 2%      =   835
  ─────────────────────────────────────────────
  NI                                      = 3,097

TOTAL = £24,232 + £3,097 = £27,329
Effective rate = 29.7%
```

**Payments on account:** HMRC expects two advance payments (31 Jan and 31 Jul) based on prior year. Budget for it.

**Key reliefs:** Trading Allowance (£1,000), Annual Investment Allowance, pension contributions, allowable expenses. **VAT** registration threshold ~£90,000 — register if you exceed it.

---

### 🇨🇦 Canada

**Federal tax brackets (2026 — illustrative):**

| Taxable income | Rate |
|----------------|------|
| $0 – $55,867 | 15% |
| $55,868 – $111,733 | 20.5% |
| $111,734 – $173,205 | 26% |
| $173,206 – $246,752 | 29% |
| $246,753+ | 33% |

**CPP contributions (self-employed):** pay both employee + employer portions (~11.9% on earnings between $3,500 and the YMPE ~$68,500), plus CPP2 on higher earnings.

**Worked example — net profit $92,000 (Ontario, single, illustrative):**

```
CPP (self-employed, both halves):
  ($68,500 − $3,500) × 11.9%  = 7,735
  CPP2 on ($92,000 − $68,500) × 8% = 1,880

Federal tax (after basic personal amount ~$15,705):
  Roughly 15% on first bracket, 20.5% on next
  ≈ 13,000 (federal, illustrative)

Provincial tax (Ontario, illustrative) ≈ 7,500

TOTAL ≈ 7,735 + 1,880 + 13,000 + 7,500 = $30,115
Effective rate ≈ 32.7%
```

**Installments:** CRA requires quarterly installments once net owing exceeds $3,000.

**Deductions:** RRSP contributions, home office, vehicle, phone/internet, professional fees, CCA (capital cost allowance).

---

### 🇦🇺 Australia

**Income tax rates (resident, 2026 — illustrative):**

| Taxable income | Rate |
|----------------|------|
| $0 – $18,200 | 0% |
| $18,201 – $45,000 | 16% |
| $45,001 – $135,000 | 30% |
| $135,001 – $190,000 | 37% |
| $190,001+ | 45% |

Plus **Medicare Levy** 2%.

**Worked example — net profit $92,000:**

```
Tax:
  0% on first 18,200            = 0
  16% on 18,201–45,000 (26,800) = 4,288
  30% on 45,001–92,000 (47,000) = 14,100
  ─────────────────────────────────
  Income tax                    = 18,388
  Medicare Levy (2% × 92,000)   =  1,840
  ─────────────────────────────────
  TOTAL                         = 20,228
Effective rate = 22.0%
```

**PAYG instalments:** ATO issues quarterly instalments once you're in the system.

**Deductions:** Instant asset write-off, super contributions, home office (fixed rate 67¢/hour), vehicle (cents-per-km or logbook), tools & equipment.

---

## Step 4 — Quarterly Tax Schedule

Plan cash flow around these dates. Mark them in your calendar.

| Quarter | 🇺🇸 US | 🇬🇧 UK | 🇨🇦 Canada | 🇦🇺 Australia |
|---------|-------|-------|-----------|---------------|
| Q1 | Apr 15 | Jan 31 (bal + 1st POA) | Mar 15 | Oct 28 |
| Q2 | Jun 15 | Jul 31 (2nd POA) | Jun 15 | Feb 28 |
| Q3 | Sep 15 | — | Sep 15 | Apr 28 |
| Q4 | Jan 15 | — | Dec 15 | Jul 28 |

> **Tip:** Even if you're not required to pay quarterly, *save* quarterly. The habit is what matters.

---

## Step 5 — Deduction Checklist

Tick what applies to you. Every tick reduces taxable profit.

**Home & workspace**
- [ ] Home office (simplified or actual method)
- [ ] Internet & phone (business %)
- [ ] Rent/mortgage interest (business %)
- [ ] Utilities (business %)

**Vehicle & travel**
- [ ] Mileage / logbook
- [ ] Fuel, insurance, maintenance (business %)
- [ ] Parking & tolls
- [ ] Business travel (flights, hotels, meals)

**Business operations**
- [ ] Software & subscriptions
- [ ] Equipment & tools
- [ ] Professional fees (accountant, lawyer)
- [ ] Bank & payment processing fees
- [ ] Marketing & advertising
- [ ] Education & training
- [ ] Insurance (business, liability)

**People & retirement**
- [ ] Contractor payments
- [ ] Retirement contributions (SEP, Solo 401k, SIPP, RRSP, Super)
- [ ] Self-employed health insurance
- [ ] Wages (if you have employees)

**Money**
- [ ] Business loan interest
- [ ] Bad debts (written off)
- [ ] Tax preparation fees

---

## Step 6 — Set-Aside Tracker

Log every set-aside so you always know your tax pot balance.

| Date | Income received | Set-aside % | Amount moved | Tax pot balance |
|------|-----------------|-------------|--------------|-----------------|
| 2026-09-02 | 5,400.00 | 30% | 1,620.00 | 1,620.00 |
| 2026-09-06 | 3,360.00 | 30% | 1,008.00 | 2,628.00 |
| 2026-09-20 | 7,440.00 | 30% | 2,232.00 | 4,860.00 |
| 2026-10-01 | 2,340.00 | 30% | 702.00 | 5,562.00 |
| 2026-10-10 | 3,960.00 | 30% | 1,188.00 | 6,750.00 |

**Projected annual tax (from Step 3):** $23,651
**Set aside so far:** $6,750
**Remaining to save:** $16,901
**Months left in tax year:** 3 → **$5,634/month needed**

---

## Year-End Checklist

- [ ] Reconcile all income to bank statements
- [ ] Confirm all expenses categorised (see `expense-categoriser.md`)
- [ ] Total retirement contributions
- [ ] Calculate final net profit
- [ ] Run the tax calculation for your country
- [ ] Compare against set-aside pot — top up if short
- [ ] File return / submit to accountant
- [ ] Pay balance due before deadline
- [ ] Set next year's set-aside rate

---

## Quick Reference — Effective Rates

For a sole trader with ~25% expenses, these are rough all-in effective rates (income tax + self-employment/Medicare):

| Net profit | 🇺🇸 US | 🇬🇧 UK | 🇨🇦 CA | 🇦🇺 AU |
|-----------|-------|-------|-------|-------|
| $30,000 | ~15% | ~12% | ~17% | ~10% |
| $60,000 | ~22% | ~22% | ~25% | ~18% |
| $92,000 | ~26% | ~30% | ~33% | ~22% |
| $150,000 | ~31% | ~38% | ~40% | ~30% |
| $250,000 | ~36% | ~44% | ~46% | ~38% |

> Use these to sanity-check your set-aside rate. If your estimate is far off, revisit your deductions.

---

*Feed your net profit into `profit-dashboard.md` and keep invoices current in `invoice-tracker.md`.*
