# 📊 Profit Dashboard

Your one-page command centre. Revenue, costs, margins, runway, and KPIs — updated monthly so you always know whether the business is actually working.

---

## How to Use This File

1. **Once a month**, pull your revenue (from `invoice-tracker.md`) and costs (from `expense-categoriser.md`).
2. Fill in the **Monthly P&L** table.
3. Update the **KPI Snapshot** and **Runway** sections.
4. Read the **Health Check** to know what to fix.

> **20-minute rule:** If updating this takes longer, you're tracking too much. Cut a row.

---

## Monthly P&L (Profit & Loss)

| Line | Jan | Feb | Mar | Apr | May | Jun | Jul | Aug | Sep | Oct |
|------|-----|-----|-----|-----|-----|-----|-----|-----|-----|-----|
| **Revenue** | 14,200 | 16,800 | 18,500 | 17,200 | 19,400 | 21,000 | 18,400 | 21,750 | 22,890 | 13,250 |
| Cost of Goods Sold (COGS) | 2,100 | 2,400 | 2,600 | 2,500 | 2,900 | 3,100 | 2,700 | 3,200 | 3,400 | 1,900 |
| **Gross Profit** | 12,100 | 14,400 | 15,900 | 14,700 | 16,500 | 17,900 | 15,700 | 18,550 | 19,490 | 11,350 |
| Software & subscriptions | 480 | 480 | 520 | 520 | 610 | 610 | 640 | 640 | 720 | 720 |
| Marketing | 600 | 900 | 1,200 | 800 | 1,100 | 1,400 | 900 | 1,600 | 1,800 | 700 |
| Contractors | 2,000 | 2,500 | 3,000 | 2,800 | 3,200 | 3,500 | 2,900 | 3,800 | 4,000 | 2,200 |
| Office & admin | 350 | 350 | 350 | 400 | 400 | 400 | 420 | 420 | 450 | 450 |
| Travel & meals | 200 | 150 | 400 | 250 | 300 | 500 | 180 | 600 | 700 | 250 |
| Insurance & fees | 220 | 220 | 220 | 220 | 220 | 220 | 240 | 240 | 240 | 240 |
| **Total Operating Costs** | 3,850 | 4,600 | 5,690 | 4,990 | 5,830 | 6,630 | 5,280 | 7,300 | 7,910 | 4,560 |
| **Net Profit (pre-tax)** | 8,250 | 9,800 | 10,210 | 9,710 | 10,670 | 11,270 | 10,420 | 11,250 | 11,580 | 6,790 |

---

## Margin Analysis

| Metric | Formula | Jan | Jun | Sep | Target |
|--------|---------|-----|-----|-----|--------|
| **Gross margin** | Gross Profit ÷ Revenue | 85.2% | 85.2% | 85.1% | > 80% |
| **Net margin** | Net Profit ÷ Revenue | 58.1% | 53.7% | 50.6% | > 40% |
| **Operating cost ratio** | Op Costs ÷ Revenue | 27.1% | 31.6% | 34.6% | < 35% |
| **Owner's pay** | Drawings ÷ Net Profit | — | — | — | 30–50% |

> **Reading it:** Gross margin is steady (~85%), but net margin is *slipping* because operating costs are creeping up (27% → 35%). Marketing and contractors are the culprits — review before they eat the profit.

---

## Quarterly Rollup

| Quarter | Revenue | COGS | Gross Profit | Op Costs | Net Profit | Net Margin |
|---------|---------|------|--------------|----------|------------|------------|
| Q1 | 49,500 | 7,100 | 42,400 | 14,140 | 28,260 | 57.1% |
| Q2 | 57,600 | 8,500 | 49,100 | 17,450 | 31,650 | 54.9% |
| Q3 | 63,040 | 9,300 | 53,740 | 20,490 | 33,250 | 52.7% |
| Q4 (MTD) | 13,250 | 1,900 | 11,350 | 4,560 | 6,790 | 51.2% |
| **YTD** | **183,390** | **26,800** | **156,590** | **56,640** | **99,950** | **54.5%** |

---

## KPI Snapshot

| KPI | This Month | Last Month | Trend | Healthy |
|-----|-----------|-----------|-------|---------|
| Revenue | 13,250 | 22,890 | ▼ | — |
| Net profit | 6,790 | 11,580 | ▼ | — |
| Net margin | 51.2% | 50.6% | ▲ | > 40% |
| Avg invoice value | 3,312 | 3,815 | ▼ | Rising |
| New clients | 1 | 3 | ▼ | ≥ 2 |
| Repeat client % | 72% | 68% | ▲ | > 60% |
| Days Sales Outstanding | 24 | 21 | ▲ | < 30 |
| Monthly recurring revenue | 4,200 | 4,200 | ▬ | Growing |
| Cash on hand | 41,500 | 38,900 | ▲ | > 3 mo |
| Billable utilisation | 62% | 68% | ▼ | 60–75% |

> **Note:** October is a partial month (MTD) — the revenue dip is expected, not a crisis. Watch the *trend* over 3 months, not one data point.

---

## Runway Calculator

How many months can you survive on current cash if revenue stopped tomorrow?

```
Runway (months) = Cash on hand ÷ Average monthly expenses

Example:
  Cash on hand              = $41,500
  Avg monthly expenses      = $5,900
  Runway = 41,500 ÷ 5,900   = 7.0 months
```

| Runway | Status | Action |
|--------|--------|--------|
| < 1 month | 🔴 Critical | Cut costs, chase receivables, get deposits |
| 1–3 months | 🟠 Tight | Build buffer, raise prices, find recurring revenue |
| 3–6 months | 🟡 OK | Maintain, aim for 6 |
| 6–12 months | 🟢 Strong | Invest in growth |
| 12+ months | 🔵 Excellent | Consider hiring or scaling |

**Current runway: 7.0 months 🟢**

---

## Cash Flow View

Profit ≠ cash. Track the timing gap.

| Month | Cash In | Cash Out | Net Cash | Closing Balance |
|-------|---------|----------|----------|-----------------|
| Jul | 18,400 | 11,300 | 7,100 | 33,200 |
| Aug | 20,310 | 12,900 | 7,410 | 40,610 |
| Sep | 8,760 | 13,180 | −4,420 | 36,190 |
| Oct (MTD) | 12,000 | 6,690 | 5,310 | 41,500 |

> **Sep warning:** Profit was $11,580 but cash *fell* by $4,420 — because $14,130 of invoices were still unpaid. This is why the `invoice-tracker.md` aging report matters.

---

## Revenue Mix

Know where your money actually comes from.

| Source | Monthly | % of Revenue | Margin | Notes |
|--------|---------|--------------|--------|-------|
| Retainer clients | 8,000 | 60% | 55% | Predictable |
| Project work | 3,500 | 26% | 50% | Lumpy |
| Digital products | 1,250 | 9% | 85% | High margin, scalable |
| Affiliate/sponsorship | 500 | 4% | 95% | Passive |
| **Total** | **13,250** | **100%** | — | |

> **Goal:** Shift 10% more revenue toward products/passive income — highest margin, no client dependency.

---

## Health Check (read this monthly)

Score yourself 0–2 on each. Max 20.

| Check | Question | Score |
|-------|----------|-------|
| Profitability | Is net margin > 40%? | 2 |
| Growth | Is revenue up vs 3 months ago? | 1 |
| Cash | Is runway > 3 months? | 2 |
| Receivables | Is DSO < 30 days? | 2 |
| Diversification | Is no single client > 40% of revenue? | 1 |
| Recurring | Is MRR growing? | 1 |
| Costs | Is op-cost ratio < 35%? | 1 |
| Pricing | Have you raised prices in 12 months? | 0 |
| Tax | Is the tax pot on track? | 2 |
| Buffer | Do you have 3+ months expenses saved? | 2 |
| **Total** | | **14 / 20** |

**Interpretation:**
- **17–20:** Thriving — invest and scale
- **13–16:** Healthy — fix the weak spots
- **9–12:** Warning — tighten costs, chase cash
- **0–8:** Danger — restructure now

**Your weak spots:** pricing (haven't raised), client concentration, MRR growth. Fix pricing first — it's the fastest lever.

---

## Monthly Review Questions

Answer these in 5 minutes each month:

1. What was my **net profit** and did it beat last month?
2. Which **client or product** drove most of it?
3. What **cost** grew fastest, and is it worth it?
4. Am I **on track** for my annual profit goal?
5. What's my **runway** if things go wrong?
6. What **one change** would most improve next month's margin?

---

## Annual Goal Tracker

| Goal | Target | YTD | % Complete | On Track? |
|------|--------|-----|-----------|-----------|
| Revenue | 240,000 | 183,390 | 76% | ✅ |
| Net profit | 120,000 | 99,950 | 83% | ✅ |
| Net margin | 45% | 54.5% | — | ✅ |
| Recurring revenue | 6,000/mo | 4,200/mo | 70% | ⚠️ |
| Cash buffer | 6 months | 7.0 | 117% | ✅ |
| Tax set-aside | 30% | 30% | 100% | ✅ |

---

*Revenue comes from `invoice-tracker.md`; costs come from `expense-categoriser.md`; tax from `tax-calculator.md`.*
