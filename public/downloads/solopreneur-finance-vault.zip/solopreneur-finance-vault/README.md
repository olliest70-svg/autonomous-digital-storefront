# 💰 Solopreneur Finance Vault

**The complete money-management system for one-person businesses.**

Bookkeeping, invoicing, tax planning, and profit tracking — without an accountant on retainer and without a $50/month SaaS subscription. Everything in this vault is plain Markdown or a lightweight spreadsheet you can copy in 60 seconds.

---

## What's Inside

| File | What it does | Best for |
|------|--------------|----------|
| `README.md` | This file — setup, workflow, and how the pieces fit together | Start here |
| `invoice-tracker.md` | Track every invoice from draft → sent → paid → overdue | Getting paid on time |
| `tax-calculator.md` | Estimate income tax, self-employment tax, and set-asides | Never getting blindsided at year-end |
| `profit-dashboard.md` | Monthly P&L view with margins, runway, and KPIs | Knowing if you're actually profitable |
| `expense-categoriser.md` | A rule-based system to sort every expense correctly | Clean books + bigger deductions |

---

## Who This Is For

- **Freelancers & consultants** billing clients by the hour, day, or project
- **Solo creators** earning from courses, memberships, sponsorships, and ad revenue
- **Indie makers & SaaS founders** with recurring subscriptions and app-store payouts
- **Tradespeople & service pros** running a one-person operation
- Anyone doing **$20k–$500k/year** who wants real numbers without hiring a bookkeeper yet

---

## The 15-Minute Setup

1. **Pick your home.** Copy this whole folder into Notion, Obsidian, Google Drive, or a local Git repo. Markdown works everywhere.
2. **Set your fiscal basics** in `tax-calculator.md` → *Country Profile* section (your country, entity type, tax year).
3. **Import last 3 months of transactions** into `expense-categoriser.md` and run the rules once.
4. **List every open invoice** in `invoice-tracker.md`.
5. **Fill one month** of `profit-dashboard.md` so you have a baseline.

That's it. From month two onward, the weekly routine below takes ~20 minutes.

---

## The Weekly Money Routine (20 minutes)

| Day | Task | File |
|-----|------|------|
| **Monday** | Log new invoices, chase anything past due | `invoice-tracker.md` |
| **Wednesday** | Categorise the week's expenses | `expense-categoriser.md` |
| **Friday** | Update revenue + costs, check the dashboard | `profit-dashboard.md` |
| **Month-end** | Reconcile, set aside tax, review KPIs | All files |

> **Rule of thumb:** If it takes longer than 20 minutes a week, you're over-engineering. The vault is designed to be *good enough and consistent*, not perfect.

---

## The Money Map (how the files connect)

```
        ┌─────────────────┐
        │  INVOICES       │  money coming in
        │ invoice-tracker │
        └────────┬────────┘
                 │ revenue
                 ▼
        ┌─────────────────┐        ┌──────────────────┐
        │ PROFIT DASHBOARD│◄───────│ EXPENSE          │
        │ revenue - costs │  costs │ CATEGORISER      │
        └────────┬────────┘        └──────────────────┘
                 │ taxable profit
                 ▼
        ┌─────────────────┐
        │ TAX CALCULATOR  │  what to set aside
        └─────────────────┘
```

Every number flows one direction: **invoices → dashboard → tax**. Keep that chain clean and you'll never wonder "where did the money go?"

---

## Core Principles

1. **Separate accounts, always.** One business checking account, one business card. Never mix personal and business. This alone prevents 80% of bookkeeping pain.
2. **Set aside tax the moment money lands.** Move 25–35% to a separate savings account immediately (see `tax-calculator.md`).
3. **Invoice fast, follow up faster.** The longer an invoice ages, the less likely it gets paid. Chase at day 7, 14, and 30.
4. **Categorise as you go.** A 5-minute weekly sort beats a 5-hour year-end panic.
5. **Track profit, not revenue.** Revenue is vanity; profit is sanity; cash is reality.

---

## Key Metrics to Watch

| Metric | Healthy range | Where to find it |
|--------|---------------|------------------|
| **Gross margin** | 60–90% (services), 40–70% (products) | `profit-dashboard.md` |
| **Net margin** | 20–40% | `profit-dashboard.md` |
| **Days Sales Outstanding (DSO)** | < 30 days | `invoice-tracker.md` |
| **Tax set-aside ratio** | 25–35% of net | `tax-calculator.md` |
| **Runway** | 3–6 months of expenses | `profit-dashboard.md` |
| **Owner's pay ratio** | 30–50% of net profit | `profit-dashboard.md` |

---

## Common Mistakes This Vault Prevents

- ❌ Spending money that's actually owed in tax → ✅ Set-aside rule in `tax-calculator.md`
- ❌ Not knowing which clients pay late → ✅ Aging report in `invoice-tracker.md`
- ❌ Missing deductions because expenses were uncategorised → ✅ Rule engine in `expense-categoriser.md`
- ❌ Confusing revenue with profit → ✅ Margin tracking in `profit-dashboard.md`
- ❌ No idea if the business can survive a slow quarter → ✅ Runway calc in `profit-dashboard.md`

---

## Frequently Asked Questions

**Do I need accounting software?**
No. This vault replaces the *thinking* layer. If you later add software (Wave, Xero, QuickBooks), keep using the dashboard for the high-level view — it's faster to read than any app.

**Is this tax advice?**
No. It's a planning framework with realistic rates. Always confirm your specific numbers with a qualified accountant in your jurisdiction.

**Which currency?**
Any. The templates use a neutral `$` symbol — swap it for your local currency. Country-specific tax sections cover the US, UK, Canada, and Australia.

**Can I use this in Notion?**
Yes — paste the Markdown tables into Notion and they convert to databases automatically.

---

## Quick-Start Checklist

- [ ] Copied the folder somewhere I'll actually open it
- [ ] Set my country profile in `tax-calculator.md`
- [ ] Opened a separate tax savings account
- [ ] Listed all outstanding invoices
- [ ] Categorised last month's expenses
- [ ] Filled in one month of the dashboard
- [ ] Diarised the weekly 20-minute routine

---

*Version 1.0 · Built for one-person businesses that want clarity over complexity.*
