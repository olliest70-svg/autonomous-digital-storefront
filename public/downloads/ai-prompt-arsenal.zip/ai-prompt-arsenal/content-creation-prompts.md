# ✍️ Content Creation Prompts — 80+ Prompts

> **Part of the AI Prompt Arsenal.** Blog posts, newsletters, scripts, courses, books, and repurposing — engineered for creators who publish consistently.

**How to read this file:** Each prompt shows the **Role**, the **Prompt** (with `{{variables}}`), and where useful a **Before / After** or **Example Output**. Copy, fill the variables, and go.

---

## Table of Contents

1. [Blog & Article Writing (1–15)](#1-blog--article-writing)
2. [Newsletter & Email Content (16–28)](#2-newsletter--email-content)
3. [Video & Podcast Scripts (29–40)](#3-video--podcast-scripts)
4. [Course & Educational Content (41–50)](#4-course--educational-content)
5. [Book & Long-Form Writing (51–58)](#5-book--long-form-writing)
6. [Content Repurposing (59–68)](#6-content-repurposing)
7. [Editing & Refinement (69–80)](#7-editing--refinement)
8. [Prompt Engineering Cheatsheet](#-prompt-engineering-cheatsheet)

---

## 1. Blog & Article Writing

### 1. The Definitive Blog Post Outline
**Role:** Senior content strategist
```
You are a senior content strategist who has written for {{publication_type, e.g. "a B2B SaaS blog"}}.
Create a detailed outline for a blog post titled "{{working_title}}".
Target reader: {{audience}}.
Primary goal: {{goal, e.g. "rank for 'project management for freelancers' and drive trial signups"}}.
Include: an H1, 6–9 H2 sections with 2–3 bullet points each, suggested data points or examples per section, and a conclusion with a CTA.
Output as a nested Markdown outline.
```

### 2. Full Blog Post Draft
```
You are an expert writer for {{niche}}. Write a {{word_count}}-word blog post on "{{topic}}".
Audience: {{audience}}. Tone: {{tone}}. Reading level: {{grade_level}}.
Structure: hook intro → 5–7 sections with subheads → actionable takeaways → conclusion.
Include at least {{n}} concrete examples and {{n}} statistics (flag any you are unsure of).
End with a CTA to {{cta}}.
```

### 3. The Contrarian Take Post
```
Write a {{word_count}}-word opinion piece arguing that {{contrarian_claim}}.
Open with the strongest common belief you are challenging, then dismantle it with {{n}} arguments backed by evidence or logic.
Anticipate and rebut the top 2 counterarguments.
Tone: confident but fair. End with a nuanced conclusion, not a rant.
```

### 4. How-To / Tutorial Post
```
Write a step-by-step tutorial: "How to {{task}} in {{timeframe}}".
Assume the reader is a {{skill_level}} who knows {{prerequisites}}.
For each of the {{n}} steps include: what to do, why it matters, a common mistake, and a pro tip.
Use numbered steps, code/command blocks where relevant, and a "Troubleshooting" section at the end.
```

### 5. Listicle Post
```
Write a listicle: "{{number}} {{adjective}} {{things}} for {{audience}}".
For each item give: a punchy subhead, a 2–3 sentence explanation, and one concrete example or action.
Order items by {{criteria, e.g. "impact, easiest first"}}.
Add a short intro that promises the payoff and a conclusion with a next step.
```

### 6. Comparison / "X vs Y" Post
```
Write a balanced comparison of {{option_a}} vs {{option_b}} for {{audience}}.
Include a comparison table (criteria: {{criteria_list}}), a "Choose A if…" and "Choose B if…" section, and a verdict.
Stay neutral unless I specify a recommendation. Cite pricing/features as of the date I provide: {{date}}.
```

### 7. Case Study Post
```
Turn these raw details into a compelling case study: {{raw_details}}.
Structure: Client background → The problem → What we tried → The solution → Results (with numbers) → Key takeaways.
Write in {{third_person/first_person}}. Keep it under {{word_count}} words. Add a pull-quote from the client: "{{quote}}".
```

### 8. Pillar / Ultimate Guide
```
Create a comprehensive pillar page outline (3,000+ words) on "{{broad_topic}}".
Include: a definition section, why it matters, {{n}} subtopics each linking to a future cluster post, FAQs, and a glossary.
Output the outline plus a list of {{n}} supporting cluster article titles that should link back to this pillar.
```

### 9. SEO Blog Brief
```
Write a content brief for a writer covering "{{keyword}}".
Include: search intent, target word count, recommended H2/H3 structure, entities/keywords to include, questions to answer (from People Also Ask), internal links, and a suggested meta title + description.
Format as a brief a freelancer can execute without further questions.
```

### 10. Thought Leadership Article
```
Write a thought-leadership article on "{{topic}}" from the perspective of a {{role}} at a {{company_type}}.
Argue a clear point of view. Support it with 2–3 industry trends and one original framework (name it and explain it).
Avoid buzzwords. Aim for {{word_count}} words. End with a provocative question for the reader.
```

### 11. Roundup / Expert Quotes Post
```
Write a roundup post: "{{number}} experts on {{topic}}".
I will paste {{n}} expert quotes below. For each, write a 2-sentence intro framing the expert and a 1-sentence takeaway.
Add an intro and a synthesis conclusion. Quotes: {{paste_quotes}}
```

### 12. News Reaction Post
```
Write a fast-turnaround reaction post to this news: {{news_summary}}.
Structure: what happened (2 sentences) → why it matters to {{audience}} → 3 implications → what to do next.
Publish-ready, {{word_count}} words, neutral-to-analytical tone. Flag anything that needs verification.
```

### 13. Story-Driven Blog Post
```
Write a {{word_count}}-word narrative blog post about {{topic}}.
Open in-scene (a specific moment, place, or conversation), then zoom out to the lesson.
Use the "story → insight → application" arc. Keep the reader in the story for the first 150 words before making the point.
```

### 14. FAQ / Q&A Post
```
Generate {{n}} frequently asked questions about "{{topic}}" with concise, accurate answers (2–4 sentences each).
Group them into {{n}} themes. Add a short intro and a "Still have questions?" CTA.
Optimize answers to be featured-snippet friendly (direct answer in the first sentence).
```

### 15. Blog Post Conclusion & CTA
```
Write 5 different conclusions for a blog post about "{{topic}}".
Each should: summarize the core takeaway in one line, then lead into a CTA for {{offer}}.
Vary the style: (1) action-oriented, (2) question, (3) bold statement, (4) story callback, (5) future-pacing.
```

---

## 2. Newsletter & Email Content

### 16. Weekly Newsletter Issue
```
You are the writer of a {{niche}} newsletter with {{subscriber_count}} subscribers.
Write this week's issue on "{{topic}}".
Structure: subject line (give 3 options) → personal 2-sentence opener → main insight ({{word_count}} words) → one actionable tip → one curated link with commentary → sign-off.
Voice: {{voice, e.g. "smart friend, not corporate"}}.
```

### 17. Welcome Email (Sequence #1)
```
Write the first email in a welcome sequence for new subscribers who joined via {{lead_magnet}}.
Goal: build trust and set expectations. Deliver the lead magnet, tell them what to expect (frequency, topics), and ask one engagement question.
Subject line + preview text + body. Under 200 words. Warm, human tone.
```

### 18. 5-Email Welcome Sequence
```
Write a 5-email welcome sequence for {{audience}} who signed up for {{lead_magnet}}.
Email 1: deliver + welcome. Email 2: your story/credibility. Email 3: quick win. Email 4: social proof + case study. Email 5: soft pitch for {{offer}}.
For each: subject line, send day, goal, and full body copy.
```

### 19. Re-Engagement Email
```
Write a re-engagement email for subscribers who haven't opened in {{timeframe}}.
Give 3 subject line options (one curiosity, one value, one "should I stop emailing you?").
Body: acknowledge the silence, deliver one high-value insight, and offer a clear choice (stay or unsubscribe).
Keep it under 150 words and non-guilty.
```

### 20. Product Launch Email
```
Write a launch email announcing {{product}}.
Include: subject line (3 options), a hook, the problem it solves, 3 key benefits, social proof, pricing/offer details, and a single CTA button text.
Tone: {{tone}}. Length: {{word_count}}. Add a P.S. line.
```

### 21. Curated Links Newsletter
```
Write a "5 things worth your time" newsletter section.
I'll paste {{n}} links with short descriptions: {{links}}.
For each, write a 1–2 sentence commentary explaining why it matters to {{audience}}. Add a one-line intro and a closing thought.
```

### 22. Story Newsletter
```
Write a newsletter issue built around a personal story about {{experience}}.
Arc: scene → tension → realization → lesson → application for the reader.
Keep the story under 400 words, then connect it to one actionable takeaway. End with a question to drive replies.
```

### 23. Promotional Email (Non-Launch)
```
Write a promotional email for {{offer}} with a {{discount/deadline}}.
Emphasize the transformation, not the features. Include: subject line (3 options), urgency element, 3 benefits, testimonial, CTA, and a P.S. with the deadline.
Avoid hype. Keep it honest and specific.
```

### 24. Abandoned Cart Email
```
Write a 3-email abandoned cart sequence for an e-commerce store selling {{product}}.
Email 1 (1 hour): friendly reminder. Email 2 (24 hours): address objections + social proof. Email 3 (72 hours): incentive or final nudge.
Each: subject line, preview text, body, CTA. Keep it helpful, not pushy.
```

### 25. Newsletter Subject Line Machine
```
Generate 15 subject lines for a newsletter about "{{topic}}".
Mix these styles: curiosity gap, number/list, question, contrarian, personal, and benefit-driven.
Keep each under 50 characters. Mark the 3 you'd A/B test first and explain why.
```

### 26. Referral / Share Email
```
Write an email asking subscribers to refer a friend to {{newsletter/product}}.
Give a genuine reason (not just "help us grow"), explain the reward ({{reward}}), and include a shareable link placeholder.
Subject line + body under 150 words. Friendly and low-pressure.
```

### 27. Survey / Feedback Email
```
Write an email inviting subscribers to complete a {{length}} survey about {{topic}}.
Explain the value of their input, promise how you'll use it, and offer an incentive ({{incentive}}).
Include 3 subject line options and a direct link CTA. Keep it under 120 words.
```

### 28. Newsletter Sign-Off & P.S. Bank
```
Write 10 newsletter sign-offs and 10 P.S. lines for a {{niche}} newsletter.
Sign-offs should feel personal and on-brand. P.S. lines should each drive a different action (reply, share, click, buy, follow).
Label each by intent.
```

---

## 3. Video & Podcast Scripts

### 29. YouTube Video Script (Long-Form)
```
Write a {{duration}}-minute YouTube script on "{{topic}}" for {{audience}}.
Structure: hook (first 15 seconds) → intro/credibility → {{n}} main sections with pattern interrupts → recap → CTA.
Include B-roll suggestions in [brackets] and on-screen text callouts.
Tone: {{tone}}. Keep sentences spoken-friendly (short, conversational).
```

### 30. Short-Form Video Script (60s)
```
Write a 60-second short-form video script (TikTok/Reels/Shorts) about "{{topic}}".
Format: Hook (0–3s) → Context (3–10s) → Value (10–50s) → CTA (50–60s).
Include on-screen text for each beat and a suggested visual. Make the hook a pattern interrupt.
```

### 31. Podcast Episode Outline
```
Create a podcast episode outline on "{{topic}}" for a {{show_type}} show.
Include: episode title (3 options), cold open hook, 3–5 segments with talking points and questions, a story or example per segment, and a closing CTA.
Add 5 "rabbit hole" questions to keep the conversation flowing.
```

### 32. Podcast Interview Questions
```
Generate 15 interview questions for a guest who is a {{guest_role}} in {{industry}}.
Mix: warm-up, origin story, tactical/how-to, contrarian, and forward-looking questions.
Order them from easy to deep. Add a suggested follow-up probe for each.
```

### 33. Video Hook Bank
```
Write 15 hook variations for a video about "{{topic}}".
Include: 5 curiosity hooks, 5 bold-claim hooks, 5 question hooks.
Each under 12 words, spoken naturally. Mark the strongest 3.
```

### 34. Explainer Video Script
```
Write a 90-second explainer video script for {{product/service}}.
Structure: problem → agitation → solution → how it works (3 steps) → proof → CTA.
Include a voiceover column and a visuals column in a two-column table.
Tone: clear, confident, jargon-free.
```

### 35. Webinar Script
```
Write a {{duration}} webinar script on "{{topic}}" that leads to a pitch for {{offer}}.
Structure: intro & promise → credibility → teaching (3 core lessons) → transition → offer → objections → urgency → Q&A.
Mark where to insert polls, slides, and engagement prompts.
```

### 36. VSL (Video Sales Letter) Script
```
Write a VSL script for {{offer}} targeting {{audience}}.
Structure: hook → problem → failed solutions → new mechanism → offer → bonuses → guarantee → price reveal → urgency → CTA.
Write conversationally, as if speaking to one person. Length: {{duration}}.
```

### 37. Course Lesson Video Script
```
Write a lesson script for a course module on "{{lesson_topic}}".
Include: learning objective, a 30-second recap of the previous lesson, the main teaching (with 1 worked example), a practice task, and a preview of the next lesson.
Keep it {{duration}} minutes. Add speaker notes for tone.
```

### 38. Talking-Head Story Script
```
Write a {{duration}} talking-head script where I tell a personal story about {{experience}} and connect it to {{lesson}}.
Use the arc: normal → disruption → struggle → turning point → lesson → application.
Write it the way I'd actually speak. Include [pause] and [emphasis] cues.
```

### 39. Podcast Ad Read
```
Write a {{duration}}-second host-read ad for {{sponsor/product}}.
Match the host's casual voice. Include a personal-sounding endorsement, the key benefit, a specific offer code ({{code}}), and a clear CTA.
Give 2 versions: one story-led, one benefit-led.
```

### 40. Video Series Plan
```
Plan a {{number}}-episode video series on "{{topic}}".
For each episode: title, hook, core takeaway, and how it links to the next.
Ensure the series builds toward {{end_goal}}. Output as a table with columns: #, Title, Hook, Takeaway, CTA.
```

---

## 4. Course & Educational Content

### 41. Course Outline
```
Design a course outline for "{{course_title}}" that takes students from {{starting_point}} to {{end_result}}.
Include: {{n}} modules, each with 3–5 lessons, learning objectives, a practical exercise, and an assessment.
Add prerequisites, total time estimate, and a "who this is for / not for" section.
```

### 42. Lesson Plan
```
Write a lesson plan for a {{duration}} lesson on "{{topic}}".
Include: objective, materials, warm-up, direct instruction, guided practice, independent practice, and a check for understanding.
Format as a table with a Time | Activity | Notes structure.
```

### 43. Quiz & Assessment Questions
```
Write {{n}} assessment questions on "{{topic}}" at {{difficulty}} level.
Include a mix of multiple choice, true/false, and short answer. Provide an answer key with explanations.
Ensure questions test understanding, not just recall.
```

### 44. Course Workbook Exercise
```
Design a fill-in-the-blank workbook exercise for a lesson on "{{topic}}".
Include: instructions, a worked example, the blank template, and reflection prompts.
Make it something a student can complete in {{timeframe}}.
```

### 45. Learning Objectives
```
Write {{n}} measurable learning objectives for a module on "{{topic}}" using Bloom's taxonomy verbs.
Each objective should be specific, assessable, and start with "By the end of this module, learners will be able to…".
```

### 46. Onboarding Curriculum
```
Design a {{duration}} onboarding curriculum for new {{role}} at {{company_type}}.
Break it into days/weeks with: goals, activities, resources, and a success check.
Include a "first 30/60/90 days" summary table.
```

### 47. Microlearning Cards
```
Turn "{{topic}}" into {{n}} microlearning cards.
Each card: a single concept, a 1-sentence explanation, an example, and a 1-question self-check.
Keep each under 80 words. Output as a numbered list.
```

### 48. Workshop Facilitation Guide
```
Write a facilitation guide for a {{duration}} workshop on "{{topic}}" for {{audience}}.
Include: agenda with timings, materials, facilitator scripts for key moments, group activities, and a debrief.
Add contingency notes for "if the group is quiet" and "if you run out of time".
```

### 49. Course Sales Page Copy
```
Write sales page copy for a course on "{{topic}}" priced at {{price}}.
Include: headline, subhead, problem, promise, curriculum overview, instructor bio, testimonials (placeholders), FAQ, guarantee, and CTA.
Emphasize transformation and outcomes over features.
```

### 50. Certification Exam Blueprint
```
Create an exam blueprint for a "{{certification_name}}" certification.
Include: domains, weightings (%), number of questions per domain, question types, and passing score rationale.
Output as a table. Add 5 sample questions with answers.
```

---

## 5. Book & Long-Form Writing

### 51. Non-Fiction Book Outline
```
Create a chapter-by-chapter outline for a non-fiction book titled "{{title}}" about {{topic}}.
For each of {{n}} chapters: working title, core argument, 3 key points, a story/example, and a takeaway.
Add an intro, conclusion, and a "how to read this book" section.
```

### 52. Chapter Draft
```
Write Chapter {{n}} of a book about "{{topic}}". Chapter focus: "{{chapter_focus}}".
Length: {{word_count}} words. Open with a scene or anecdote, deliver the core teaching, and end with a bridge to the next chapter.
Voice: {{voice}}. Avoid academic stiffness.
```

### 53. Memoir Scene
```
Write a {{word_count}}-word memoir scene about {{event}}.
Use sensory detail, present-tense immediacy where it helps, and restraint with emotion (show, don't tell).
Focus on one pivotal moment. End on an image, not a summary.
```

### 54. Book Blurb / Back Cover
```
Write a back-cover blurb for a book about "{{topic}}" for {{audience}}.
Include: a hook line, a 2-sentence setup, the promise, and a one-line author credibility note.
Give 3 versions: dramatic, benefit-driven, and curiosity-led. Each under 150 words.
```

### 55. Book Proposal Overview
```
Write the overview section of a non-fiction book proposal for "{{title}}".
Include: the hook, the target market, why now, the author's platform, competing titles and how this differs, and the book's promise.
Professional, agent-ready tone. {{word_count}} words.
```

### 56. Fiction Story Outline
```
Outline a {{genre}} story with the following premise: {{premise}}.
Include: protagonist (want vs. need), antagonist/obstacle, inciting incident, 3-act structure with turning points, midpoint reversal, climax, and resolution.
Add 3 subplot ideas and a one-line theme.
```

### 57. Character Profile
```
Create a detailed character profile for a {{role}} in a {{genre}} story.
Include: name, age, appearance, backstory, want, need, flaw, secret, speech patterns, and a defining quote.
Then write a 150-word scene that reveals their character through action.
```

### 58. Book Chapter Summaries
```
Write a 100-word summary for each of the {{n}} chapters in a book about "{{topic}}".
Each summary should capture the core argument and one memorable example. Output as a numbered list.
Add a 1-sentence "big idea" for the whole book at the end.
```

---

## 6. Content Repurposing

### 59. Blog → Social Posts
```
Turn this blog post into {{n}} social media posts: {{paste_blog}}.
Create: 3 LinkedIn posts (insight-led), 3 X/Twitter posts (punchy), 2 Instagram captions (visual-friendly), and 2 short-video hooks.
Keep each platform's native style. Don't just copy-paste.
```

### 60. Video → Blog Post
```
Turn this video transcript into a {{word_count}}-word blog post: {{paste_transcript}}.
Remove filler, add subheads, tighten the argument, and add a skimmable intro and conclusion.
Keep the speaker's voice. Add a "key takeaways" box at the top.
```

### 61. Long-Form → Thread
```
Turn this article into a 10-post X/Twitter thread: {{paste_article}}.
Post 1 = hook. Posts 2–9 = one idea each. Post 10 = recap + CTA.
Keep each post under 280 characters. Make the thread readable as a standalone.
```

### 62. Podcast → Newsletter
```
Turn this podcast episode into a newsletter issue: {{paste_transcript}}.
Structure: hook → the big idea → 3 key insights with quotes → one action step → link to the episode.
Write in {{voice}}. Keep it under {{word_count}} words.
```

### 63. Webinar → Lead Magnet
```
Turn this webinar into a downloadable lead magnet: {{paste_transcript}}.
Create a {{format, e.g. "10-page PDF"} outline: title, intro, {{n}} lessons with takeaways, a checklist, and a CTA.
Make it skimmable and standalone (no need to have watched the webinar).
```

### 64. One Piece → 10 Assets
```
Take this single piece of content: {{content}}.
Repurpose it into 10 different assets: blog post, newsletter, 3 social posts, 1 short video script, 1 carousel, 1 thread, 1 infographic outline, and 1 quote graphic.
Output each as a labeled section.
```

### 65. Case Study → Sales Assets
```
Turn this case study into: a 1-page sales sheet, 3 LinkedIn posts, 1 email, and 1 testimonial graphic caption.
Source: {{paste_case_study}}. Keep the numbers and specifics intact. Label each asset.
```

### 66. Evergreen Content Refresh
```
Here is an old post: {{paste_post}}. It's about "{{topic}}" and was written in {{year}}.
Update it: flag outdated claims, suggest new examples/statistics, rewrite the intro, and propose a new title.
Output: a change log + the refreshed draft.
```

### 67. Content Atomization Plan
```
I have one pillar piece on "{{topic}}". Create an atomization plan that produces {{n}} assets over {{timeframe}}.
Map each asset to a channel, a format, and a publish day. Output as a table: Asset | Channel | Format | Publish Day | Source Section.
```

### 68. Repurposing Voice Adapter
```
Rewrite this content for a different platform while keeping the core message: {{content}}.
Original platform: {{platform_a}}. Target platform: {{platform_b}}.
Adjust length, tone, formatting, and CTA to match {{platform_b}} norms. Explain the 3 biggest changes you made.
```

---

## 7. Editing & Refinement

### 69. Line Edit for Clarity
```
Edit the following text for clarity and concision. Cut filler, tighten sentences, and remove redundancy. Preserve my voice.
Return: (1) the edited version, (2) a bullet list of the main changes.
Text: {{paste_text}}
```

### 70. Tone Shift
```
Rewrite the following text in a {{target_tone}} tone, keeping the meaning and facts intact.
Text: {{paste_text}}
After the rewrite, list the specific word/phrase swaps you made (e.g. "utilize → use").
```

### 71. Cut by 30%
```
Cut the following text by 30% without losing the core argument or any key facts.
Text: {{paste_text}}
Show the word count before and after.
```

### 72. Strengthen the Opening
```
Rewrite the opening paragraph of this piece to be more compelling. Give 5 options using different techniques: anecdote, statistic, question, bold claim, and scene-setting.
Piece: {{paste_text}}
```

### 73. Improve Readability
```
Rewrite this text to a {{grade_level}} reading level. Shorten sentences, replace jargon, and use active voice.
Text: {{paste_text}}
Report the Flesch reading ease score before and after (estimate if needed).
```

### 74. Fact-Check Pass
```
Review this text for factual claims that need verification. List each claim, mark it as [verifiable], [opinion], or [needs source], and suggest where to find a source.
Text: {{paste_text}}
Do not rewrite the text — just produce the claim audit.
```

### 75. Consistency Check
```
Check this document for inconsistencies in terminology, capitalization, tone, and formatting.
Document: {{paste_text}}
Output a table: Issue | Location | Suggested Fix.
```

### 76. Add Examples & Specifics
```
The following text is too abstract. Add concrete examples, numbers, or mini-stories to make each key point tangible.
Text: {{paste_text}}
Keep the same structure and length (within 10%).
```

### 77. Headline Generator
```
Generate 15 headlines for a piece about "{{topic}}" aimed at {{audience}}.
Include: 5 benefit-driven, 5 curiosity, 3 how-to, 2 contrarian.
Keep each under 60 characters. Mark the 3 strongest.
```

### 78. SEO Polish Pass
```
Optimize this draft for the keyword "{{keyword}}" without keyword-stuffing.
Draft: {{paste_draft}}
Suggest: title tag, meta description, H1, and where to naturally place the keyword. Report keyword density before and after.
```

### 79. Voice Matching
```
Here are 3 samples of my writing: {{samples}}.
Now rewrite the following content to match my voice exactly: {{content}}.
After the rewrite, describe the 4 voice traits you inferred and how you applied them.
```

### 80. Final Proofread
```
Proofread this text for grammar, spelling, punctuation, and typos. Do not change style or meaning.
Text: {{paste_text}}
Output: (1) the corrected text, (2) a list of every change made.
```

### 81. Reader Empathy Check
```
Read this draft as a skeptical {{audience}} member. Where would I get bored, confused, or unconvinced?
Draft: {{paste_draft}}
Give 5 specific friction points with a suggested fix for each.
```

### 82. Before/After Rewrite Demo
```
Show me a before/after rewrite of this paragraph: {{paragraph}}.
Before: the original. After: a stronger version. Then annotate 4 specific improvements (e.g. "replaced passive with active," "added a concrete number").
```

---

## 🧰 Prompt Engineering Cheatsheet

### The C.R.A.F.T. Framework
| Letter | Meaning | Example |
|--------|---------|---------|
| **C** | Context | "I run a 5,000-subscriber newsletter for freelance designers." |
| **R** | Role | "Act as a senior editor." |
| **A** | Action | "Rewrite this intro." |
| **F** | Format | "Return a table with 3 options." |
| **T** | Tone | "Warm, direct, no jargon." |

### Power Phrases
- **To get reasoning:** "Think step by step before answering."
- **To get options:** "Give me 5 variations, ranked by likely impact."
- **To constrain:** "No more than 150 words. No clichés. No emojis."
- **To improve:** "Now make it 30% more specific and add one example per point."
- **To match voice:** "Match the voice in the sample below: …"

### The Iteration Ladder
1. **Draft** → get something on the page.
2. **Sharpen** → cut, clarify, add specifics.
3. **Voice** → match your brand.
4. **Format** → structure for the platform.
5. **Final** → proofread and fact-check.

### Common Mistakes to Avoid
- ❌ Vague audience ("people") → ✅ "freelance web designers with 1–3 years experience"
- ❌ No format → ✅ "Output as a Markdown table with 4 columns"
- ❌ Accepting v1 → ✅ Always run one refinement pass
- ❌ Assuming facts → ✅ "Flag any statistic you're unsure of"

---

*End of Content Creation Prompts — 82 prompts. Part of the AI Prompt Arsenal.*
