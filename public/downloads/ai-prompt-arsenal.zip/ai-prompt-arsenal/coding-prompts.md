# 💻 Coding & Engineering Prompts — 60+ Prompts

> **Part of the AI Prompt Arsenal.** Code review, debugging, refactoring, testing, documentation, architecture, and DevOps — prompts that make AI a real engineering partner.

**How to read this file:** Each prompt shows the **Role**, the **Prompt** (with `{{variables}}`), and where useful a **Before / After** or **Example Output**. Prompts are language-agnostic unless noted.

---

## Table of Contents

1. [Code Review & Quality (1–12)](#1-code-review--quality)
2. [Debugging & Troubleshooting (13–22)](#2-debugging--troubleshooting)
3. [Refactoring & Optimization (23–32)](#3-refactoring--optimization)
4. [Testing & QA (33–42)](#4-testing--qa)
5. [Documentation & Comments (43–50)](#5-documentation--comments)
6. [Architecture & Design (51–58)](#6-architecture--design)
7. [DevOps, Git & Workflow (59–66)](#7-devops-git--workflow)
8. [Prompt Engineering Cheatsheet](#-prompt-engineering-cheatsheet)

---

## 1. Code Review & Quality

### 1. Senior Code Review
**Role:** Senior software engineer
```
You are a senior {{language}} engineer conducting a code review.
Review the following code for: correctness, readability, performance, security, and edge cases.
For each issue: quote the line, explain the problem, and give a corrected version.
Prioritize issues as [critical], [major], or [nit].
Code:
```{{language}}
{{paste_code}}
```
```

### 2. Security Review
```
Act as an application security engineer. Review this code for vulnerabilities (injection, XSS, auth flaws, secrets, insecure deserialization, etc.).
For each finding: the vulnerability type, the risk, an exploit scenario, and a fix.
Map findings to OWASP Top 10 where applicable.
Code:
```{{language}}
{{paste_code}}
```
```

### 3. Performance Review
```
Analyze this code for performance bottlenecks.
Identify: inefficient algorithms, unnecessary allocations, N+1 queries, blocking calls, and memory leaks.
For each: the impact, a measurement suggestion, and an optimized version.
Code:
```{{language}}
{{paste_code}}
```
```

### 4. Readability & Style Review
```
Review this code for readability and maintainability.
Flag: unclear names, long functions, deep nesting, magic numbers, and inconsistent style.
Suggest concrete improvements and show a refactored snippet.
Code:
```{{language}}
{{paste_code}}
```
```

### 5. Code Review — Before/After
**Before (smelly):**
```python
def p(d):
    r = 0
    for i in range(len(d)):
        if d[i]['s'] == 1:
            r += d[i]['a'] * 1.08
    return r
```

**After (clean):**
```python
TAX_RATE = 1.08

def calculate_total_price(items: list[dict]) -> float:
    """Sum the price of all active items, including tax."""
    return sum(
        item["amount"] * TAX_RATE
        for item in items
        if item["status"] == ACTIVE
    )
```

**Prompt:**
```
Refactor this code for readability: use descriptive names, extract constants, add a docstring, and use idiomatic constructs. Explain each change.
Code: {{paste_code}}
```

### 6. PR Review Comment
```
Write a constructive PR review comment for this change: {{paste_diff}}.
Be specific, kind, and actionable. Distinguish blocking issues from suggestions.
Use the format: [blocking/suggestion/nit] — comment — suggested change.
```

### 7. Legacy Code Assessment
```
Assess this legacy code: {{paste_code}}.
Identify: what it does, hidden dependencies, risks, and technical debt.
Recommend a safe modernization path (strangler pattern, tests first, incremental refactor).
```

### 8. Dependency Audit
```
Review this dependency list: {{dependencies}}.
Flag: outdated packages, security concerns, heavy/unmaintained libraries, and duplicates.
Recommend replacements or upgrades, with a priority order.
```

### 9. API Design Review
```
Review this API design: {{api_spec_or_code}}.
Evaluate: REST/GraphQL conventions, naming, versioning, error handling, pagination, and auth.
Suggest improvements with examples.
```

### 10. Accessibility Review (Frontend)
```
Review this frontend code for accessibility (WCAG 2.2 AA).
Check: semantic HTML, ARIA usage, keyboard navigation, focus management, color contrast, and alt text.
For each issue: the WCAG criterion, the problem, and a fix.
Code:
```{{language}}
{{paste_code}}
```
```

### 11. Code Smell Detector
```
Identify code smells in this code: {{paste_code}}.
For each: the smell name, why it's a problem, and a refactoring technique (from the catalog: extract method, replace conditional with polymorphism, etc.).
```

### 12. Review Checklist Generator
```
Create a code review checklist for a {{language}} {{project_type}} project.
Cover: correctness, tests, security, performance, readability, and documentation.
Format as a checklist a reviewer can run through in under 10 minutes.
```

---

## 2. Debugging & Troubleshooting

### 13. Root-Cause Debugging
**Role:** Debugging specialist
```
You are a debugging specialist. Here is the problem:
- Expected: {{expected_behavior}}
- Actual: {{actual_behavior}}
- Error: {{error_message}}
- Code: {{paste_code}}
- Environment: {{environment}}

Think step by step: list 5 possible causes ranked by likelihood, then tell me how to test each one. Do not guess a fix until the cause is confirmed.
```

### 14. Stack Trace Analysis
```
Analyze this stack trace and explain what's happening in plain English:
{{paste_stack_trace}}
Identify: the failing line, the call chain, the likely root cause, and the fix.
```

### 15. Intermittent Bug Investigation
```
This bug happens intermittently: {{bug_description}}.
Context: {{context}}.
List the most likely causes of non-determinism (race conditions, timing, caching, state, env differences).
Suggest logging/observability to narrow it down.
```

### 16. Error Message Decoder
```
Explain this error message and how to fix it: "{{error_message}}".
Context: {{language/framework/version}}.
Give: the cause, 3 likely fixes ranked by probability, and how to prevent it.
```

### 17. Reproduce & Isolate
```
Help me create a minimal reproduction for this bug: {{bug_description}}.
Code: {{paste_code}}.
Give me a step-by-step plan to isolate the smallest failing case, and write the minimal repro code.
```

### 18. Log Analysis
```
Analyze these logs and identify the root cause: {{paste_logs}}.
Highlight the anomaly, correlate events by timestamp, and suggest the failing component.
```

### 19. Performance Profiling
```
My {{language}} code is slow. Here's the code and profiling data: {{code_and_profile}}.
Identify the bottleneck, explain why, and provide an optimized version with expected improvement.
```

### 20. Memory Leak Hunt
```
This {{language}} application has a memory leak: {{symptoms}}.
Code: {{paste_code}}.
Identify likely leak sources (unclosed resources, event listeners, caches, circular refs) and how to confirm each.
```

### 21. Debugging — Before/After
**Before (vague ask):**
> My code doesn't work, can you fix it? [pastes 400 lines]

**After (effective ask):**
> **Goal:** Parse a CSV and return rows where `status == "active"`.
> **Expected:** 12 rows. **Actual:** `KeyError: 'status'` on row 4.
> **Minimal repro:**
> ```python
> import csv
> rows = list(csv.DictReader(open("data.csv")))
> active = [r for r in rows if r["status"] == "active"]
> ```
> **What I've tried:** printed `rows[3].keys()` → `['Status', 'Amount']` (capital S).
> What's the cleanest fix?

**Prompt:**
```
Rewrite my vague bug report into a precise one: include goal, expected vs actual, a minimal repro, and what I've tried.
Report: {{paste_report}}
```

### 22. Fix Verification
```
I applied this fix: {{fix}} to this bug: {{bug}}.
Review the fix for correctness, side effects, and edge cases. Suggest a test that would prove it works.
```

---

## 3. Refactoring & Optimization

### 23. Refactor to Clean Code
```
Refactor this code following clean code principles: {{paste_code}}.
Improve: naming, function size, single responsibility, and duplication.
Show the refactored code and explain each change. Preserve behavior.
```

### 24. Extract Function / Method
```
This function is too long: {{paste_code}}.
Break it into smaller, well-named functions with single responsibilities.
Show the refactored version and a brief rationale.
```

### 25. Replace Conditionals
```
Refactor this conditional-heavy code: {{paste_code}}.
Replace nested if/else with a cleaner pattern (early returns, strategy pattern, lookup table, or polymorphism).
Explain the tradeoffs.
```

### 26. Optimize Algorithm
```
Optimize the algorithm in this code: {{paste_code}}.
State the current time/space complexity, propose a better approach, and give the optimized code with its complexity.
```

### 27. Modernize Syntax
```
Modernize this code to use current {{language}} idioms ({{version}}): {{paste_code}}.
Use modern features (e.g. f-strings, async/await, optional chaining, pattern matching). Explain each change.
```

### 28. Remove Duplication (DRY)
```
Find and remove duplication in this code: {{paste_code}}.
Extract shared logic into reusable functions/modules. Show before/after and note any behavior differences.
```

### 29. Add Types / Type Safety
```
Add type annotations to this code: {{paste_code}}.
Use {{language}}'s type system fully. Flag any places where types reveal a bug or ambiguity.
```

### 30. Refactor for Testability
```
This code is hard to test: {{paste_code}}.
Refactor it to be testable (dependency injection, pure functions, separation of concerns). Show the refactor and an example test.
```

### 31. Database Query Optimization
```
Optimize this database query: {{query}}.
Schema: {{schema}}.
Identify missing indexes, N+1 issues, and inefficient joins. Provide an optimized query and index recommendations.
```

### 32. Refactor — Before/After
**Before (nested and duplicated):**
```javascript
function getPrice(user) {
  if (user) {
    if (user.type === 'premium') {
      return 10;
    } else {
      if (user.type === 'basic') {
        return 20;
      } else {
        return 30;
      }
    }
  } else {
    return 30;
  }
}
```

**After (clean):**
```javascript
const PRICES = { premium: 10, basic: 20, default: 30 };

function getPrice(user) {
  return PRICES[user?.type] ?? PRICES.default;
}
```

**Prompt:**
```
Refactor this code to reduce nesting and duplication using early returns or a lookup table. Explain the change.
Code: {{paste_code}}
```

---

## 4. Testing & QA

### 33. Unit Test Generator
**Role:** Test engineer
```
You are a test engineer. Write unit tests for this code: {{paste_code}}.
Use {{test_framework}}. Cover: happy path, edge cases, error conditions, and boundary values.
Aim for {{coverage}}% coverage. Include descriptive test names.
```

### 34. Test Case Brainstorm
```
List all test cases for this function/feature: {{code_or_spec}}.
Include: happy path, edge cases, invalid inputs, boundary values, and error handling.
Output as a table: Case | Input | Expected Output | Type.
```

### 35. Integration Test
```
Write an integration test for this flow: {{flow_description}}.
Code/endpoints: {{paste_code}}.
Use {{framework}}. Include setup, teardown, and assertions on the full flow.
```

### 36. E2E Test (Playwright/Cypress)
```
Write an end-to-end test for this user flow: {{flow}}.
Use {{playwright/cypress}}. Include selectors, actions, and assertions. Add a note on flakiness prevention.
```

### 37. Test Data Factory
```
Create a test data factory/builder for {{entity}} with these fields: {{fields}}.
Provide sensible defaults and the ability to override any field. Use {{language}}.
```

### 38. Mock / Stub Generator
```
Write mocks/stubs for these dependencies: {{dependencies}}.
Use {{framework}}. Show how to inject them into the code under test.
```

### 39. Test Coverage Gap Analysis
```
Here is my code and existing tests: {{code_and_tests}}.
Identify untested paths, missing edge cases, and risky gaps. Prioritize by risk.
Output a table: Gap | Risk | Suggested Test.
```

### 40. Flaky Test Fix
```
This test is flaky: {{paste_test}}.
Identify the cause (timing, shared state, order dependence, network) and rewrite it to be deterministic.
```

### 41. Property-Based Test
```
Write property-based tests for this function: {{paste_code}}.
Use {{framework, e.g. Hypothesis/fast-check}}. Identify the invariants to test and generate strategies.
```

### 42. Test — Before/After
**Before (weak test):**
```python
def test_add():
    assert add(1, 2) == 3
```

**After (thorough test):**
```python
import pytest

@pytest.mark.parametrize("a, b, expected", [
    (1, 2, 3),          # happy path
    (-1, 1, 0),         # negatives
    (0, 0, 0),          # zeros
    (1.5, 2.5, 4.0),    # floats
])
def test_add_returns_sum(a, b, expected):
    assert add(a, b) == expected

def test_add_raises_on_none():
    with pytest.raises(TypeError):
        add(None, 1)
```

**Prompt:**
```
Improve this test to cover edge cases, boundaries, and error conditions using parametrization. Explain what each case guards against.
Test: {{paste_test}}
```

---

## 5. Documentation & Comments

### 43. Docstring / JSDoc Generator
**Role:** Technical writer
```
Write complete documentation comments for this code: {{paste_code}}.
Use {{docstring_format, e.g. Google/NumPy/JSDoc}}. Include: description, params, returns, raises, and an example.
```

### 44. README Generator
```
Write a README.md for this project: {{project_description}}.
Include: title, badges, description, features, installation, usage, configuration, examples, contributing, and license.
Make it skimmable with code blocks.
```

### 45. API Documentation
```
Write API documentation for these endpoints: {{endpoints}}.
For each: method, path, description, parameters, request body, response, status codes, and an example.
Format as Markdown.
```

### 46. Inline Comment Pass
```
Add clarifying inline comments to this code: {{paste_code}}.
Explain the "why," not the "what." Remove any obvious comments. Keep it concise.
```

### 47. Changelog Entry
```
Write a changelog entry for these changes: {{changes}}.
Follow Keep a Changelog format (Added/Changed/Fixed/Removed). Write for users, not developers.
```

### 48. Architecture Decision Record (ADR)
```
Write an ADR for this decision: {{decision}}.
Include: title, status, context, decision, consequences (positive and negative), and alternatives considered.
```

### 49. Onboarding Doc for Developers
```
Write a developer onboarding doc for this codebase: {{codebase_summary}}.
Include: setup steps, project structure, key concepts, common tasks, and troubleshooting.
```

### 50. Documentation — Before/After
**Before (useless comment):**
```python
# increment i by 1
i += 1
```

**After (useful comment):**
```python
# Skip the header row so the first data record is parsed correctly.
i += 1
```

**Prompt:**
```
Rewrite these comments to explain "why" instead of "what." Remove comments that just restate the code.
Code: {{paste_code}}
```

---

## 6. Architecture & Design

### 51. System Design Review
**Role:** Software architect
```
You are a software architect. Review this system design: {{design_description}}.
Evaluate: scalability, reliability, security, cost, and maintainability.
Identify bottlenecks and single points of failure. Suggest improvements with tradeoffs.
```

### 52. Design a Feature
```
Design the architecture for this feature: {{feature}}.
Context: {{constraints, e.g. "must handle 10k req/s, existing stack is Node + Postgres"}}.
Provide: components, data flow, data model, API surface, and key tradeoffs. Include a diagram in text/mermaid.
```

### 53. Database Schema Design
```
Design a database schema for {{application}}.
Requirements: {{requirements}}.
Provide: tables, columns, types, relationships, indexes, and constraints. Output as SQL DDL plus an explanation.
```

### 54. API Design
```
Design a REST API for {{resource}}.
Include: endpoints, methods, request/response schemas, status codes, pagination, filtering, and auth.
Output as an OpenAPI-style spec plus examples.
```

### 55. Microservices vs Monolith
```
I'm building {{project}}. Should I use a monolith or microservices?
Context: {{team_size, scale, timeline}}.
Give a recommendation with reasoning, tradeoffs, and a migration path if needed.
```

### 56. Caching Strategy
```
Design a caching strategy for {{system}}.
Consider: cache layers (client, CDN, app, DB), invalidation, TTLs, and consistency.
Output a table: Layer | What to Cache | TTL | Invalidation Strategy.
```

### 57. Scalability Plan
```
My application needs to scale from {{current}} to {{target}}.
Current architecture: {{architecture}}.
Identify bottlenecks and provide a phased scaling plan (vertical, horizontal, sharding, async).
```

### 58. Technology Selection
```
Help me choose between {{option_a}} and {{option_b}} for {{use_case}}.
Compare on: performance, ecosystem, learning curve, cost, and community.
Give a recommendation for {{team_context}} with reasoning.
```

---

## 7. DevOps, Git & Workflow

### 59. Dockerfile
**Role:** DevOps engineer
```
Write an optimized Dockerfile for a {{language/framework}} app.
Requirements: {{requirements, e.g. "multi-stage build, small image, non-root user"}}.
Include comments explaining each stage and a .dockerignore suggestion.
```

### 60. CI/CD Pipeline
```
Write a {{github_actions/gitlab_ci}} pipeline for a {{language}} project.
Stages: lint, test, build, and deploy to {{environment}}.
Include caching, secrets handling, and a note on rollback.
```

### 61. Git Commit Message
```
Write a conventional commit message for these changes: {{paste_diff}}.
Format: type(scope): subject, then a body explaining what and why. Add a footer for breaking changes if needed.
```

### 62. Git Troubleshooting
```
I'm stuck in Git: {{problem, e.g. "I committed to main by mistake"}}.
Give me the exact commands to fix it safely, explain what each does, and warn about any destructive steps.
```

### 63. Infrastructure as Code
```
Write {{terraform/cloudformation}} for {{infrastructure}}.
Include: resources, variables, outputs, and comments. Follow best practices for state and security.
```

### 64. Monitoring & Alerting
```
Design monitoring and alerting for {{service}}.
Include: key metrics (latency, error rate, saturation, traffic), alert thresholds, and dashboards.
Output a table: Metric | Threshold | Alert | Action.
```

### 65. Incident Postmortem
```
Write a blameless postmortem for this incident: {{incident_summary}}.
Include: timeline, impact, root cause, detection, response, and action items with owners.
```

### 66. Codebase Onboarding Plan
```
Create a plan for a new developer to get productive in this codebase within {{timeframe}}.
Codebase: {{summary}}.
Include: day-by-day tasks, key files to read, a first "good first issue," and checkpoints.
```

---

## 🧰 Prompt Engineering Cheatsheet

### The Code Prompt R.O.C.K. Framework
| Letter | Meaning | Example |
|--------|---------|---------|
| **R** | Role | "You are a senior Go engineer." |
| **O** | Objective | "Find the race condition in this handler." |
| **C** | Context | "Go 1.22, Postgres 16, 5k req/s." |
| **K** | Known constraints | "Don't change the public API." |

### Power Phrases for Coding Prompts
- **To get reasoning:** "Think step by step before proposing a fix."
- **To avoid hallucinated APIs:** "Only use methods that exist in {{library}} {{version}}. Flag anything uncertain."
- **To preserve behavior:** "Refactor without changing behavior; note any behavior change explicitly."
- **To get tests:** "Write tests that would fail on the original code."
- **To get diffs:** "Show only the changed lines as a unified diff."

### The Debugging Ladder
1. **Reproduce** — get a minimal failing case.
2. **Isolate** — narrow to the smallest component.
3. **Hypothesize** — list causes ranked by likelihood.
4. **Test** — confirm the cause before fixing.
5. **Fix & verify** — write a test that proves it.

### Code Review Priorities
1. **Correctness** — does it do what it claims?
2. **Security** — can it be exploited?
3. **Performance** — will it scale?
4. **Readability** — can the next dev understand it?
5. **Tests** — is it protected against regression?

### Common Mistakes to Avoid
- ❌ Pasting 500 lines with "fix this" → ✅ Paste the minimal repro + expected vs actual
- ❌ Trusting AI-generated code blindly → ✅ Review, test, and verify
- ❌ No version/context → ✅ Always state language, framework, and versions
- ❌ Accepting the first fix → ✅ Ask "what else could cause this?"

---

*End of Coding & Engineering Prompts — 66 prompts. Part of the AI Prompt Arsenal.*
