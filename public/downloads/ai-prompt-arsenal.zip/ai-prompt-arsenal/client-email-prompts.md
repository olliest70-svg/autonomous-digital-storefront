# 📧 Client & Sales Email Prompts — 60+ Prompts

> **Part of the AI Prompt Arsenal.** Every email a freelancer, agency, or consultant needs — from cold outreach to difficult conversations — with variables, examples, and before/after rewrites.

**How to read this file:** Each prompt shows the **Role**, the **Prompt** (with `{{variables}}`), and where useful a **Before / After** or **Example Output**.

---

## Table of Contents

1. [Cold Outreach & Prospecting (1–12)](#1-cold-outreach--prospecting)
2. [Discovery & Sales (13–22)](#2-discovery--sales)
3. [Proposals, Quotes & Negotiation (23–32)](#3-proposals-quotes--negotiation)
4. [Onboarding & Kickoff (33–40)](#4-onboarding--kickoff)
5. [Project Updates & Management (41–50)](#5-project-updates--management)
6. [Difficult Conversations (51–60)](#6-difficult-conversations)
7. [Follow-Ups, Referrals & Retention (61–68)](#7-follow-ups-referrals--retention)
8. [Prompt Engineering Cheatsheet](#-prompt-engineering-cheatsheet)

---

## 1. Cold Outreach & Prospecting

### 1. Cold Outreach Email (Personalized)
**Role:** B2B sales copywriter
```
You are a B2B sales copywriter who writes cold emails that get replies, not spam complaints.
Write a cold email to {{prospect_name}}, {{prospect_role}} at {{company}}.
What I offer: {{offer}}. A relevant trigger/observation about them: {{trigger}}.
Structure: personalized opener (1 sentence, no "I hope this finds you well") → the problem I solve → one-line proof → low-friction CTA.
Under 120 words. Subject line + 2 alternatives.
```

### 2. Cold Outreach — Before/After
**Before (weak):**
> Hi, I'm a web designer and I'd love to work with you. We offer great websites at affordable prices. Let me know if you're interested!

**After (strong):**
> Hi Sarah,
> I noticed Acme just launched a new pricing page — congrats. I clicked through and spotted that the mobile checkout takes 6 taps to complete, which usually costs 10–15% of conversions.
> I help SaaS teams fix exactly this. Last month I cut a client's checkout from 6 taps to 3 and lifted conversions 18%.
> Worth a 15-minute look? I'll send a 60-second Loom either way.
> — Alex

**Prompt to generate the "After":**
```
Rewrite this cold email to be specific, personalized, and low-friction. Add a concrete observation, one proof point, and a soft CTA. Keep it under 120 words.
Email: {{paste_email}}
```

### 3. Follow-Up #1 (No Reply)
```
Write a follow-up email to a cold outreach sent {{days}} days ago with no reply.
Add new value (a tip, resource, or insight) — do not just "bump" the thread.
Under 80 words. Friendly, no guilt. Subject line that replies to the same thread.
```

### 4. Follow-Up #2 (Breakup Email)
```
Write a "breakup" email for a prospect who hasn't replied after 3 touches.
Tone: gracious, zero pressure. Give them an easy out and leave the door open.
Under 60 words. Subject: something like "Should I close your file?"
```

### 5. LinkedIn Connection Request + Message
```
Write a LinkedIn connection request note (under 300 characters) and a follow-up message to {{prospect}}.
Context: {{shared_connection_or_trigger}}. My offer: {{offer}}.
The note should be warm and non-salesy. The follow-up (sent after they accept) should offer value first.
```

### 6. Referral Introduction Request
```
Write an email asking {{contact}} to introduce me to {{target}}.
Explain why the intro makes sense for both parties, make it easy to forward (include a blurb they can copy), and keep it under 100 words.
```

### 7. Warm Lead Reactivation
```
Write an email to a lead who went cold {{timeframe}} ago.
Reference our last conversation ({{last_topic}}), share a relevant update or new result, and offer a specific next step.
Under 120 words. No "just checking in."
```

### 8. Event / Conference Follow-Up
```
Write a follow-up email after meeting {{name}} at {{event}}.
Reference something specific from our conversation ({{detail}}), connect it to how I can help ({{offer}}), and propose a concrete next step.
Under 100 words. Send within 24 hours tone.
```

### 9. Cold Email Sequence (5 Touches)
```
Write a 5-email cold outreach sequence to {{persona}} at {{company_type}} about {{offer}}.
Email 1: personalized value. Email 2: case study. Email 3: different angle/objection. Email 4: social proof. Email 5: breakup.
For each: subject line, send day, goal, and body. Keep every email under 120 words.
```

### 10. Partnership / Collab Pitch
```
Write a partnership pitch email to {{company}}.
Propose a specific collaboration ({{idea}}), explain the mutual benefit, and suggest a low-commitment first step.
Under 150 words. Confident but collaborative.
```

### 11. Guest Post / Podcast Pitch
```
Write a pitch email to {{host/publication}} proposing a guest post or podcast appearance.
Include: a hook, 3 specific topic ideas with angles, why I'm credible ({{credentials}}), and links to past work.
Under 150 words. Make it easy for them to say yes.
```

### 12. Subject Line Bank (Outreach)
```
Generate 20 cold email subject lines for an offer about "{{offer}}" to {{persona}}.
Mix: curiosity, benefit, question, personalized, and pattern-interrupt styles.
Keep each under 50 characters. Mark the 5 least "spammy."
```

---

## 2. Discovery & Sales

### 13. Discovery Call Request
```
Write an email proposing a discovery call with a warm lead.
Reference their situation ({{situation}}), state what we'd cover in 20 minutes, and offer 2–3 specific time slots.
Under 100 words. Include a calendar link placeholder.
```

### 14. Discovery Call Confirmation
```
Write a confirmation email for a discovery call on {{date_time}}.
Include: a recap of what we'll discuss, 3 questions they can prepare, the meeting link, and how to reschedule.
Under 120 words. Warm and organized.
```

### 15. Discovery Call Agenda
```
Write a 30-minute discovery call agenda for a prospect interested in {{service}}.
Include: intro, their goals, current situation, budget/timeline, and next steps — with time allocations.
Add 8 open-ended discovery questions to uncover pain and budget.
```

### 16. Post-Discovery Recap
```
Write a post-call recap email summarizing our discovery conversation.
Include: their stated goals, the problems we identified, what I proposed, and the agreed next step ({{next_step}}).
Under 150 words. Make it easy for them to forward to a decision-maker.
```

### 17. Proposal Follow-Up (Post-Send)
```
Write a follow-up email {{days}} days after sending a proposal for {{project}}.
Ask if they have questions, offer to hop on a quick call, and gently create a reason to decide ({{reason, e.g. "my next opening is in 2 weeks"}}).
Under 100 words.
```

### 18. Objection Handling — "Too Expensive"
```
Write an email response to a prospect who says my price for {{service}} is too high.
Reframe around ROI/outcomes, offer a smaller-scope option ({{option}}), and stay confident without discounting immediately.
Under 150 words.
```

### 19. Objection Handling — "Need to Think About It"
```
Write an email to a prospect who wants to "think about it."
Acknowledge their need to decide, surface the likely hesitation, and offer a no-pressure next step.
Under 100 words. Include one clarifying question.
```

### 20. Objection Handling — "We'll Do It In-House"
```
Write an email responding to "we'll handle this in-house."
Respect their capability, highlight the hidden costs (time, opportunity), and position my offer as an accelerator, not a replacement.
Under 130 words.
```

### 21. Sales Call Script
```
Write a sales call script for selling {{offer}} to {{audience}}.
Structure: rapport → discovery questions → pain amplification → solution → proof → price → close → objections.
Include branching responses for 3 common objections.
```

### 22. Testimonial Request (Post-Sale)
```
Write an email asking a happy client for a testimonial.
Make it easy: provide 3–4 specific prompts they can answer, offer to draft it for their approval, and explain how it'll be used.
Under 100 words.
```

---

## 3. Proposals, Quotes & Negotiation

### 23. Proposal Cover Email
```
Write the cover email for a proposal for {{project}} to {{client}}.
Summarize the value in 2 sentences, note the attached proposal, and state the decision deadline ({{deadline}}).
Under 120 words. Confident and clear.
```

### 24. Proposal Executive Summary
```
Write an executive summary for a proposal to {{client}} for {{project}}.
Include: their goal, the problem, my approach, expected outcomes, timeline, and investment range.
Under 250 words. Written for a busy decision-maker.
```

### 25. Scope of Work Section
```
Write a Scope of Work section for a {{project_type}} project.
Include: deliverables, out-of-scope items, assumptions, client responsibilities, and revision limits ({{n}} rounds).
Format as a clear table or bulleted list.
```

### 26. Pricing Options Email
```
Write an email presenting 3 pricing tiers for {{service}}: {{tier_1}}, {{tier_2}}, {{tier_3}}.
Explain who each is for, anchor the middle option as recommended, and invite them to choose.
Under 150 words.
```

### 27. Quote / Estimate Email
```
Write an email with a quote for {{project}} at {{price}}.
Break down what's included, note the validity period ({{days}} days), and state the next step to proceed.
Under 120 words.
```

### 28. Negotiation Response (Discount Request)
```
Write a response to a client asking for a {{discount}}% discount on {{project}}.
Offer alternatives to a straight discount (reduced scope, phased payment, extended timeline) and protect my value.
Under 130 words. Firm but warm.
```

### 29. Rate Increase Announcement
```
Write an email announcing a rate increase from {{old_rate}} to {{new_rate}}, effective {{date}}.
Explain the reason (value delivered, market rates, added services), reassure existing clients, and offer a grace period.
Under 150 words.
```

### 30. Contract / Agreement Cover Email
```
Write an email sending a contract for {{project}} to {{client}}.
Highlight the key terms (scope, payment, timeline, IP), tell them how to sign, and offer to answer questions.
Under 120 words.
```

### 31. Retainer Proposal
```
Write an email proposing a monthly retainer of {{amount}} for {{services}}.
Explain the value of ongoing support vs. one-off projects, list what's included, and propose a start date.
Under 150 words.
```

### 32. Decline a Project (Gracefully)
```
Write an email declining a project because {{reason, e.g. "capacity/not a fit"}}.
Be gracious, refer them to someone who can help ({{referral}}), and leave the relationship warm.
Under 100 words.
```

---

## 4. Onboarding & Kickoff

### 33. Welcome / Onboarding Email
```
Write a welcome email for a new client who just signed for {{project}}.
Include: a warm welcome, what happens next, what I need from them ({{requirements}}), key dates, and how to reach me.
Under 180 words. Reassuring and organized.
```

### 34. Kickoff Call Scheduling
```
Write an email scheduling a project kickoff call.
Propose 2–3 times, outline the agenda (goals, scope, timeline, communication), and list what to prepare.
Under 120 words.
```

### 35. Onboarding Questionnaire
```
Write an onboarding questionnaire email for a {{project_type}} client.
Include 10 questions covering goals, audience, brand, competitors, success metrics, and preferences.
Format so they can reply inline.
```

### 36. Access & Assets Request
```
Write an email requesting the assets and access I need to start {{project}}.
List everything clearly (logins, brand files, content, approvals), explain why each is needed, and set a deadline.
Under 150 words. Make it a checklist.
```

### 37. Project Timeline & Milestones
```
Write an email presenting the project timeline for {{project}}.
Include milestones, dates, dependencies, and what happens at each stage.
Format as a table: Phase | Deliverable | Date | Owner.
```

### 38. Communication & Expectations Setting
```
Write an email setting communication expectations for a new client.
Cover: preferred channels, response times, meeting cadence, revision process, and how to flag issues.
Under 180 words. Collaborative tone.
```

### 39. First Week Check-In
```
Write a check-in email one week into a project.
Confirm we're on track, share a quick win or progress note, and ask if anything needs adjusting.
Under 100 words.
```

### 40. Onboarding Sequence (4 Emails)
```
Write a 4-email onboarding sequence for a new client.
Email 1: welcome + next steps. Email 2: questionnaire + assets. Email 3: kickoff confirmation. Email 4: project start + timeline.
For each: subject, timing, goal, and body.
```

---

## 5. Project Updates & Management

### 41. Weekly Status Update
```
Write a weekly project update email for {{client}}.
Include: progress this week, what's next, blockers, and decisions needed.
Format as a short scannable list. Under 150 words.
```

### 42. Milestone Completion Update
```
Write an email announcing completion of the {{milestone}} milestone for {{project}}.
Celebrate the win, summarize what was delivered, and outline the next phase.
Under 120 words.
```

### 43. Delay Notification (Proactive)
```
Write an email notifying a client of a {{days}}-day delay on {{deliverable}}.
Explain the cause honestly, present a revised timeline, and offer a mitigation.
Under 130 words. Own it without over-apologizing.
```

### 44. Scope Creep Pushback
```
Write an email responding to a client request that's outside our agreed scope ({{request}}).
Acknowledge the idea, clarify what's included, and offer to quote the addition separately.
Under 130 words. Firm and helpful.
```

### 45. Request for Feedback / Approval
```
Write an email requesting client feedback/approval on {{deliverable}}.
Point to the specific areas needing input, give a deadline, and explain what happens after approval.
Under 120 words.
```

### 46. Revision Request Clarification
```
Write an email asking a client to clarify vague feedback ({{feedback}}).
Ask specific questions to pin down what they want, and confirm the revision count remaining.
Under 100 words.
```

### 47. Handoff / Delivery Email
```
Write a delivery email handing off the final {{deliverable}} for {{project}}.
Include: what's included, how to use it, any caveats, and next steps (support, follow-up work).
Under 150 words.
```

### 48. Invoice Email
```
Write an email sending invoice #{{number}} for {{amount}} due {{date}}.
Reference the work completed, include payment methods, and keep it brief and professional.
Under 80 words.
```

### 49. Payment Reminder (Gentle)
```
Write a gentle payment reminder for an overdue invoice ({{days}} days late).
Assume it's an oversight, restate the amount and due date, and provide the payment link.
Under 80 words. No passive aggression.
```

### 50. Project Wrap-Up & Testimonial Ask
```
Write a project wrap-up email that also requests a testimonial and referral.
Summarize results, express gratitude, ask for a testimonial (with prompts), and mention referral incentive.
Under 150 words.
```

---

## 6. Difficult Conversations

### 51. Missed Deadline Apology
```
Write an email apologizing for missing a deadline on {{deliverable}}.
Take responsibility without excuses, explain the impact, present a recovery plan, and reassure them.
Under 130 words. Sincere, not groveling.
```

### 52. Raising a Problem With a Client
```
Write an email raising a concern about {{problem, e.g. "slow feedback" or "unclear direction"}}.
Frame it as a shared problem to solve, propose a fix, and keep it collaborative.
Under 150 words.
```

### 53. Ending a Client Relationship
```
Write an email ending a working relationship with {{client}}.
Give a professional reason ({{reason}}), offer a smooth transition ({{transition_plan}}), and keep the door open.
Under 150 words. No blame.
```

### 54. Firing a Difficult Client
```
Write a firm but professional email ending work with a client who has been {{issue, e.g. "abusive/disrespectful/non-paying"}}.
State the decision clearly, reference the relevant terms, and outline the handover.
Under 150 words. No emotion, no over-explaining.
```

### 55. Disputing an Unfair Request
```
Write an email pushing back on an unreasonable client request ({{request}}).
Reference the agreement, explain why it's not feasible, and offer a fair alternative.
Under 140 words. Calm and factual.
```

### 56. Handling a Complaint
```
Write a response to a client complaint about {{issue}}.
Acknowledge their frustration, take ownership of what's mine, explain what happened, and present a resolution.
Under 150 words. Empathetic and action-oriented.
```

### 57. Requesting a Contract Change
```
Write an email requesting a change to an existing contract ({{change}}).
Explain the reason, propose the revised terms, and ask for their agreement.
Under 130 words.
```

### 58. Chasing a Late Payment (Firm)
```
Write a firm payment chase email for an invoice {{days}} days overdue.
Reference prior reminders, state the consequences ({{consequence, e.g. "work pauses"}}), and request immediate payment.
Under 100 words. Professional, not hostile.
```

### 59. Reducing Scope Due to Budget
```
Write an email explaining that the current budget ({{budget}}) won't cover the full scope ({{scope}}).
Present 2 options: reduce scope or increase budget. Recommend one.
Under 140 words.
```

### 60. Difficult Conversation — Before/After
**Before (weak):**
> Hey, just wondering if you could maybe send the feedback soon? We're a bit behind and it would be great if you could help us out. Sorry to bother you!

**After (strong):**
> Hi Mark,
> Quick heads-up: we're at the feedback stage on the homepage design, and the project timeline now depends on your input. To keep the {{date}} launch on track, I need your notes by Thursday EOD.
> If it's easier, I can hop on a 15-minute call and capture your feedback live — just reply with a time.
> — Alex

**Prompt:**
```
Rewrite this client email to be clear, confident, and specific — without being aggressive. State the ask, the deadline, and the impact. Under 120 words.
Email: {{paste_email}}
```

---

## 7. Follow-Ups, Referrals & Retention

### 61. Post-Project Follow-Up (30 Days)
```
Write a follow-up email 30 days after project completion.
Check in on results, offer a quick tip, and ask if they need anything else.
Under 100 words. Genuinely helpful, not salesy.
```

### 62. Upsell / Cross-Sell Email
```
Write an email offering {{additional_service}} to an existing client who bought {{previous_service}}.
Connect it to their goals, reference results so far, and propose a low-risk next step.
Under 130 words.
```

### 63. Referral Request Email
```
Write an email asking a satisfied client for a referral.
Make it specific (who to refer), easy (a forwardable blurb), and rewarding ({{incentive}}).
Under 100 words.
```

### 64. Re-Engagement (Dormant Client)
```
Write an email re-engaging a client who hasn't worked with me in {{timeframe}}.
Reference our past work, share a relevant update, and offer a specific reason to reconnect.
Under 120 words.
```

### 65. Anniversary / Milestone Email
```
Write an email celebrating a milestone with a client ({{milestone, e.g. "1 year working together"}}).
Reflect on results, express gratitude, and hint at what's next.
Under 100 words. Warm and personal.
```

### 66. Quarterly Business Review Invite
```
Write an email inviting a client to a quarterly review call.
Outline what we'll cover (results, goals, next quarter), propose times, and attach a prep doc placeholder.
Under 130 words.
```

### 67. Reactivation Offer Email
```
Write a win-back email to a client who left {{timeframe}} ago, offering {{offer}}.
Acknowledge the gap, share what's changed, and make returning easy.
Under 120 words.
```

### 68. Thank-You Email (Post-Referral)
```
Write a thank-you email to someone who referred a client to me.
Express genuine gratitude, update them on the outcome, and offer something in return.
Under 90 words.
```

---

## 🧰 Prompt Engineering Cheatsheet

### The Email C.L.E.A.R. Framework
| Letter | Meaning | Example |
|--------|---------|---------|
| **C** | Context | "This is a follow-up to a proposal sent 5 days ago." |
| **L** | Length | "Under 120 words." |
| **E** | Emotion | "Warm but professional; no guilt-tripping." |
| **A** | Action | "End with a single clear CTA." |
| **R** | Recipient | "Written for a busy CFO who skims on mobile." |

### Power Phrases for Emails
- **To cut fluff:** "Remove all filler. No 'just checking in,' no 'I hope this finds you well.'"
- **To get options:** "Give me 3 versions: warm, direct, and playful."
- **To fix tone:** "Rewrite this to sound confident, not needy."
- **To personalize:** "Use the specific detail I provide in the first sentence."
- **To close:** "End with one CTA and nothing else."

### Subject Line Formulas That Work
1. **Specific observation:** "Noticed your checkout takes 6 taps"
2. **Question:** "Should I close your file?"
3. **Benefit + timeframe:** "Cut onboarding time by 40% in 2 weeks"
4. **Curiosity:** "The email that got a 62% reply rate"
5. **Personal:** "Following up on our chat about X"

### The Golden Rules of Client Email
1. **One email, one ask.** Never bury the CTA.
2. **Lead with them, not you.** "You/your" > "I/we."
3. **Be specific.** Dates, numbers, and names beat vague promises.
4. **Make it easy to say yes.** Offer a link, a time, or a template.
5. **Never send angry.** Draft it, wait an hour, then rewrite with AI.

---

*End of Client & Sales Email Prompts — 68 prompts. Part of the AI Prompt Arsenal.*
