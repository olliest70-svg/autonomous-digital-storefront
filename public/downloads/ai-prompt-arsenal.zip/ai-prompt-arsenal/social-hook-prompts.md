# 📱 Social Media & Hook Prompts — 60+ Prompts

> **Part of the AI Prompt Arsenal.** Hooks, carousels, threads, captions, and repurposing — engineered to stop the scroll and drive engagement.

**How to read this file:** Each prompt shows the **Role**, the **Prompt** (with `{{variables}}`), and where useful a **Before / After** or **Example Output**.

---

## Table of Contents

1. [Hooks & Openers (1–14)](#1-hooks--openers)
2. [LinkedIn Posts (15–24)](#2-linkedin-posts)
3. [X / Twitter Threads (25–33)](#3-x--twitter-threads)
4. [Instagram & TikTok (34–43)](#4-instagram--tiktok)
5. [Carousels & Visual Content (44–51)](#5-carousels--visual-content)
6. [Community & Engagement (52–58)](#6-community--engagement)
7. [Repurposing & Content Systems (59–64)](#7-repurposing--content-systems)
8. [Prompt Engineering Cheatsheet](#-prompt-engineering-cheatsheet)

---

## 1. Hooks & Openers

### 1. Hook Machine (Multi-Style)
**Role:** Viral social copywriter
```
You are a social copywriter who writes hooks that stop the scroll.
Write 15 hooks for a post about "{{topic}}" for {{audience}}.
Include: 3 curiosity, 3 bold-claim, 3 question, 3 story, 3 contrarian.
Each under 12 words. Mark the 3 strongest and explain why they work.
```

### 2. Curiosity-Gap Hook
```
Write 10 curiosity-gap hooks about "{{topic}}".
Each should open a loop the reader must close (e.g. "Nobody talks about the real reason…").
Under 15 words each. Avoid clickbait that the post can't deliver on.
```

### 3. Contrarian Hook
```
Write 10 contrarian hooks that challenge a common belief in {{niche}}.
Format: "Everyone says X. Here's why that's wrong."
Keep each under 15 words and make sure the post can back it up.
```

### 4. Story Hook
```
Write 10 story-based hooks for a post about {{experience}}.
Open in-scene: a specific moment, line of dialogue, or detail.
Under 20 words each. Make the reader feel like they're there.
```

### 5. Number / List Hook
```
Write 10 list-style hooks about "{{topic}}" (e.g. "7 things I wish I knew before…").
Keep each under 15 words. Make the number feel earned, not arbitrary.
```

### 6. Hook — Before/After
**Before (weak):**
> Here are some tips about productivity that might help you get more done.

**After (strong):**
> I wasted 3 years "getting organized." Then I deleted my to-do app and got more done in 2 weeks than the previous 6 months. Here's the system that replaced it:

**Prompt:**
```
Rewrite this opener into 5 scroll-stopping hooks using different techniques (story, contrarian, curiosity, number, question). Keep the core message.
Opener: {{paste_opener}}
```

### 7. First-Line Optimizer
```
Here is the first line of my post: "{{first_line}}".
Rewrite it 8 ways to maximize the chance of stopping the scroll. Keep the meaning. Mark the strongest 3.
```

### 8. Hook for a Cold Audience
```
Write 10 hooks about "{{topic}}" for an audience that has never heard of me.
Each should be self-contained (no inside references) and deliver value in the first line.
```

### 9. Hook for a Warm Audience
```
Write 10 hooks about "{{topic}}" for my existing followers who know my work.
Use callbacks, running themes, and a "you asked, so here it is" angle.
```

### 10. Pattern-Interrupt Hook
```
Write 10 pattern-interrupt hooks about "{{topic}}" — openers that break the expected format of a feed.
Examples: a confession, a one-word line, a bold statement, a screenshot caption.
```

### 11. Hook Bank for a Topic Series
```
I'm posting a {{n}}-part series about "{{topic}}".
Write a hook for each part that also teases the next. Keep them consistent in style.
Output as a numbered list with the through-line noted.
```

### 12. Emotional Hook
```
Write 10 emotionally resonant hooks about "{{topic}}".
Target emotions: relief, hope, frustration, pride, surprise. Label each.
Keep them authentic, not manipulative.
```

### 13. Hook Testing Plan
```
Here are 5 hooks I'm considering: {{hooks}}.
Recommend which to A/B test first, what metric to watch (CTR, dwell, saves), and how to interpret results.
```

### 14. Hook Rewrite Sprint
```
Take this post and rewrite only the first line 10 different ways: {{post}}.
For each, note the technique used and the likely audience reaction.
```

---

## 2. LinkedIn Posts

### 15. LinkedIn Story Post
**Role:** LinkedIn ghostwriter
```
You are a LinkedIn ghostwriter. Write a LinkedIn post telling a story about {{experience}}.
Structure: hook → context → tension → turning point → lesson → question to the reader.
Use short lines and white space. Under 200 words. No hashtags in the body.
```

### 16. LinkedIn List Post
```
Write a LinkedIn list post: "{{number}} lessons I learned from {{experience}}".
Each lesson: a bolded one-liner + 1–2 sentences of explanation.
Open with a hook, close with a question. Under 250 words.
```

### 17. LinkedIn Contrarian Post
```
Write a LinkedIn post arguing that {{contrarian_claim}}.
Open with the common belief, then dismantle it with 3 reasons and one example.
End with a question that invites debate. Under 200 words.
```

### 18. LinkedIn Case Study Post
```
Turn these results into a LinkedIn case study post: {{results}}.
Structure: hook → the problem → what we did → the result (with numbers) → the lesson.
Under 200 words. Make it about the client, not me.
```

### 19. LinkedIn "How I Did It" Post
```
Write a LinkedIn post explaining how I {{achievement}}.
Structure: hook → the before state → the 3–5 steps → the result → a takeaway.
Under 220 words. Specific and tactical.
```

### 20. LinkedIn Carousel Outline
```
Create a 10-slide LinkedIn carousel outline about "{{topic}}".
Slide 1: hook. Slides 2–9: one idea each (headline + 1 line). Slide 10: CTA.
Output as a table: Slide | Headline | Body | Visual Note.
```

### 21. LinkedIn Comment Bait Post
```
Write a LinkedIn post about "{{topic}}" designed to generate comments.
End with a specific, easy-to-answer question (not "thoughts?"). Under 150 words.
Give 3 question options.
```

### 22. LinkedIn Profile Headline
```
Write 10 LinkedIn profile headlines for a {{role}} who helps {{audience}} with {{outcome}}.
Keep each under 220 characters. Include a benefit and a keyword. Mark the strongest 3.
```

### 23. LinkedIn About Section
```
Write a LinkedIn "About" section for a {{role}}.
Structure: hook → who I help → how → proof → CTA.
First person, conversational, keyword-aware. Under 200 words.
```

### 24. LinkedIn Post — Before/After
**Before (weak):**
> I'm excited to share that I've been thinking a lot about leadership lately. Leadership is really important and I think we can all learn to be better leaders. What do you think?

**After (strong):**
> I fired my best performer last year. She hit every target — and quietly burned out the other 4 people on her team.
> Here's what I got wrong about leadership:
> I promoted for output, not for how she made others feel.
> I measured her results, not her ripple.
> I confused "high performer" with "good leader."
> The fix wasn't a training course. It was changing what I rewarded.
> What's one leadership belief you've had to unlearn?

**Prompt:**
```
Rewrite this LinkedIn post to open with a specific story or claim, use short lines, and end with an engaging question. Keep it under 200 words.
Post: {{paste_post}}
```

---

## 3. X / Twitter Threads

### 25. Thread From an Idea
**Role:** X/Twitter thread writer
```
Write a 10-post thread about "{{topic}}" for {{audience}}.
Post 1: a hook that promises a specific payoff. Posts 2–9: one idea each, under 280 chars. Post 10: recap + CTA.
Make each post readable standalone. Number them.
```

### 26. Thread From an Article
```
Turn this article into a 10-post thread: {{paste_article}}.
Extract the sharpest ideas, write a scroll-stopping first post, and end with a CTA to the full piece.
Keep each post under 280 characters.
```

### 27. Thread Hook
```
Write 10 first-posts (hooks) for a thread about "{{topic}}".
Each must promise a clear payoff and create curiosity. Under 280 chars. Mark the 3 strongest.
```

### 28. Thread Outline
```
Create a thread outline for "{{topic}}" with {{n}} posts.
For each post: the core point, a supporting example, and the transition to the next.
Output as a numbered list.
```

### 29. Single Viral Tweet
```
Write 10 standalone tweets about "{{topic}}".
Mix: insight, hot take, tip, story, and question. Under 280 chars each.
Mark the 3 most likely to get engagement.
```

### 30. Tweet — Before/After
**Before:**
> I think AI is going to change a lot of things for marketers. It's important to learn how to use it. Let me know your thoughts.

**After:**
> AI didn't replace my copywriter.
> It replaced my excuses.
> I shipped 3x more content last quarter with the same team — here's the exact workflow (thread):

**Prompt:**
```
Rewrite this tweet to be punchy, specific, and hook-driven. Give 5 versions under 280 characters.
Tweet: {{paste_tweet}}
```

### 31. Quote-Tweet / Reply Bait
```
Write 5 quote-tweet-style posts about "{{topic}}" that invite replies.
Each should take a clear stance and end with an open question. Under 280 chars.
```

### 32. Thread CTA Bank
```
Write 10 closing posts (CTAs) for threads about "{{topic}}".
Mix: follow, repost, newsletter signup, reply, and link. Keep each under 280 chars.
```

### 33. Thread Repurposing Plan
```
I have a thread about "{{topic}}". Plan how to repurpose it into: a LinkedIn post, an Instagram carousel, a short video, and a newsletter section.
Output a table: Format | Adaptation | Key Change.
```

---

## 4. Instagram & TikTok

### 34. Instagram Caption
**Role:** Instagram content strategist
```
Write 3 Instagram captions for a post about "{{topic}}".
Each: a hook first line, 2–4 short paragraphs, a CTA, and 5–8 relevant hashtags.
Tone: {{tone}}. Keep the first line under 125 characters (before the "more" cut).
```

### 35. TikTok / Reels Script
```
Write a 30-second TikTok/Reels script about "{{topic}}".
Format: Hook (0–3s) → Value (3–25s) → CTA (25–30s).
Include on-screen text and a suggested visual for each beat. Make the hook a pattern interrupt.
```

### 36. Instagram Carousel Copy
```
Write copy for a 10-slide Instagram carousel about "{{topic}}".
Slide 1: hook. Slides 2–9: one tip each (headline + 1 line). Slide 10: CTA.
Output as a table: Slide | Headline | Body.
```

### 37. Reel Hook Bank
```
Write 15 hooks for short-form video about "{{topic}}".
Each under 10 words, spoken naturally. Mix: question, bold claim, curiosity, and "watch this if…" styles.
```

### 38. Instagram Story Sequence
```
Write a 6-frame Instagram Story sequence promoting {{offer}}.
Frame 1: hook/poll. Frames 2–4: value. Frame 5: proof. Frame 6: CTA with link sticker.
Include text and visual notes for each frame.
```

### 39. TikTok Trend Adaptation
```
Adapt this trending format to my niche ({{niche}}): {{trend_description}}.
Write a script that fits the trend but delivers value about "{{topic}}". Include the hook and CTA.
```

### 40. Instagram Bio
```
Write 10 Instagram bios for a {{role}} who helps {{audience}} with {{outcome}}.
Each under 150 characters. Include a hook, a benefit, and a CTA. Mark the strongest 3.
```

### 41. Hashtag Strategy
```
Generate a hashtag strategy for a {{niche}} account.
Include: 10 niche hashtags, 10 mid-size, 5 broad, and 5 branded. Explain the mix ratio and how to rotate them.
```

### 42. Caption — Before/After
**Before:**
> New blog post is live! Check it out, link in bio. Hope you like it!

**After:**
> I almost quit freelancing in month 3.
> One thing saved me: charging by the project, not the hour.
> I wrote the exact pricing framework I use now — link in bio.
> What's the #1 thing you'd tell a new freelancer?

**Prompt:**
```
Rewrite this Instagram caption to open with a hook, add value, and end with a question. Add 6 relevant hashtags.
Caption: {{paste_caption}}
```

### 43. Short-Form Content Calendar
```
Create a 30-day short-form content calendar for a {{niche}} account.
Include: 5 content pillars, a post idea per day, and the format (reel, carousel, story).
Output as a table: Day | Pillar | Idea | Format | Hook.
```

---

## 5. Carousels & Visual Content

### 44. Carousel From a Blog Post
```
Turn this blog post into a 10-slide carousel: {{paste_post}}.
Slide 1: hook. Slides 2–9: one key point each. Slide 10: CTA.
Keep each slide under 30 words. Output as a table with a visual suggestion per slide.
```

### 45. Infographic Outline
```
Create an infographic outline about "{{topic}}".
Include: a title, 5–7 data points or steps, and a source note. Describe the ideal layout and color logic.
Output as a structured outline.
```

### 46. Quote Graphic Copy
```
Write 10 short, quotable lines about "{{topic}}" suitable for quote graphics.
Each under 15 words, punchy, and standalone. Mark the 3 most shareable.
```

### 47. Carousel Hook Slides
```
Write 10 opening-slide hooks for a carousel about "{{topic}}".
Each under 10 words and designed to earn the swipe. Mark the strongest 3.
```

### 48. Visual Content Ideas
```
Generate 15 visual content ideas for a {{niche}} account.
Mix: carousels, infographics, before/after, charts, memes, and screenshots.
For each: the idea, the format, and the hook.
```

### 49. Slide-by-Slide Carousel Script
```
Write a full 8-slide carousel script about "{{topic}}" for {{audience}}.
Each slide: headline (≤8 words) + body (≤25 words). Slide 1 = hook, slide 8 = CTA.
```

### 50. Chart / Data Post
```
Turn this data into a social post: {{data}}.
Write a hook, a one-line insight, and a CTA. Suggest the best chart type and a caption.
```

### 51. Carousel — Before/After
**Before (weak slide 1):**
> 5 Tips for Better Marketing

**After (strong slide 1):**
> I spent $40k on ads so you don't have to.
> 5 mistakes that quietly killed my ROI →

**Prompt:**
```
Rewrite this carousel's first slide into 5 stronger hooks that create curiosity and promise a payoff.
Slide: {{paste_slide}}
```

---

## 6. Community & Engagement

### 52. Engagement Question Bank
```
Write 20 engagement questions about "{{topic}}" for a {{platform}} audience.
Mix: easy (one-word answers), opinion, experience, and hypothetical.
Mark the 5 most likely to get replies.
```

### 53. Poll Ideas
```
Generate 10 poll ideas for a {{niche}} audience.
Each: the question and 3–4 options. Make them quick to answer and genuinely interesting.
```

### 54. Reply / Comment Strategy
```
Write 10 thoughtful comment templates I can use to engage with posts in my niche ({{niche}}).
Each should add value, not just praise. Include a question to keep the conversation going.
```

### 55. Community Post
```
Write a community post for a {{platform}} group about "{{topic}}".
Open with a relatable observation, share a quick insight, and invite members to share their experience.
Under 150 words. Warm and inclusive.
```

### 56. DM Outreach (Warm)
```
Write a warm DM to {{name}} who engaged with my content about "{{topic}}".
Reference their specific comment/post, offer genuine value, and ask a light question. Under 60 words. No pitch.
```

### 57. DM Outreach (Value-First Pitch)
```
Write a value-first DM to a potential client ({{name}}) about {{offer}}.
Lead with a specific, free insight about their business, then offer a soft next step. Under 80 words.
```

### 58. Community Announcement
```
Write an announcement post for {{event/launch}} to my community.
Include: what it is, why it matters to them, the date/details, and a clear CTA.
Under 150 words. Excited but not hypey.
```

---

## 7. Repurposing & Content Systems

### 59. One Idea → 10 Posts
```
Take this single idea: {{idea}}.
Turn it into 10 social posts: 2 LinkedIn, 2 X, 2 Instagram, 2 short-video scripts, and 2 carousels.
Output each as a labeled section with a hook and body.
```

### 60. Content Pillar System
```
Design a content system for a {{niche}} creator with 5 content pillars.
For each pillar: the theme, 5 post ideas, and the format. Then suggest a weekly posting schedule.
Output as a table.
```

### 61. Post Repurposing Matrix
```
I have these top-performing posts: {{posts}}.
Create a repurposing matrix showing how each can be adapted across platforms.
Output a table: Post | LinkedIn | X | Instagram | Video | Newsletter.
```

### 62. Content Batching Plan
```
Create a batching plan to produce {{n}} posts in one 3-hour session.
Include: the workflow, the order of tasks, templates to reuse, and how to schedule.
Output as a timed checklist.
```

### 63. Engagement-to-Content Loop
```
Here are my best-performing posts and the comments they got: {{posts_and_comments}}.
Identify content ideas hidden in the comments (questions, objections, stories) and turn them into 10 new post ideas.
```

### 64. Monthly Content Review
```
Review this month's content performance: {{metrics}}.
Identify: top 3 posts and why they worked, bottom 3 and why, and 5 recommendations for next month.
Output as a structured report.
```

---

## 🧰 Prompt Engineering Cheatsheet

### The Hook H.A.C.K. Framework
| Letter | Meaning | Example |
|--------|---------|---------|
| **H** | Hook | "I fired my best performer last year." |
| **A** | Agitate | "She hit every target — and burned out her team." |
| **C** | Content | "Here's what I got wrong about leadership." |
| **K** | Kick | "What belief have you had to unlearn?" |

### Power Phrases for Social Prompts
- **To stop the scroll:** "Make the first line a pattern interrupt."
- **To get engagement:** "End with a specific, easy-to-answer question."
- **To stay native:** "Write in the platform's native style — no cross-posting tone."
- **To get options:** "Give me 10 hooks and mark the strongest 3."
- **To avoid cringe:** "No hashtags in the body. No 'game-changer.' No emoji spam."

### Platform Cheat Sheet
| Platform | Sweet Spot | Hook Style | CTA Style |
|----------|-----------|------------|-----------|
| LinkedIn | 150–250 words | Story or contrarian | Question |
| X/Twitter | ≤280 chars/post | Bold claim | Repost/follow |
| Instagram | 125-char first line | Relatable pain | Save/share |
| TikTok | 15–45 seconds | Pattern interrupt | Follow/comment |

### The 5 Hook Types That Always Work
1. **The confession** — "I almost quit…"
2. **The contrarian** — "Everyone says X. They're wrong."
3. **The specific number** — "$40k, 3 years, 6 mistakes…"
4. **The curiosity gap** — "Nobody talks about the real reason…"
5. **The direct callout** — "If you're a freelancer, read this."

---

*End of Social Media & Hook Prompts — 64 prompts. Part of the AI Prompt Arsenal.*
